--
-- PostgreSQL database dump
--

\restrict MXEveMPs96eWcrxUjJg2polRxXLyWdw2NS2wg8jiVDPMQnrROCttm8eXJQbkh2D

-- Dumped from database version 15.15 (Debian 15.15-1.pgdg13+1)
-- Dumped by pg_dump version 15.15 (Debian 15.15-1.pgdg11+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts_activedirectorygroupmap; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts_activedirectorygroupmap (
    id integer NOT NULL,
    ad_group character varying(255) NOT NULL,
    account_qualifier boolean NOT NULL
);


ALTER TABLE public.accounts_activedirectorygroupmap OWNER TO postgres;

--
-- Name: accounts_activedirectorygroupmap_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts_activedirectorygroupmap_groups (
    id integer NOT NULL,
    activedirectorygroupmap_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.accounts_activedirectorygroupmap_groups OWNER TO postgres;

--
-- Name: accounts_activedirectorygroupmap_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accounts_activedirectorygroupmap_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_activedirectorygroupmap_groups_id_seq OWNER TO postgres;

--
-- Name: accounts_activedirectorygroupmap_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accounts_activedirectorygroupmap_groups_id_seq OWNED BY public.accounts_activedirectorygroupmap_groups.id;


--
-- Name: accounts_activedirectorygroupmap_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accounts_activedirectorygroupmap_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_activedirectorygroupmap_id_seq OWNER TO postgres;

--
-- Name: accounts_activedirectorygroupmap_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accounts_activedirectorygroupmap_id_seq OWNED BY public.accounts_activedirectorygroupmap.id;


--
-- Name: accounts_defaultgroup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts_defaultgroup (
    id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.accounts_defaultgroup OWNER TO postgres;

--
-- Name: accounts_defaultgroup_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accounts_defaultgroup_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_defaultgroup_id_seq OWNER TO postgres;

--
-- Name: accounts_defaultgroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accounts_defaultgroup_id_seq OWNED BY public.accounts_defaultgroup.id;


--
-- Name: attachments_attachment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attachments_attachment (
    id integer NOT NULL,
    attachment character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    comment text NOT NULL,
    created timestamp with time zone NOT NULL,
    created_by_id integer NOT NULL,
    test_id integer,
    testinstance_id integer,
    testlist_id integer,
    testlistcycle_id integer,
    testlistinstance_id integer,
    serviceevent_id integer,
    part_id integer,
    fault_id integer
);


ALTER TABLE public.attachments_attachment OWNER TO postgres;

--
-- Name: attachments_attachment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attachments_attachment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.attachments_attachment_id_seq OWNER TO postgres;

--
-- Name: attachments_attachment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attachments_attachment_id_seq OWNED BY public.attachments_attachment.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO postgres;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO postgres;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: authtoken_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.authtoken_token (
    key character varying(40) NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.authtoken_token OWNER TO postgres;

--
-- Name: contacts_contact; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contacts_contact (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    number character varying(256) NOT NULL,
    description text NOT NULL
);


ALTER TABLE public.contacts_contact OWNER TO postgres;

--
-- Name: contacts_contact_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contacts_contact_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contacts_contact_id_seq OWNER TO postgres;

--
-- Name: contacts_contact_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.contacts_contact_id_seq OWNED BY public.contacts_contact.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_comment_flags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_comment_flags (
    id integer NOT NULL,
    flag character varying(30) NOT NULL,
    flag_date timestamp with time zone NOT NULL,
    comment_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.django_comment_flags OWNER TO postgres;

--
-- Name: django_comment_flags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_comment_flags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_comment_flags_id_seq OWNER TO postgres;

--
-- Name: django_comment_flags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_comment_flags_id_seq OWNED BY public.django_comment_flags.id;


--
-- Name: django_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_comments (
    id integer NOT NULL,
    object_pk text NOT NULL,
    user_name character varying(50) NOT NULL,
    user_email character varying(254) NOT NULL,
    user_url character varying(200) NOT NULL,
    comment text NOT NULL,
    submit_date timestamp with time zone NOT NULL,
    ip_address inet,
    is_public boolean NOT NULL,
    is_removed boolean NOT NULL,
    content_type_id integer NOT NULL,
    site_id integer NOT NULL,
    user_id integer
);


ALTER TABLE public.django_comments OWNER TO postgres;

--
-- Name: django_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_comments_id_seq OWNER TO postgres;

--
-- Name: django_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_comments_id_seq OWNED BY public.django_comments.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_q_ormq; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_q_ormq (
    id integer NOT NULL,
    key character varying(100) NOT NULL,
    payload text NOT NULL,
    lock timestamp with time zone
);


ALTER TABLE public.django_q_ormq OWNER TO postgres;

--
-- Name: django_q_ormq_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_q_ormq_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_q_ormq_id_seq OWNER TO postgres;

--
-- Name: django_q_ormq_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_q_ormq_id_seq OWNED BY public.django_q_ormq.id;


--
-- Name: django_q_schedule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_q_schedule (
    id integer NOT NULL,
    func character varying(256) NOT NULL,
    hook character varying(256),
    args text,
    kwargs text,
    schedule_type character varying(1) NOT NULL,
    repeats integer NOT NULL,
    next_run timestamp with time zone,
    task character varying(100),
    name character varying(100),
    minutes smallint,
    cron character varying(100),
    CONSTRAINT django_q_schedule_minutes_check CHECK ((minutes >= 0))
);


ALTER TABLE public.django_q_schedule OWNER TO postgres;

--
-- Name: django_q_schedule_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_q_schedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_q_schedule_id_seq OWNER TO postgres;

--
-- Name: django_q_schedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_q_schedule_id_seq OWNED BY public.django_q_schedule.id;


--
-- Name: django_q_task; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_q_task (
    name character varying(100) NOT NULL,
    func character varying(256) NOT NULL,
    hook character varying(256),
    args text,
    kwargs text,
    result text,
    started timestamp with time zone NOT NULL,
    stopped timestamp with time zone NOT NULL,
    success boolean NOT NULL,
    id character varying(32) NOT NULL,
    "group" character varying(100),
    attempt_count integer NOT NULL
);


ALTER TABLE public.django_q_task OWNER TO postgres;

--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO postgres;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_site_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO postgres;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_site_id_seq OWNED BY public.django_site.id;


--
-- Name: faults_fault; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.faults_fault (
    id integer NOT NULL,
    occurred timestamp with time zone NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    created_by_id integer NOT NULL,
    modality_id integer,
    modified_by_id integer NOT NULL,
    unit_id integer NOT NULL
);


ALTER TABLE public.faults_fault OWNER TO postgres;

--
-- Name: faults_fault_fault_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.faults_fault_fault_types (
    id integer NOT NULL,
    fault_id integer NOT NULL,
    faulttype_id integer NOT NULL
);


ALTER TABLE public.faults_fault_fault_types OWNER TO postgres;

--
-- Name: faults_fault_fault_types_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.faults_fault_fault_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.faults_fault_fault_types_id_seq OWNER TO postgres;

--
-- Name: faults_fault_fault_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.faults_fault_fault_types_id_seq OWNED BY public.faults_fault_fault_types.id;


--
-- Name: faults_fault_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.faults_fault_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.faults_fault_id_seq OWNER TO postgres;

--
-- Name: faults_fault_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.faults_fault_id_seq OWNED BY public.faults_fault.id;


--
-- Name: faults_fault_related_service_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.faults_fault_related_service_events (
    id integer NOT NULL,
    fault_id integer NOT NULL,
    serviceevent_id integer NOT NULL
);


ALTER TABLE public.faults_fault_related_service_events OWNER TO postgres;

--
-- Name: faults_fault_related_service_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.faults_fault_related_service_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.faults_fault_related_service_events_id_seq OWNER TO postgres;

--
-- Name: faults_fault_related_service_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.faults_fault_related_service_events_id_seq OWNED BY public.faults_fault_related_service_events.id;


--
-- Name: faults_faultreviewgroup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.faults_faultreviewgroup (
    id integer NOT NULL,
    required boolean NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.faults_faultreviewgroup OWNER TO postgres;

--
-- Name: faults_faultreviewgroup_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.faults_faultreviewgroup_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.faults_faultreviewgroup_id_seq OWNER TO postgres;

--
-- Name: faults_faultreviewgroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.faults_faultreviewgroup_id_seq OWNED BY public.faults_faultreviewgroup.id;


--
-- Name: faults_faultreviewinstance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.faults_faultreviewinstance (
    id integer NOT NULL,
    reviewed timestamp with time zone NOT NULL,
    fault_id integer NOT NULL,
    fault_review_group_id integer,
    reviewed_by_id integer NOT NULL
);


ALTER TABLE public.faults_faultreviewinstance OWNER TO postgres;

--
-- Name: faults_faultreviewinstance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.faults_faultreviewinstance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.faults_faultreviewinstance_id_seq OWNER TO postgres;

--
-- Name: faults_faultreviewinstance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.faults_faultreviewinstance_id_seq OWNED BY public.faults_faultreviewinstance.id;


--
-- Name: faults_faulttype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.faults_faulttype (
    id integer NOT NULL,
    code character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text NOT NULL
);


ALTER TABLE public.faults_faulttype OWNER TO postgres;

--
-- Name: faults_faulttype_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.faults_faulttype_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.faults_faulttype_id_seq OWNER TO postgres;

--
-- Name: faults_faulttype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.faults_faulttype_id_seq OWNED BY public.faults_faulttype.id;


--
-- Name: issue_tracker_issue; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.issue_tracker_issue (
    id integer NOT NULL,
    datetime_submitted timestamp with time zone NOT NULL,
    description text NOT NULL,
    error_screen text,
    issue_type_id integer NOT NULL,
    user_submitted_by_id integer NOT NULL,
    issue_priority_id integer,
    issue_status_id integer
);


ALTER TABLE public.issue_tracker_issue OWNER TO postgres;

--
-- Name: issue_tracker_issue_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.issue_tracker_issue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.issue_tracker_issue_id_seq OWNER TO postgres;

--
-- Name: issue_tracker_issue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.issue_tracker_issue_id_seq OWNED BY public.issue_tracker_issue.id;


--
-- Name: issue_tracker_issue_issue_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.issue_tracker_issue_issue_tags (
    id integer NOT NULL,
    issue_id integer NOT NULL,
    issuetag_id integer NOT NULL
);


ALTER TABLE public.issue_tracker_issue_issue_tags OWNER TO postgres;

--
-- Name: issue_tracker_issue_issue_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.issue_tracker_issue_issue_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.issue_tracker_issue_issue_tags_id_seq OWNER TO postgres;

--
-- Name: issue_tracker_issue_issue_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.issue_tracker_issue_issue_tags_id_seq OWNED BY public.issue_tracker_issue_issue_tags.id;


--
-- Name: issue_tracker_issuepriority; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.issue_tracker_issuepriority (
    id integer NOT NULL,
    name character varying(32) NOT NULL,
    colour character varying(22),
    "order" integer NOT NULL,
    CONSTRAINT issue_tracker_issuepriority_order_check CHECK (("order" >= 0))
);


ALTER TABLE public.issue_tracker_issuepriority OWNER TO postgres;

--
-- Name: issue_tracker_issuepriority_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.issue_tracker_issuepriority_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.issue_tracker_issuepriority_id_seq OWNER TO postgres;

--
-- Name: issue_tracker_issuepriority_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.issue_tracker_issuepriority_id_seq OWNED BY public.issue_tracker_issuepriority.id;


--
-- Name: issue_tracker_issuestatus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.issue_tracker_issuestatus (
    id integer NOT NULL,
    name character varying(32) NOT NULL,
    description character varying(255),
    colour character varying(22),
    "order" integer NOT NULL,
    CONSTRAINT issue_tracker_issuestatus_order_check CHECK (("order" >= 0))
);


ALTER TABLE public.issue_tracker_issuestatus OWNER TO postgres;

--
-- Name: issue_tracker_issuestatus_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.issue_tracker_issuestatus_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.issue_tracker_issuestatus_id_seq OWNER TO postgres;

--
-- Name: issue_tracker_issuestatus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.issue_tracker_issuestatus_id_seq OWNED BY public.issue_tracker_issuestatus.id;


--
-- Name: issue_tracker_issuetag; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.issue_tracker_issuetag (
    id integer NOT NULL,
    name character varying(32) NOT NULL,
    description character varying(255)
);


ALTER TABLE public.issue_tracker_issuetag OWNER TO postgres;

--
-- Name: issue_tracker_issuetag_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.issue_tracker_issuetag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.issue_tracker_issuetag_id_seq OWNER TO postgres;

--
-- Name: issue_tracker_issuetag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.issue_tracker_issuetag_id_seq OWNED BY public.issue_tracker_issuetag.id;


--
-- Name: issue_tracker_issuetype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.issue_tracker_issuetype (
    id integer NOT NULL,
    name character varying(32) NOT NULL
);


ALTER TABLE public.issue_tracker_issuetype OWNER TO postgres;

--
-- Name: issue_tracker_issuetype_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.issue_tracker_issuetype_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.issue_tracker_issuetype_id_seq OWNER TO postgres;

--
-- Name: issue_tracker_issuetype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.issue_tracker_issuetype_id_seq OWNED BY public.issue_tracker_issuetype.id;


--
-- Name: notifications_faultnotice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications_faultnotice (
    id integer NOT NULL,
    notification_type integer NOT NULL,
    recipients_id integer NOT NULL,
    units_id integer
);


ALTER TABLE public.notifications_faultnotice OWNER TO postgres;

--
-- Name: notifications_faultnotice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_faultnotice_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_faultnotice_id_seq OWNER TO postgres;

--
-- Name: notifications_faultnotice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_faultnotice_id_seq OWNED BY public.notifications_faultnotice.id;


--
-- Name: notifications_faultsreviewnotice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications_faultsreviewnotice (
    id integer NOT NULL,
    notification_type integer NOT NULL,
    send_empty boolean NOT NULL,
    recurrences text NOT NULL,
    "time" time without time zone NOT NULL,
    last_sent timestamp with time zone,
    recipients_id integer NOT NULL,
    units_id integer
);


ALTER TABLE public.notifications_faultsreviewnotice OWNER TO postgres;

--
-- Name: notifications_faultsreviewnotice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_faultsreviewnotice_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_faultsreviewnotice_id_seq OWNER TO postgres;

--
-- Name: notifications_faultsreviewnotice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_faultsreviewnotice_id_seq OWNED BY public.notifications_faultsreviewnotice.id;


--
-- Name: notifications_partcategorygroup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications_partcategorygroup (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.notifications_partcategorygroup OWNER TO postgres;

--
-- Name: notifications_partcategorygroup_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_partcategorygroup_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_partcategorygroup_id_seq OWNER TO postgres;

--
-- Name: notifications_partcategorygroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_partcategorygroup_id_seq OWNED BY public.notifications_partcategorygroup.id;


--
-- Name: notifications_partcategorygroup_part_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications_partcategorygroup_part_categories (
    id integer NOT NULL,
    partcategorygroup_id integer NOT NULL,
    partcategory_id integer NOT NULL
);


ALTER TABLE public.notifications_partcategorygroup_part_categories OWNER TO postgres;

--
-- Name: notifications_partcategorygroup_part_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_partcategorygroup_part_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_partcategorygroup_part_categories_id_seq OWNER TO postgres;

--
-- Name: notifications_partcategorygroup_part_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_partcategorygroup_part_categories_id_seq OWNED BY public.notifications_partcategorygroup_part_categories.id;


--
-- Name: notifications_partnotice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications_partnotice (
    id integer NOT NULL,
    notification_type character varying(128) NOT NULL,
    part_categories_id integer,
    recipients_id integer NOT NULL
);


ALTER TABLE public.notifications_partnotice OWNER TO postgres;

--
-- Name: notifications_partnotice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_partnotice_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_partnotice_id_seq OWNER TO postgres;

--
-- Name: notifications_partnotice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_partnotice_id_seq OWNED BY public.notifications_partnotice.id;


--
-- Name: notifications_qccompletednotice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications_qccompletednotice (
    id integer NOT NULL,
    notification_type integer NOT NULL,
    follow_up_days integer,
    recipients_id integer NOT NULL,
    test_lists_id integer,
    units_id integer,
    CONSTRAINT notifications_qccompletednotice_follow_up_days_check CHECK ((follow_up_days >= 0))
);


ALTER TABLE public.notifications_qccompletednotice OWNER TO postgres;

--
-- Name: notifications_qccompletednotice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_qccompletednotice_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_qccompletednotice_id_seq OWNER TO postgres;

--
-- Name: notifications_qccompletednotice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_qccompletednotice_id_seq OWNED BY public.notifications_qccompletednotice.id;


--
-- Name: notifications_qcreviewnotice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications_qcreviewnotice (
    id integer NOT NULL,
    notification_type integer NOT NULL,
    recurrences text NOT NULL,
    "time" time without time zone NOT NULL,
    last_sent timestamp with time zone,
    recipients_id integer NOT NULL,
    test_lists_id integer,
    units_id integer,
    send_empty boolean NOT NULL
);


ALTER TABLE public.notifications_qcreviewnotice OWNER TO postgres;

--
-- Name: notifications_qcreviewnotice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_qcreviewnotice_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_qcreviewnotice_id_seq OWNER TO postgres;

--
-- Name: notifications_qcreviewnotice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_qcreviewnotice_id_seq OWNED BY public.notifications_qcreviewnotice.id;


--
-- Name: notifications_qcschedulingnotice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications_qcschedulingnotice (
    id integer NOT NULL,
    notification_type integer NOT NULL,
    recurrences text NOT NULL,
    "time" time without time zone NOT NULL,
    future_days integer,
    recipients_id integer NOT NULL,
    test_lists_id integer,
    units_id integer,
    last_sent timestamp with time zone,
    send_empty boolean NOT NULL,
    CONSTRAINT notifications_qcschedulingnotice_future_days_check CHECK ((future_days >= 0))
);


ALTER TABLE public.notifications_qcschedulingnotice OWNER TO postgres;

--
-- Name: notifications_qcschedulingnotice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_qcschedulingnotice_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_qcschedulingnotice_id_seq OWNER TO postgres;

--
-- Name: notifications_qcschedulingnotice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_qcschedulingnotice_id_seq OWNED BY public.notifications_qcschedulingnotice.id;


--
-- Name: notifications_recipientgroup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications_recipientgroup (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    emails text NOT NULL
);


ALTER TABLE public.notifications_recipientgroup OWNER TO postgres;

--
-- Name: notifications_recipientgroup_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications_recipientgroup_groups (
    id integer NOT NULL,
    recipientgroup_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.notifications_recipientgroup_groups OWNER TO postgres;

--
-- Name: notifications_recipientgroup_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_recipientgroup_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_recipientgroup_groups_id_seq OWNER TO postgres;

--
-- Name: notifications_recipientgroup_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_recipientgroup_groups_id_seq OWNED BY public.notifications_recipientgroup_groups.id;


--
-- Name: notifications_recipientgroup_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_recipientgroup_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_recipientgroup_id_seq OWNER TO postgres;

--
-- Name: notifications_recipientgroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_recipientgroup_id_seq OWNED BY public.notifications_recipientgroup.id;


--
-- Name: notifications_recipientgroup_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications_recipientgroup_users (
    id integer NOT NULL,
    recipientgroup_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.notifications_recipientgroup_users OWNER TO postgres;

--
-- Name: notifications_recipientgroup_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_recipientgroup_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_recipientgroup_users_id_seq OWNER TO postgres;

--
-- Name: notifications_recipientgroup_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_recipientgroup_users_id_seq OWNED BY public.notifications_recipientgroup_users.id;


--
-- Name: notifications_serviceeventnotice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications_serviceeventnotice (
    id integer NOT NULL,
    notification_type character varying(128) NOT NULL,
    recipients_id integer NOT NULL,
    units_id integer
);


ALTER TABLE public.notifications_serviceeventnotice OWNER TO postgres;

--
-- Name: notifications_serviceeventnotice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_serviceeventnotice_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_serviceeventnotice_id_seq OWNER TO postgres;

--
-- Name: notifications_serviceeventnotice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_serviceeventnotice_id_seq OWNED BY public.notifications_serviceeventnotice.id;


--
-- Name: notifications_serviceeventreviewnotice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications_serviceeventreviewnotice (
    id integer NOT NULL,
    notification_type integer NOT NULL,
    send_empty boolean NOT NULL,
    recurrences text NOT NULL,
    "time" time without time zone NOT NULL,
    last_sent timestamp with time zone,
    recipients_id integer NOT NULL,
    units_id integer
);


ALTER TABLE public.notifications_serviceeventreviewnotice OWNER TO postgres;

--
-- Name: notifications_serviceeventreviewnotice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_serviceeventreviewnotice_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_serviceeventreviewnotice_id_seq OWNER TO postgres;

--
-- Name: notifications_serviceeventreviewnotice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_serviceeventreviewnotice_id_seq OWNED BY public.notifications_serviceeventreviewnotice.id;


--
-- Name: notifications_serviceeventschedulingnotice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications_serviceeventschedulingnotice (
    id integer NOT NULL,
    notification_type integer NOT NULL,
    send_empty boolean NOT NULL,
    recurrences text NOT NULL,
    "time" time without time zone NOT NULL,
    future_days integer,
    last_sent timestamp with time zone,
    recipients_id integer NOT NULL,
    units_id integer,
    CONSTRAINT notifications_serviceeventschedulingnotice_future_days_check CHECK ((future_days >= 0))
);


ALTER TABLE public.notifications_serviceeventschedulingnotice OWNER TO postgres;

--
-- Name: notifications_serviceeventschedulingnotice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_serviceeventschedulingnotice_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_serviceeventschedulingnotice_id_seq OWNER TO postgres;

--
-- Name: notifications_serviceeventschedulingnotice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_serviceeventschedulingnotice_id_seq OWNED BY public.notifications_serviceeventschedulingnotice.id;


--
-- Name: notifications_testlistgroup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications_testlistgroup (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.notifications_testlistgroup OWNER TO postgres;

--
-- Name: notifications_testlistgroup_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_testlistgroup_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_testlistgroup_id_seq OWNER TO postgres;

--
-- Name: notifications_testlistgroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_testlistgroup_id_seq OWNED BY public.notifications_testlistgroup.id;


--
-- Name: notifications_testlistgroup_test_lists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications_testlistgroup_test_lists (
    id integer NOT NULL,
    testlistgroup_id integer NOT NULL,
    testlist_id integer NOT NULL
);


ALTER TABLE public.notifications_testlistgroup_test_lists OWNER TO postgres;

--
-- Name: notifications_testlistgroup_test_lists_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_testlistgroup_test_lists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_testlistgroup_test_lists_id_seq OWNER TO postgres;

--
-- Name: notifications_testlistgroup_test_lists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_testlistgroup_test_lists_id_seq OWNED BY public.notifications_testlistgroup_test_lists.id;


--
-- Name: notifications_unitgroup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications_unitgroup (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.notifications_unitgroup OWNER TO postgres;

--
-- Name: notifications_unitgroup_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_unitgroup_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_unitgroup_id_seq OWNER TO postgres;

--
-- Name: notifications_unitgroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_unitgroup_id_seq OWNED BY public.notifications_unitgroup.id;


--
-- Name: notifications_unitgroup_units; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications_unitgroup_units (
    id integer NOT NULL,
    unitgroup_id integer NOT NULL,
    unit_id integer NOT NULL
);


ALTER TABLE public.notifications_unitgroup_units OWNER TO postgres;

--
-- Name: notifications_unitgroup_units_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_unitgroup_units_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_unitgroup_units_id_seq OWNER TO postgres;

--
-- Name: notifications_unitgroup_units_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_unitgroup_units_id_seq OWNED BY public.notifications_unitgroup_units.id;


--
-- Name: parts_contact; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parts_contact (
    id integer NOT NULL,
    first_name character varying(64) NOT NULL,
    last_name character varying(64) NOT NULL,
    email character varying(254) NOT NULL,
    phone_number character varying(31) NOT NULL,
    supplier_id integer NOT NULL
);


ALTER TABLE public.parts_contact OWNER TO postgres;

--
-- Name: parts_contact_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.parts_contact_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.parts_contact_id_seq OWNER TO postgres;

--
-- Name: parts_contact_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.parts_contact_id_seq OWNED BY public.parts_contact.id;


--
-- Name: parts_part; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parts_part (
    id integer NOT NULL,
    part_number character varying(32) NOT NULL,
    alt_part_number character varying(32),
    quantity_min integer NOT NULL,
    quantity_current integer NOT NULL,
    cost numeric(10,2),
    notes text,
    is_obsolete boolean NOT NULL,
    part_category_id integer,
    name character varying(255) NOT NULL,
    new_or_used character varying(12) NOT NULL,
    CONSTRAINT parts_part_quantity_current_check CHECK ((quantity_current >= 0)),
    CONSTRAINT parts_part_quantity_min_check CHECK ((quantity_min >= 0))
);


ALTER TABLE public.parts_part OWNER TO postgres;

--
-- Name: parts_part_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.parts_part_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.parts_part_id_seq OWNER TO postgres;

--
-- Name: parts_part_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.parts_part_id_seq OWNED BY public.parts_part.id;


--
-- Name: parts_partcategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parts_partcategory (
    id integer NOT NULL,
    name character varying(64) NOT NULL
);


ALTER TABLE public.parts_partcategory OWNER TO postgres;

--
-- Name: parts_partcategory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.parts_partcategory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.parts_partcategory_id_seq OWNER TO postgres;

--
-- Name: parts_partcategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.parts_partcategory_id_seq OWNED BY public.parts_partcategory.id;


--
-- Name: parts_partstoragecollection; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parts_partstoragecollection (
    id integer NOT NULL,
    quantity integer NOT NULL,
    part_id integer NOT NULL,
    storage_id integer NOT NULL
);


ALTER TABLE public.parts_partstoragecollection OWNER TO postgres;

--
-- Name: parts_partstoragecollection_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.parts_partstoragecollection_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.parts_partstoragecollection_id_seq OWNER TO postgres;

--
-- Name: parts_partstoragecollection_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.parts_partstoragecollection_id_seq OWNED BY public.parts_partstoragecollection.id;


--
-- Name: parts_partsuppliercollection; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parts_partsuppliercollection (
    id integer NOT NULL,
    part_number character varying(32),
    part_id integer NOT NULL,
    supplier_id integer NOT NULL
);


ALTER TABLE public.parts_partsuppliercollection OWNER TO postgres;

--
-- Name: parts_partsuppliercollection_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.parts_partsuppliercollection_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.parts_partsuppliercollection_id_seq OWNER TO postgres;

--
-- Name: parts_partsuppliercollection_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.parts_partsuppliercollection_id_seq OWNED BY public.parts_partsuppliercollection.id;


--
-- Name: parts_partused; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parts_partused (
    id integer NOT NULL,
    quantity integer NOT NULL,
    part_id integer NOT NULL,
    service_event_id integer NOT NULL,
    from_storage_id integer
);


ALTER TABLE public.parts_partused OWNER TO postgres;

--
-- Name: parts_partused_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.parts_partused_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.parts_partused_id_seq OWNER TO postgres;

--
-- Name: parts_partused_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.parts_partused_id_seq OWNED BY public.parts_partused.id;


--
-- Name: parts_room; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parts_room (
    id integer NOT NULL,
    name character varying(32) NOT NULL,
    site_id integer
);


ALTER TABLE public.parts_room OWNER TO postgres;

--
-- Name: parts_room_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.parts_room_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.parts_room_id_seq OWNER TO postgres;

--
-- Name: parts_room_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.parts_room_id_seq OWNED BY public.parts_room.id;


--
-- Name: parts_storage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parts_storage (
    id integer NOT NULL,
    location character varying(32),
    description text,
    room_id integer
);


ALTER TABLE public.parts_storage OWNER TO postgres;

--
-- Name: parts_storage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.parts_storage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.parts_storage_id_seq OWNER TO postgres;

--
-- Name: parts_storage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.parts_storage_id_seq OWNED BY public.parts_storage.id;


--
-- Name: parts_supplier; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parts_supplier (
    id integer NOT NULL,
    name character varying(32) NOT NULL,
    notes text,
    address text NOT NULL,
    phone_number character varying(31) NOT NULL,
    website character varying(200) NOT NULL
);


ALTER TABLE public.parts_supplier OWNER TO postgres;

--
-- Name: parts_supplier_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.parts_supplier_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.parts_supplier_id_seq OWNER TO postgres;

--
-- Name: parts_supplier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.parts_supplier_id_seq OWNED BY public.parts_supplier.id;


--
-- Name: qa_autoreviewrule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_autoreviewrule (
    id integer NOT NULL,
    pass_fail character varying(15) NOT NULL,
    status_id integer NOT NULL
);


ALTER TABLE public.qa_autoreviewrule OWNER TO postgres;

--
-- Name: qa_autoreviewrule_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_autoreviewrule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.qa_autoreviewrule_id_seq OWNER TO postgres;

--
-- Name: qa_autoreviewrule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_autoreviewrule_id_seq OWNED BY public.qa_autoreviewrule.id;


--
-- Name: qa_autoreviewruleset; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_autoreviewruleset (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    is_default boolean NOT NULL
);


ALTER TABLE public.qa_autoreviewruleset OWNER TO postgres;

--
-- Name: qa_autoreviewruleset_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_autoreviewruleset_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.qa_autoreviewruleset_id_seq OWNER TO postgres;

--
-- Name: qa_autoreviewruleset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_autoreviewruleset_id_seq OWNED BY public.qa_autoreviewruleset.id;


--
-- Name: qa_autoreviewruleset_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_autoreviewruleset_rules (
    id integer NOT NULL,
    autoreviewruleset_id integer NOT NULL,
    autoreviewrule_id integer NOT NULL
);


ALTER TABLE public.qa_autoreviewruleset_rules OWNER TO postgres;

--
-- Name: qa_autoreviewruleset_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_autoreviewruleset_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.qa_autoreviewruleset_rules_id_seq OWNER TO postgres;

--
-- Name: qa_autoreviewruleset_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_autoreviewruleset_rules_id_seq OWNED BY public.qa_autoreviewruleset_rules.id;


--
-- Name: qa_autosave; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_autosave (
    id integer NOT NULL,
    work_started timestamp with time zone,
    work_completed timestamp with time zone,
    day integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    data text NOT NULL,
    created_by_id integer NOT NULL,
    modified_by_id integer NOT NULL,
    test_list_id integer NOT NULL,
    unit_test_collection_id integer NOT NULL,
    test_list_instance_id integer
);


ALTER TABLE public.qa_autosave OWNER TO postgres;

--
-- Name: qa_autosave_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_autosave_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.qa_autosave_id_seq OWNER TO postgres;

--
-- Name: qa_autosave_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_autosave_id_seq OWNED BY public.qa_autosave.id;


--
-- Name: qa_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_category (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text NOT NULL,
    level integer NOT NULL,
    lft integer NOT NULL,
    parent_id integer,
    rght integer NOT NULL,
    tree_id integer NOT NULL,
    CONSTRAINT qa_category_level_check CHECK ((level >= 0)),
    CONSTRAINT qa_category_lft_check CHECK ((lft >= 0)),
    CONSTRAINT qa_category_rght_check CHECK ((rght >= 0)),
    CONSTRAINT qa_category_tree_id_check CHECK ((tree_id >= 0))
);


ALTER TABLE public.qa_category OWNER TO postgres;

--
-- Name: qa_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.qa_category_id_seq OWNER TO postgres;

--
-- Name: qa_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_category_id_seq OWNED BY public.qa_category.id;


--
-- Name: qa_frequency; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_frequency (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    slug character varying(50) NOT NULL,
    nominal_interval integer NOT NULL,
    recurrences text NOT NULL,
    window_end integer NOT NULL,
    window_start integer,
    CONSTRAINT qa_frequency_nominal_interval_check CHECK ((nominal_interval >= 0)),
    CONSTRAINT qa_frequency_window_end_check CHECK ((window_end >= 0)),
    CONSTRAINT qa_frequency_window_start_check CHECK ((window_start >= 0))
);


ALTER TABLE public.qa_frequency OWNER TO postgres;

--
-- Name: qa_frequency_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_frequency_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.qa_frequency_id_seq OWNER TO postgres;

--
-- Name: qa_frequency_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_frequency_id_seq OWNED BY public.qa_frequency.id;


--
-- Name: qa_reference; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_reference (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(15) NOT NULL,
    value double precision NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    created_by_id integer NOT NULL,
    modified_by_id integer NOT NULL
);


ALTER TABLE public.qa_reference OWNER TO postgres;

--
-- Name: qa_reference_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_reference_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.qa_reference_id_seq OWNER TO postgres;

--
-- Name: qa_reference_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_reference_id_seq OWNED BY public.qa_reference.id;


--
-- Name: qa_sublist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_sublist (
    id integer NOT NULL,
    "order" integer NOT NULL,
    child_id integer NOT NULL,
    parent_id integer NOT NULL,
    outline boolean NOT NULL
);


ALTER TABLE public.qa_sublist OWNER TO postgres;

--
-- Name: qa_sublist_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_sublist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.qa_sublist_id_seq OWNER TO postgres;

--
-- Name: qa_sublist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_sublist_id_seq OWNED BY public.qa_sublist.id;


--
-- Name: qa_test; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_test (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(128) NOT NULL,
    description text,
    procedure character varying(512),
    chart_visibility boolean NOT NULL,
    type character varying(10) NOT NULL,
    hidden boolean NOT NULL,
    skip_without_comment boolean NOT NULL,
    display_image boolean NOT NULL,
    choices character varying(2048),
    constant_value double precision,
    calculation_procedure text,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    category_id integer NOT NULL,
    created_by_id integer NOT NULL,
    modified_by_id integer NOT NULL,
    formatting character varying(10) NOT NULL,
    flag_when boolean,
    autoreviewruleset_id integer,
    display_name character varying(255) NOT NULL,
    wrap_high double precision,
    wrap_low double precision,
    require_comment boolean NOT NULL
);


ALTER TABLE public.qa_test OWNER TO postgres;

--
-- Name: qa_test_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_test_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.qa_test_id_seq OWNER TO postgres;

--
-- Name: qa_test_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_test_id_seq OWNED BY public.qa_test.id;


--
-- Name: qa_testinstance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_testinstance (
    id integer NOT NULL,
    review_date timestamp with time zone,
    pass_fail character varying(20) NOT NULL,
    value double precision,
    string_value text,
    skipped boolean NOT NULL,
    comment text,
    work_started timestamp with time zone NOT NULL,
    work_completed timestamp with time zone NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    created_by_id integer NOT NULL,
    modified_by_id integer NOT NULL,
    reference_id integer,
    reviewed_by_id integer,
    status_id integer NOT NULL,
    test_list_instance_id integer NOT NULL,
    tolerance_id integer,
    unit_test_info_id integer NOT NULL,
    "order" integer NOT NULL,
    date_value date,
    datetime_value timestamp with time zone,
    json_value text,
    CONSTRAINT qa_testinstance_order_check CHECK (("order" >= 0))
);


ALTER TABLE public.qa_testinstance OWNER TO postgres;

--
-- Name: qa_testinstance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_testinstance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.qa_testinstance_id_seq OWNER TO postgres;

--
-- Name: qa_testinstance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_testinstance_id_seq OWNED BY public.qa_testinstance.id;


--
-- Name: qa_testinstancestatus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_testinstancestatus (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    slug character varying(50) NOT NULL,
    description text,
    is_default boolean NOT NULL,
    requires_review boolean NOT NULL,
    export_by_default boolean NOT NULL,
    valid boolean NOT NULL,
    colour character varying(22) NOT NULL
);


ALTER TABLE public.qa_testinstancestatus OWNER TO postgres;

--
-- Name: qa_testinstancestatus_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_testinstancestatus_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.qa_testinstancestatus_id_seq OWNER TO postgres;

--
-- Name: qa_testinstancestatus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_testinstancestatus_id_seq OWNED BY public.qa_testinstancestatus.id;


--
-- Name: qa_testlist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_testlist (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    warning_message character varying(255) NOT NULL,
    created_by_id integer NOT NULL,
    modified_by_id integer NOT NULL,
    javascript text
);


ALTER TABLE public.qa_testlist OWNER TO postgres;

--
-- Name: qa_testlist_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_testlist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.qa_testlist_id_seq OWNER TO postgres;

--
-- Name: qa_testlist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_testlist_id_seq OWNED BY public.qa_testlist.id;


--
-- Name: qa_testlistcycle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_testlistcycle (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    drop_down_label character varying(128) NOT NULL,
    day_option_text character varying(8) NOT NULL,
    created_by_id integer NOT NULL,
    modified_by_id integer NOT NULL,
    javascript text
);


ALTER TABLE public.qa_testlistcycle OWNER TO postgres;

--
-- Name: qa_testlistcycle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_testlistcycle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.qa_testlistcycle_id_seq OWNER TO postgres;

--
-- Name: qa_testlistcycle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_testlistcycle_id_seq OWNED BY public.qa_testlistcycle.id;


--
-- Name: qa_testlistcyclemembership; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_testlistcyclemembership (
    id integer NOT NULL,
    "order" integer NOT NULL,
    cycle_id integer NOT NULL,
    test_list_id integer NOT NULL
);


ALTER TABLE public.qa_testlistcyclemembership OWNER TO postgres;

--
-- Name: qa_testlistcyclemembership_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_testlistcyclemembership_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.qa_testlistcyclemembership_id_seq OWNER TO postgres;

--
-- Name: qa_testlistcyclemembership_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_testlistcyclemembership_id_seq OWNED BY public.qa_testlistcyclemembership.id;


--
-- Name: qa_testlistinstance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_testlistinstance (
    id integer NOT NULL,
    work_started timestamp with time zone NOT NULL,
    work_completed timestamp with time zone,
    in_progress boolean NOT NULL,
    reviewed timestamp with time zone,
    all_reviewed boolean NOT NULL,
    day integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    created_by_id integer NOT NULL,
    modified_by_id integer NOT NULL,
    reviewed_by_id integer,
    test_list_id integer NOT NULL,
    unit_test_collection_id integer NOT NULL,
    due_date timestamp with time zone,
    flagged boolean NOT NULL,
    include_for_scheduling boolean NOT NULL,
    user_key character varying(255)
);


ALTER TABLE public.qa_testlistinstance OWNER TO postgres;

--
-- Name: qa_testlistinstance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_testlistinstance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.qa_testlistinstance_id_seq OWNER TO postgres;

--
-- Name: qa_testlistinstance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_testlistinstance_id_seq OWNED BY public.qa_testlistinstance.id;


--
-- Name: qa_testlistmembership; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_testlistmembership (
    id integer NOT NULL,
    "order" integer NOT NULL,
    test_id integer NOT NULL,
    test_list_id integer NOT NULL
);


ALTER TABLE public.qa_testlistmembership OWNER TO postgres;

--
-- Name: qa_testlistmembership_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_testlistmembership_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.qa_testlistmembership_id_seq OWNER TO postgres;

--
-- Name: qa_testlistmembership_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_testlistmembership_id_seq OWNED BY public.qa_testlistmembership.id;


--
-- Name: qa_tolerance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_tolerance (
    id integer NOT NULL,
    type character varying(20) NOT NULL,
    act_low double precision,
    tol_low double precision,
    tol_high double precision,
    act_high double precision,
    mc_pass_choices character varying(2048) NOT NULL,
    mc_tol_choices character varying(2048) NOT NULL,
    created_date timestamp with time zone NOT NULL,
    modified_date timestamp with time zone NOT NULL,
    created_by_id integer NOT NULL,
    modified_by_id integer NOT NULL,
    bool_warning_only boolean NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.qa_tolerance OWNER TO postgres;

--
-- Name: qa_tolerance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_tolerance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.qa_tolerance_id_seq OWNER TO postgres;

--
-- Name: qa_tolerance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_tolerance_id_seq OWNED BY public.qa_tolerance.id;


--
-- Name: qa_unittestcollection; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_unittestcollection (
    id integer NOT NULL,
    due_date timestamp with time zone,
    auto_schedule boolean NOT NULL,
    active boolean NOT NULL,
    object_id integer NOT NULL,
    assigned_to_id integer,
    content_type_id integer NOT NULL,
    frequency_id integer,
    last_instance_id integer,
    unit_id integer NOT NULL,
    name character varying(255) NOT NULL,
    CONSTRAINT qa_unittestcollection_object_id_check CHECK ((object_id >= 0))
);


ALTER TABLE public.qa_unittestcollection OWNER TO postgres;

--
-- Name: qa_unittestcollection_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_unittestcollection_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.qa_unittestcollection_id_seq OWNER TO postgres;

--
-- Name: qa_unittestcollection_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_unittestcollection_id_seq OWNED BY public.qa_unittestcollection.id;


--
-- Name: qa_unittestcollection_visible_to; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_unittestcollection_visible_to (
    id integer NOT NULL,
    unittestcollection_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.qa_unittestcollection_visible_to OWNER TO postgres;

--
-- Name: qa_unittestcollection_visible_to_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_unittestcollection_visible_to_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.qa_unittestcollection_visible_to_id_seq OWNER TO postgres;

--
-- Name: qa_unittestcollection_visible_to_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_unittestcollection_visible_to_id_seq OWNED BY public.qa_unittestcollection_visible_to.id;


--
-- Name: qa_unittestinfo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_unittestinfo (
    id integer NOT NULL,
    active boolean NOT NULL,
    assigned_to_id integer,
    reference_id integer,
    test_id integer NOT NULL,
    tolerance_id integer,
    unit_id integer NOT NULL
);


ALTER TABLE public.qa_unittestinfo OWNER TO postgres;

--
-- Name: qa_unittestinfo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_unittestinfo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.qa_unittestinfo_id_seq OWNER TO postgres;

--
-- Name: qa_unittestinfo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_unittestinfo_id_seq OWNED BY public.qa_unittestinfo.id;


--
-- Name: qa_unittestinfochange; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_unittestinfochange (
    id integer NOT NULL,
    reference_changed boolean NOT NULL,
    tolerance_changed boolean NOT NULL,
    comment text NOT NULL,
    changed timestamp with time zone NOT NULL,
    changed_by_id integer NOT NULL,
    reference_id integer,
    tolerance_id integer,
    unit_test_info_id integer NOT NULL
);


ALTER TABLE public.qa_unittestinfochange OWNER TO postgres;

--
-- Name: qa_unittestinfochange_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_unittestinfochange_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.qa_unittestinfochange_id_seq OWNER TO postgres;

--
-- Name: qa_unittestinfochange_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_unittestinfochange_id_seq OWNED BY public.qa_unittestinfochange.id;


--
-- Name: qatrack_cache_table; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qatrack_cache_table (
    cache_key character varying(255) NOT NULL,
    value text NOT NULL,
    expires timestamp with time zone NOT NULL
);


ALTER TABLE public.qatrack_cache_table OWNER TO postgres;

--
-- Name: recurrence_date; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recurrence_date (
    id integer NOT NULL,
    mode boolean NOT NULL,
    dt timestamp with time zone NOT NULL,
    recurrence_id integer NOT NULL
);


ALTER TABLE public.recurrence_date OWNER TO postgres;

--
-- Name: recurrence_date_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recurrence_date_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recurrence_date_id_seq OWNER TO postgres;

--
-- Name: recurrence_date_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recurrence_date_id_seq OWNED BY public.recurrence_date.id;


--
-- Name: recurrence_param; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recurrence_param (
    id integer NOT NULL,
    param character varying(16) NOT NULL,
    value integer NOT NULL,
    index integer NOT NULL,
    rule_id integer NOT NULL
);


ALTER TABLE public.recurrence_param OWNER TO postgres;

--
-- Name: recurrence_param_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recurrence_param_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recurrence_param_id_seq OWNER TO postgres;

--
-- Name: recurrence_param_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recurrence_param_id_seq OWNED BY public.recurrence_param.id;


--
-- Name: recurrence_recurrence; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recurrence_recurrence (
    id integer NOT NULL,
    dtstart timestamp with time zone,
    dtend timestamp with time zone
);


ALTER TABLE public.recurrence_recurrence OWNER TO postgres;

--
-- Name: recurrence_recurrence_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recurrence_recurrence_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recurrence_recurrence_id_seq OWNER TO postgres;

--
-- Name: recurrence_recurrence_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recurrence_recurrence_id_seq OWNED BY public.recurrence_recurrence.id;


--
-- Name: recurrence_rule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recurrence_rule (
    id integer NOT NULL,
    mode boolean NOT NULL,
    freq integer NOT NULL,
    "interval" integer NOT NULL,
    wkst integer,
    count integer,
    until timestamp with time zone,
    recurrence_id integer NOT NULL,
    CONSTRAINT recurrence_rule_count_check CHECK ((count >= 0)),
    CONSTRAINT recurrence_rule_freq_check CHECK ((freq >= 0)),
    CONSTRAINT recurrence_rule_interval_check CHECK (("interval" >= 0)),
    CONSTRAINT recurrence_rule_wkst_check CHECK ((wkst >= 0))
);


ALTER TABLE public.recurrence_rule OWNER TO postgres;

--
-- Name: recurrence_rule_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recurrence_rule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recurrence_rule_id_seq OWNER TO postgres;

--
-- Name: recurrence_rule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recurrence_rule_id_seq OWNED BY public.recurrence_rule.id;


--
-- Name: reports_reportnote; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reports_reportnote (
    id integer NOT NULL,
    heading text NOT NULL,
    content text NOT NULL,
    report_id integer NOT NULL
);


ALTER TABLE public.reports_reportnote OWNER TO postgres;

--
-- Name: reports_reportnote_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reports_reportnote_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reports_reportnote_id_seq OWNER TO postgres;

--
-- Name: reports_reportnote_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reports_reportnote_id_seq OWNED BY public.reports_reportnote.id;


--
-- Name: reports_reportschedule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reports_reportschedule (
    id integer NOT NULL,
    schedule text NOT NULL,
    "time" time without time zone NOT NULL,
    emails text NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    created_by_id integer NOT NULL,
    modified_by_id integer NOT NULL,
    report_id integer NOT NULL,
    last_sent timestamp with time zone
);


ALTER TABLE public.reports_reportschedule OWNER TO postgres;

--
-- Name: reports_reportschedule_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reports_reportschedule_groups (
    id integer NOT NULL,
    reportschedule_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.reports_reportschedule_groups OWNER TO postgres;

--
-- Name: reports_reportschedule_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reports_reportschedule_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reports_reportschedule_groups_id_seq OWNER TO postgres;

--
-- Name: reports_reportschedule_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reports_reportschedule_groups_id_seq OWNED BY public.reports_reportschedule_groups.id;


--
-- Name: reports_reportschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reports_reportschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reports_reportschedule_id_seq OWNER TO postgres;

--
-- Name: reports_reportschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reports_reportschedule_id_seq OWNED BY public.reports_reportschedule.id;


--
-- Name: reports_reportschedule_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reports_reportschedule_users (
    id integer NOT NULL,
    reportschedule_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.reports_reportschedule_users OWNER TO postgres;

--
-- Name: reports_reportschedule_users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reports_reportschedule_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reports_reportschedule_users_id_seq OWNER TO postgres;

--
-- Name: reports_reportschedule_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reports_reportschedule_users_id_seq OWNED BY public.reports_reportschedule_users.id;


--
-- Name: reports_savedreport; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reports_savedreport (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    report_type character varying(128) NOT NULL,
    report_format character varying(8) NOT NULL,
    include_signature boolean NOT NULL,
    filters text NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    created_by_id integer NOT NULL,
    modified_by_id integer NOT NULL
);


ALTER TABLE public.reports_savedreport OWNER TO postgres;

--
-- Name: reports_savedreport_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reports_savedreport_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reports_savedreport_id_seq OWNER TO postgres;

--
-- Name: reports_savedreport_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reports_savedreport_id_seq OWNED BY public.reports_savedreport.id;


--
-- Name: reports_savedreport_visible_to; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reports_savedreport_visible_to (
    id integer NOT NULL,
    savedreport_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.reports_savedreport_visible_to OWNER TO postgres;

--
-- Name: reports_savedreport_visible_to_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reports_savedreport_visible_to_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reports_savedreport_visible_to_id_seq OWNER TO postgres;

--
-- Name: reports_savedreport_visible_to_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reports_savedreport_visible_to_id_seq OWNED BY public.reports_savedreport_visible_to.id;


--
-- Name: service_log_grouplinker; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_log_grouplinker (
    id integer NOT NULL,
    name character varying(64) NOT NULL,
    description text,
    help_text character varying(64),
    group_id integer,
    multiple boolean NOT NULL,
    required boolean NOT NULL
);


ALTER TABLE public.service_log_grouplinker OWNER TO postgres;

--
-- Name: service_log_grouplinker_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.service_log_grouplinker_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_log_grouplinker_id_seq OWNER TO postgres;

--
-- Name: service_log_grouplinker_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.service_log_grouplinker_id_seq OWNED BY public.service_log_grouplinker.id;


--
-- Name: service_log_grouplinkerinstance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_log_grouplinkerinstance (
    id integer NOT NULL,
    datetime_linked timestamp with time zone NOT NULL,
    group_linker_id integer NOT NULL,
    service_event_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.service_log_grouplinkerinstance OWNER TO postgres;

--
-- Name: service_log_grouplinkerinstance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.service_log_grouplinkerinstance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_log_grouplinkerinstance_id_seq OWNER TO postgres;

--
-- Name: service_log_grouplinkerinstance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.service_log_grouplinkerinstance_id_seq OWNED BY public.service_log_grouplinkerinstance.id;


--
-- Name: service_log_hours; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_log_hours (
    id integer NOT NULL,
    "time" interval NOT NULL,
    service_event_id integer NOT NULL,
    third_party_id integer,
    user_id integer
);


ALTER TABLE public.service_log_hours OWNER TO postgres;

--
-- Name: service_log_hours_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.service_log_hours_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_log_hours_id_seq OWNER TO postgres;

--
-- Name: service_log_hours_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.service_log_hours_id_seq OWNED BY public.service_log_hours.id;


--
-- Name: service_log_returntoserviceqa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_log_returntoserviceqa (
    id integer NOT NULL,
    datetime_assigned timestamp with time zone NOT NULL,
    service_event_id integer NOT NULL,
    test_list_instance_id integer,
    unit_test_collection_id integer NOT NULL,
    user_assigned_by_id integer NOT NULL
);


ALTER TABLE public.service_log_returntoserviceqa OWNER TO postgres;

--
-- Name: service_log_qafollowup_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.service_log_qafollowup_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_log_qafollowup_id_seq OWNER TO postgres;

--
-- Name: service_log_qafollowup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.service_log_qafollowup_id_seq OWNED BY public.service_log_returntoserviceqa.id;


--
-- Name: service_log_servicearea; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_log_servicearea (
    id integer NOT NULL,
    name character varying(32) NOT NULL
);


ALTER TABLE public.service_log_servicearea OWNER TO postgres;

--
-- Name: service_log_servicearea_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.service_log_servicearea_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_log_servicearea_id_seq OWNER TO postgres;

--
-- Name: service_log_servicearea_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.service_log_servicearea_id_seq OWNED BY public.service_log_servicearea.id;


--
-- Name: service_log_serviceevent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_log_serviceevent (
    id integer NOT NULL,
    datetime_status_changed timestamp with time zone,
    datetime_created timestamp with time zone NOT NULL,
    datetime_service timestamp with time zone NOT NULL,
    datetime_modified timestamp with time zone,
    safety_precautions text,
    problem_description text NOT NULL,
    work_description text,
    duration_service_time interval,
    duration_lost_time interval,
    is_review_required boolean NOT NULL,
    service_status_id integer NOT NULL,
    service_type_id integer NOT NULL,
    unit_service_area_id integer NOT NULL,
    user_created_by_id integer NOT NULL,
    user_modified_by_id integer,
    user_status_changed_by_id integer,
    test_list_instance_initiated_by_id integer,
    is_active boolean NOT NULL,
    due_date timestamp with time zone,
    include_for_scheduling boolean NOT NULL,
    service_event_schedule_id integer,
    service_event_template_id integer
);


ALTER TABLE public.service_log_serviceevent OWNER TO postgres;

--
-- Name: service_log_serviceevent_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.service_log_serviceevent_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_log_serviceevent_id_seq OWNER TO postgres;

--
-- Name: service_log_serviceevent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.service_log_serviceevent_id_seq OWNED BY public.service_log_serviceevent.id;


--
-- Name: service_log_serviceevent_service_event_related; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_log_serviceevent_service_event_related (
    id integer NOT NULL,
    from_serviceevent_id integer NOT NULL,
    to_serviceevent_id integer NOT NULL
);


ALTER TABLE public.service_log_serviceevent_service_event_related OWNER TO postgres;

--
-- Name: service_log_serviceevent_service_event_related_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.service_log_serviceevent_service_event_related_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_log_serviceevent_service_event_related_id_seq OWNER TO postgres;

--
-- Name: service_log_serviceevent_service_event_related_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.service_log_serviceevent_service_event_related_id_seq OWNED BY public.service_log_serviceevent_service_event_related.id;


--
-- Name: service_log_serviceeventschedule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_log_serviceeventschedule (
    id integer NOT NULL,
    due_date timestamp with time zone,
    auto_schedule boolean NOT NULL,
    active boolean NOT NULL,
    assigned_to_id integer,
    frequency_id integer,
    last_instance_id integer,
    service_event_template_id integer NOT NULL,
    unit_service_area_id integer NOT NULL
);


ALTER TABLE public.service_log_serviceeventschedule OWNER TO postgres;

--
-- Name: service_log_serviceeventschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.service_log_serviceeventschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_log_serviceeventschedule_id_seq OWNER TO postgres;

--
-- Name: service_log_serviceeventschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.service_log_serviceeventschedule_id_seq OWNED BY public.service_log_serviceeventschedule.id;


--
-- Name: service_log_serviceeventschedule_visible_to; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_log_serviceeventschedule_visible_to (
    id integer NOT NULL,
    serviceeventschedule_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.service_log_serviceeventschedule_visible_to OWNER TO postgres;

--
-- Name: service_log_serviceeventschedule_visible_to_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.service_log_serviceeventschedule_visible_to_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_log_serviceeventschedule_visible_to_id_seq OWNER TO postgres;

--
-- Name: service_log_serviceeventschedule_visible_to_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.service_log_serviceeventschedule_visible_to_id_seq OWNED BY public.service_log_serviceeventschedule_visible_to.id;


--
-- Name: service_log_serviceeventstatus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_log_serviceeventstatus (
    id integer NOT NULL,
    name character varying(32) NOT NULL,
    is_default boolean NOT NULL,
    is_review_required boolean NOT NULL,
    rts_qa_must_be_reviewed boolean NOT NULL,
    description text,
    colour character varying(22) NOT NULL,
    "order" integer NOT NULL,
    CONSTRAINT service_log_serviceeventstatus_order_check CHECK (("order" >= 0))
);


ALTER TABLE public.service_log_serviceeventstatus OWNER TO postgres;

--
-- Name: service_log_serviceeventstatus_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.service_log_serviceeventstatus_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_log_serviceeventstatus_id_seq OWNER TO postgres;

--
-- Name: service_log_serviceeventstatus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.service_log_serviceeventstatus_id_seq OWNED BY public.service_log_serviceeventstatus.id;


--
-- Name: service_log_serviceeventtemplate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_log_serviceeventtemplate (
    id integer NOT NULL,
    problem_description text,
    work_description text,
    is_review_required boolean NOT NULL,
    name character varying(255) NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    created_by_id integer NOT NULL,
    modified_by_id integer NOT NULL,
    service_area_id integer,
    service_type_id integer
);


ALTER TABLE public.service_log_serviceeventtemplate OWNER TO postgres;

--
-- Name: service_log_serviceeventtemplate_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.service_log_serviceeventtemplate_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_log_serviceeventtemplate_id_seq OWNER TO postgres;

--
-- Name: service_log_serviceeventtemplate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.service_log_serviceeventtemplate_id_seq OWNED BY public.service_log_serviceeventtemplate.id;


--
-- Name: service_log_serviceeventtemplate_return_to_service_cycles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_log_serviceeventtemplate_return_to_service_cycles (
    id integer NOT NULL,
    serviceeventtemplate_id integer NOT NULL,
    testlistcycle_id integer NOT NULL
);


ALTER TABLE public.service_log_serviceeventtemplate_return_to_service_cycles OWNER TO postgres;

--
-- Name: service_log_serviceeventtemplate_return_to_service_cycle_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.service_log_serviceeventtemplate_return_to_service_cycle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_log_serviceeventtemplate_return_to_service_cycle_id_seq OWNER TO postgres;

--
-- Name: service_log_serviceeventtemplate_return_to_service_cycle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.service_log_serviceeventtemplate_return_to_service_cycle_id_seq OWNED BY public.service_log_serviceeventtemplate_return_to_service_cycles.id;


--
-- Name: service_log_serviceeventtemplate_return_to_service_test_lists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_log_serviceeventtemplate_return_to_service_test_lists (
    id integer NOT NULL,
    serviceeventtemplate_id integer NOT NULL,
    testlist_id integer NOT NULL
);


ALTER TABLE public.service_log_serviceeventtemplate_return_to_service_test_lists OWNER TO postgres;

--
-- Name: service_log_serviceeventtemplate_return_to_service_test__id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.service_log_serviceeventtemplate_return_to_service_test__id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_log_serviceeventtemplate_return_to_service_test__id_seq OWNER TO postgres;

--
-- Name: service_log_serviceeventtemplate_return_to_service_test__id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.service_log_serviceeventtemplate_return_to_service_test__id_seq OWNED BY public.service_log_serviceeventtemplate_return_to_service_test_lists.id;


--
-- Name: service_log_servicelog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_log_servicelog (
    id integer NOT NULL,
    log_type character varying(10) NOT NULL,
    extra_info text,
    datetime timestamp with time zone NOT NULL,
    service_event_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.service_log_servicelog OWNER TO postgres;

--
-- Name: service_log_servicelog_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.service_log_servicelog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_log_servicelog_id_seq OWNER TO postgres;

--
-- Name: service_log_servicelog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.service_log_servicelog_id_seq OWNED BY public.service_log_servicelog.id;


--
-- Name: service_log_servicetype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_log_servicetype (
    id integer NOT NULL,
    name character varying(32) NOT NULL,
    is_review_required boolean NOT NULL,
    is_active boolean NOT NULL,
    description text
);


ALTER TABLE public.service_log_servicetype OWNER TO postgres;

--
-- Name: service_log_servicetype_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.service_log_servicetype_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_log_servicetype_id_seq OWNER TO postgres;

--
-- Name: service_log_servicetype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.service_log_servicetype_id_seq OWNED BY public.service_log_servicetype.id;


--
-- Name: service_log_thirdparty; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_log_thirdparty (
    id integer NOT NULL,
    first_name character varying(32) NOT NULL,
    last_name character varying(32) NOT NULL,
    vendor_id integer NOT NULL
);


ALTER TABLE public.service_log_thirdparty OWNER TO postgres;

--
-- Name: service_log_thirdparty_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.service_log_thirdparty_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_log_thirdparty_id_seq OWNER TO postgres;

--
-- Name: service_log_thirdparty_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.service_log_thirdparty_id_seq OWNED BY public.service_log_thirdparty.id;


--
-- Name: service_log_unitservicearea; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_log_unitservicearea (
    id integer NOT NULL,
    service_area_id integer NOT NULL,
    unit_id integer NOT NULL,
    notes text
);


ALTER TABLE public.service_log_unitservicearea OWNER TO postgres;

--
-- Name: service_log_unitservicearea_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.service_log_unitservicearea_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_log_unitservicearea_id_seq OWNER TO postgres;

--
-- Name: service_log_unitservicearea_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.service_log_unitservicearea_id_seq OWNED BY public.service_log_unitservicearea.id;


--
-- Name: units_modality; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.units_modality (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.units_modality OWNER TO postgres;

--
-- Name: units_modality_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.units_modality_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.units_modality_id_seq OWNER TO postgres;

--
-- Name: units_modality_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.units_modality_id_seq OWNED BY public.units_modality.id;


--
-- Name: units_site; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.units_site (
    id integer NOT NULL,
    name character varying(64) NOT NULL,
    slug character varying(50) NOT NULL
);


ALTER TABLE public.units_site OWNER TO postgres;

--
-- Name: units_site_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.units_site_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.units_site_id_seq OWNER TO postgres;

--
-- Name: units_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.units_site_id_seq OWNED BY public.units_site.id;


--
-- Name: units_unit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.units_unit (
    id integer NOT NULL,
    number integer NOT NULL,
    name character varying(256) NOT NULL,
    serial_number character varying(256),
    location character varying(256),
    install_date date,
    type_id integer NOT NULL,
    active boolean NOT NULL,
    date_acceptance date NOT NULL,
    site_id integer,
    is_serviceable boolean NOT NULL,
    CONSTRAINT units_unit_number_check CHECK ((number >= 0))
);


ALTER TABLE public.units_unit OWNER TO postgres;

--
-- Name: units_unit_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.units_unit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.units_unit_id_seq OWNER TO postgres;

--
-- Name: units_unit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.units_unit_id_seq OWNED BY public.units_unit.id;


--
-- Name: units_unit_modalities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.units_unit_modalities (
    id integer NOT NULL,
    unit_id integer NOT NULL,
    modality_id integer NOT NULL
);


ALTER TABLE public.units_unit_modalities OWNER TO postgres;

--
-- Name: units_unit_modalities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.units_unit_modalities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.units_unit_modalities_id_seq OWNER TO postgres;

--
-- Name: units_unit_modalities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.units_unit_modalities_id_seq OWNED BY public.units_unit_modalities.id;


--
-- Name: units_unitavailabletime; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.units_unitavailabletime (
    id integer NOT NULL,
    date_changed date NOT NULL,
    hours_monday interval NOT NULL,
    hours_tuesday interval NOT NULL,
    hours_wednesday interval NOT NULL,
    hours_thursday interval NOT NULL,
    hours_friday interval NOT NULL,
    hours_saturday interval NOT NULL,
    hours_sunday interval NOT NULL,
    unit_id integer NOT NULL
);


ALTER TABLE public.units_unitavailabletime OWNER TO postgres;

--
-- Name: units_unitavailabletime_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.units_unitavailabletime_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.units_unitavailabletime_id_seq OWNER TO postgres;

--
-- Name: units_unitavailabletime_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.units_unitavailabletime_id_seq OWNED BY public.units_unitavailabletime.id;


--
-- Name: units_unitavailabletimeedit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.units_unitavailabletimeedit (
    id integer NOT NULL,
    name character varying(64),
    date date NOT NULL,
    hours interval NOT NULL,
    unit_id integer NOT NULL
);


ALTER TABLE public.units_unitavailabletimeedit OWNER TO postgres;

--
-- Name: units_unitavailabletimeedit_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.units_unitavailabletimeedit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.units_unitavailabletimeedit_id_seq OWNER TO postgres;

--
-- Name: units_unitavailabletimeedit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.units_unitavailabletimeedit_id_seq OWNED BY public.units_unitavailabletimeedit.id;


--
-- Name: units_unitclass; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.units_unitclass (
    id integer NOT NULL,
    name character varying(64) NOT NULL
);


ALTER TABLE public.units_unitclass OWNER TO postgres;

--
-- Name: units_unitclass_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.units_unitclass_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.units_unitclass_id_seq OWNER TO postgres;

--
-- Name: units_unitclass_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.units_unitclass_id_seq OWNED BY public.units_unitclass.id;


--
-- Name: units_unittype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.units_unittype (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    model character varying(50),
    vendor_id integer,
    unit_class_id integer,
    collapse boolean NOT NULL
);


ALTER TABLE public.units_unittype OWNER TO postgres;

--
-- Name: units_unittype_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.units_unittype_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.units_unittype_id_seq OWNER TO postgres;

--
-- Name: units_unittype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.units_unittype_id_seq OWNED BY public.units_unittype.id;


--
-- Name: units_vendor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.units_vendor (
    id integer NOT NULL,
    name character varying(64) NOT NULL,
    notes text
);


ALTER TABLE public.units_vendor OWNER TO postgres;

--
-- Name: units_vendor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.units_vendor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.units_vendor_id_seq OWNER TO postgres;

--
-- Name: units_vendor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.units_vendor_id_seq OWNED BY public.units_vendor.id;


--
-- Name: accounts_activedirectorygroupmap id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_activedirectorygroupmap ALTER COLUMN id SET DEFAULT nextval('public.accounts_activedirectorygroupmap_id_seq'::regclass);


--
-- Name: accounts_activedirectorygroupmap_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_activedirectorygroupmap_groups ALTER COLUMN id SET DEFAULT nextval('public.accounts_activedirectorygroupmap_groups_id_seq'::regclass);


--
-- Name: accounts_defaultgroup id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_defaultgroup ALTER COLUMN id SET DEFAULT nextval('public.accounts_defaultgroup_id_seq'::regclass);


--
-- Name: attachments_attachment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments_attachment ALTER COLUMN id SET DEFAULT nextval('public.attachments_attachment_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: auth_user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: auth_user_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: auth_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: contacts_contact id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contacts_contact ALTER COLUMN id SET DEFAULT nextval('public.contacts_contact_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_comment_flags id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_comment_flags ALTER COLUMN id SET DEFAULT nextval('public.django_comment_flags_id_seq'::regclass);


--
-- Name: django_comments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_comments ALTER COLUMN id SET DEFAULT nextval('public.django_comments_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: django_q_ormq id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_q_ormq ALTER COLUMN id SET DEFAULT nextval('public.django_q_ormq_id_seq'::regclass);


--
-- Name: django_q_schedule id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_q_schedule ALTER COLUMN id SET DEFAULT nextval('public.django_q_schedule_id_seq'::regclass);


--
-- Name: django_site id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_site ALTER COLUMN id SET DEFAULT nextval('public.django_site_id_seq'::regclass);


--
-- Name: faults_fault id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_fault ALTER COLUMN id SET DEFAULT nextval('public.faults_fault_id_seq'::regclass);


--
-- Name: faults_fault_fault_types id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_fault_fault_types ALTER COLUMN id SET DEFAULT nextval('public.faults_fault_fault_types_id_seq'::regclass);


--
-- Name: faults_fault_related_service_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_fault_related_service_events ALTER COLUMN id SET DEFAULT nextval('public.faults_fault_related_service_events_id_seq'::regclass);


--
-- Name: faults_faultreviewgroup id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_faultreviewgroup ALTER COLUMN id SET DEFAULT nextval('public.faults_faultreviewgroup_id_seq'::regclass);


--
-- Name: faults_faultreviewinstance id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_faultreviewinstance ALTER COLUMN id SET DEFAULT nextval('public.faults_faultreviewinstance_id_seq'::regclass);


--
-- Name: faults_faulttype id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_faulttype ALTER COLUMN id SET DEFAULT nextval('public.faults_faulttype_id_seq'::regclass);


--
-- Name: issue_tracker_issue id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_tracker_issue ALTER COLUMN id SET DEFAULT nextval('public.issue_tracker_issue_id_seq'::regclass);


--
-- Name: issue_tracker_issue_issue_tags id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_tracker_issue_issue_tags ALTER COLUMN id SET DEFAULT nextval('public.issue_tracker_issue_issue_tags_id_seq'::regclass);


--
-- Name: issue_tracker_issuepriority id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_tracker_issuepriority ALTER COLUMN id SET DEFAULT nextval('public.issue_tracker_issuepriority_id_seq'::regclass);


--
-- Name: issue_tracker_issuestatus id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_tracker_issuestatus ALTER COLUMN id SET DEFAULT nextval('public.issue_tracker_issuestatus_id_seq'::regclass);


--
-- Name: issue_tracker_issuetag id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_tracker_issuetag ALTER COLUMN id SET DEFAULT nextval('public.issue_tracker_issuetag_id_seq'::regclass);


--
-- Name: issue_tracker_issuetype id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_tracker_issuetype ALTER COLUMN id SET DEFAULT nextval('public.issue_tracker_issuetype_id_seq'::regclass);


--
-- Name: notifications_faultnotice id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_faultnotice ALTER COLUMN id SET DEFAULT nextval('public.notifications_faultnotice_id_seq'::regclass);


--
-- Name: notifications_faultsreviewnotice id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_faultsreviewnotice ALTER COLUMN id SET DEFAULT nextval('public.notifications_faultsreviewnotice_id_seq'::regclass);


--
-- Name: notifications_partcategorygroup id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_partcategorygroup ALTER COLUMN id SET DEFAULT nextval('public.notifications_partcategorygroup_id_seq'::regclass);


--
-- Name: notifications_partcategorygroup_part_categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_partcategorygroup_part_categories ALTER COLUMN id SET DEFAULT nextval('public.notifications_partcategorygroup_part_categories_id_seq'::regclass);


--
-- Name: notifications_partnotice id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_partnotice ALTER COLUMN id SET DEFAULT nextval('public.notifications_partnotice_id_seq'::regclass);


--
-- Name: notifications_qccompletednotice id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_qccompletednotice ALTER COLUMN id SET DEFAULT nextval('public.notifications_qccompletednotice_id_seq'::regclass);


--
-- Name: notifications_qcreviewnotice id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_qcreviewnotice ALTER COLUMN id SET DEFAULT nextval('public.notifications_qcreviewnotice_id_seq'::regclass);


--
-- Name: notifications_qcschedulingnotice id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_qcschedulingnotice ALTER COLUMN id SET DEFAULT nextval('public.notifications_qcschedulingnotice_id_seq'::regclass);


--
-- Name: notifications_recipientgroup id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_recipientgroup ALTER COLUMN id SET DEFAULT nextval('public.notifications_recipientgroup_id_seq'::regclass);


--
-- Name: notifications_recipientgroup_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_recipientgroup_groups ALTER COLUMN id SET DEFAULT nextval('public.notifications_recipientgroup_groups_id_seq'::regclass);


--
-- Name: notifications_recipientgroup_users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_recipientgroup_users ALTER COLUMN id SET DEFAULT nextval('public.notifications_recipientgroup_users_id_seq'::regclass);


--
-- Name: notifications_serviceeventnotice id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_serviceeventnotice ALTER COLUMN id SET DEFAULT nextval('public.notifications_serviceeventnotice_id_seq'::regclass);


--
-- Name: notifications_serviceeventreviewnotice id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_serviceeventreviewnotice ALTER COLUMN id SET DEFAULT nextval('public.notifications_serviceeventreviewnotice_id_seq'::regclass);


--
-- Name: notifications_serviceeventschedulingnotice id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_serviceeventschedulingnotice ALTER COLUMN id SET DEFAULT nextval('public.notifications_serviceeventschedulingnotice_id_seq'::regclass);


--
-- Name: notifications_testlistgroup id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_testlistgroup ALTER COLUMN id SET DEFAULT nextval('public.notifications_testlistgroup_id_seq'::regclass);


--
-- Name: notifications_testlistgroup_test_lists id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_testlistgroup_test_lists ALTER COLUMN id SET DEFAULT nextval('public.notifications_testlistgroup_test_lists_id_seq'::regclass);


--
-- Name: notifications_unitgroup id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_unitgroup ALTER COLUMN id SET DEFAULT nextval('public.notifications_unitgroup_id_seq'::regclass);


--
-- Name: notifications_unitgroup_units id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_unitgroup_units ALTER COLUMN id SET DEFAULT nextval('public.notifications_unitgroup_units_id_seq'::regclass);


--
-- Name: parts_contact id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_contact ALTER COLUMN id SET DEFAULT nextval('public.parts_contact_id_seq'::regclass);


--
-- Name: parts_part id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_part ALTER COLUMN id SET DEFAULT nextval('public.parts_part_id_seq'::regclass);


--
-- Name: parts_partcategory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_partcategory ALTER COLUMN id SET DEFAULT nextval('public.parts_partcategory_id_seq'::regclass);


--
-- Name: parts_partstoragecollection id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_partstoragecollection ALTER COLUMN id SET DEFAULT nextval('public.parts_partstoragecollection_id_seq'::regclass);


--
-- Name: parts_partsuppliercollection id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_partsuppliercollection ALTER COLUMN id SET DEFAULT nextval('public.parts_partsuppliercollection_id_seq'::regclass);


--
-- Name: parts_partused id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_partused ALTER COLUMN id SET DEFAULT nextval('public.parts_partused_id_seq'::regclass);


--
-- Name: parts_room id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_room ALTER COLUMN id SET DEFAULT nextval('public.parts_room_id_seq'::regclass);


--
-- Name: parts_storage id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_storage ALTER COLUMN id SET DEFAULT nextval('public.parts_storage_id_seq'::regclass);


--
-- Name: parts_supplier id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_supplier ALTER COLUMN id SET DEFAULT nextval('public.parts_supplier_id_seq'::regclass);


--
-- Name: qa_autoreviewrule id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_autoreviewrule ALTER COLUMN id SET DEFAULT nextval('public.qa_autoreviewrule_id_seq'::regclass);


--
-- Name: qa_autoreviewruleset id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_autoreviewruleset ALTER COLUMN id SET DEFAULT nextval('public.qa_autoreviewruleset_id_seq'::regclass);


--
-- Name: qa_autoreviewruleset_rules id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_autoreviewruleset_rules ALTER COLUMN id SET DEFAULT nextval('public.qa_autoreviewruleset_rules_id_seq'::regclass);


--
-- Name: qa_autosave id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_autosave ALTER COLUMN id SET DEFAULT nextval('public.qa_autosave_id_seq'::regclass);


--
-- Name: qa_category id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_category ALTER COLUMN id SET DEFAULT nextval('public.qa_category_id_seq'::regclass);


--
-- Name: qa_frequency id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_frequency ALTER COLUMN id SET DEFAULT nextval('public.qa_frequency_id_seq'::regclass);


--
-- Name: qa_reference id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_reference ALTER COLUMN id SET DEFAULT nextval('public.qa_reference_id_seq'::regclass);


--
-- Name: qa_sublist id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_sublist ALTER COLUMN id SET DEFAULT nextval('public.qa_sublist_id_seq'::regclass);


--
-- Name: qa_test id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_test ALTER COLUMN id SET DEFAULT nextval('public.qa_test_id_seq'::regclass);


--
-- Name: qa_testinstance id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testinstance ALTER COLUMN id SET DEFAULT nextval('public.qa_testinstance_id_seq'::regclass);


--
-- Name: qa_testinstancestatus id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testinstancestatus ALTER COLUMN id SET DEFAULT nextval('public.qa_testinstancestatus_id_seq'::regclass);


--
-- Name: qa_testlist id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlist ALTER COLUMN id SET DEFAULT nextval('public.qa_testlist_id_seq'::regclass);


--
-- Name: qa_testlistcycle id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlistcycle ALTER COLUMN id SET DEFAULT nextval('public.qa_testlistcycle_id_seq'::regclass);


--
-- Name: qa_testlistcyclemembership id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlistcyclemembership ALTER COLUMN id SET DEFAULT nextval('public.qa_testlistcyclemembership_id_seq'::regclass);


--
-- Name: qa_testlistinstance id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlistinstance ALTER COLUMN id SET DEFAULT nextval('public.qa_testlistinstance_id_seq'::regclass);


--
-- Name: qa_testlistmembership id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlistmembership ALTER COLUMN id SET DEFAULT nextval('public.qa_testlistmembership_id_seq'::regclass);


--
-- Name: qa_tolerance id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_tolerance ALTER COLUMN id SET DEFAULT nextval('public.qa_tolerance_id_seq'::regclass);


--
-- Name: qa_unittestcollection id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestcollection ALTER COLUMN id SET DEFAULT nextval('public.qa_unittestcollection_id_seq'::regclass);


--
-- Name: qa_unittestcollection_visible_to id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestcollection_visible_to ALTER COLUMN id SET DEFAULT nextval('public.qa_unittestcollection_visible_to_id_seq'::regclass);


--
-- Name: qa_unittestinfo id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestinfo ALTER COLUMN id SET DEFAULT nextval('public.qa_unittestinfo_id_seq'::regclass);


--
-- Name: qa_unittestinfochange id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestinfochange ALTER COLUMN id SET DEFAULT nextval('public.qa_unittestinfochange_id_seq'::regclass);


--
-- Name: recurrence_date id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurrence_date ALTER COLUMN id SET DEFAULT nextval('public.recurrence_date_id_seq'::regclass);


--
-- Name: recurrence_param id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurrence_param ALTER COLUMN id SET DEFAULT nextval('public.recurrence_param_id_seq'::regclass);


--
-- Name: recurrence_recurrence id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurrence_recurrence ALTER COLUMN id SET DEFAULT nextval('public.recurrence_recurrence_id_seq'::regclass);


--
-- Name: recurrence_rule id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurrence_rule ALTER COLUMN id SET DEFAULT nextval('public.recurrence_rule_id_seq'::regclass);


--
-- Name: reports_reportnote id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_reportnote ALTER COLUMN id SET DEFAULT nextval('public.reports_reportnote_id_seq'::regclass);


--
-- Name: reports_reportschedule id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_reportschedule ALTER COLUMN id SET DEFAULT nextval('public.reports_reportschedule_id_seq'::regclass);


--
-- Name: reports_reportschedule_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_reportschedule_groups ALTER COLUMN id SET DEFAULT nextval('public.reports_reportschedule_groups_id_seq'::regclass);


--
-- Name: reports_reportschedule_users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_reportschedule_users ALTER COLUMN id SET DEFAULT nextval('public.reports_reportschedule_users_id_seq'::regclass);


--
-- Name: reports_savedreport id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_savedreport ALTER COLUMN id SET DEFAULT nextval('public.reports_savedreport_id_seq'::regclass);


--
-- Name: reports_savedreport_visible_to id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_savedreport_visible_to ALTER COLUMN id SET DEFAULT nextval('public.reports_savedreport_visible_to_id_seq'::regclass);


--
-- Name: service_log_grouplinker id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_grouplinker ALTER COLUMN id SET DEFAULT nextval('public.service_log_grouplinker_id_seq'::regclass);


--
-- Name: service_log_grouplinkerinstance id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_grouplinkerinstance ALTER COLUMN id SET DEFAULT nextval('public.service_log_grouplinkerinstance_id_seq'::regclass);


--
-- Name: service_log_hours id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_hours ALTER COLUMN id SET DEFAULT nextval('public.service_log_hours_id_seq'::regclass);


--
-- Name: service_log_returntoserviceqa id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_returntoserviceqa ALTER COLUMN id SET DEFAULT nextval('public.service_log_qafollowup_id_seq'::regclass);


--
-- Name: service_log_servicearea id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_servicearea ALTER COLUMN id SET DEFAULT nextval('public.service_log_servicearea_id_seq'::regclass);


--
-- Name: service_log_serviceevent id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceevent ALTER COLUMN id SET DEFAULT nextval('public.service_log_serviceevent_id_seq'::regclass);


--
-- Name: service_log_serviceevent_service_event_related id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceevent_service_event_related ALTER COLUMN id SET DEFAULT nextval('public.service_log_serviceevent_service_event_related_id_seq'::regclass);


--
-- Name: service_log_serviceeventschedule id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventschedule ALTER COLUMN id SET DEFAULT nextval('public.service_log_serviceeventschedule_id_seq'::regclass);


--
-- Name: service_log_serviceeventschedule_visible_to id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventschedule_visible_to ALTER COLUMN id SET DEFAULT nextval('public.service_log_serviceeventschedule_visible_to_id_seq'::regclass);


--
-- Name: service_log_serviceeventstatus id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventstatus ALTER COLUMN id SET DEFAULT nextval('public.service_log_serviceeventstatus_id_seq'::regclass);


--
-- Name: service_log_serviceeventtemplate id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventtemplate ALTER COLUMN id SET DEFAULT nextval('public.service_log_serviceeventtemplate_id_seq'::regclass);


--
-- Name: service_log_serviceeventtemplate_return_to_service_cycles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventtemplate_return_to_service_cycles ALTER COLUMN id SET DEFAULT nextval('public.service_log_serviceeventtemplate_return_to_service_cycle_id_seq'::regclass);


--
-- Name: service_log_serviceeventtemplate_return_to_service_test_lists id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventtemplate_return_to_service_test_lists ALTER COLUMN id SET DEFAULT nextval('public.service_log_serviceeventtemplate_return_to_service_test__id_seq'::regclass);


--
-- Name: service_log_servicelog id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_servicelog ALTER COLUMN id SET DEFAULT nextval('public.service_log_servicelog_id_seq'::regclass);


--
-- Name: service_log_servicetype id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_servicetype ALTER COLUMN id SET DEFAULT nextval('public.service_log_servicetype_id_seq'::regclass);


--
-- Name: service_log_thirdparty id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_thirdparty ALTER COLUMN id SET DEFAULT nextval('public.service_log_thirdparty_id_seq'::regclass);


--
-- Name: service_log_unitservicearea id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_unitservicearea ALTER COLUMN id SET DEFAULT nextval('public.service_log_unitservicearea_id_seq'::regclass);


--
-- Name: units_modality id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_modality ALTER COLUMN id SET DEFAULT nextval('public.units_modality_id_seq'::regclass);


--
-- Name: units_site id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_site ALTER COLUMN id SET DEFAULT nextval('public.units_site_id_seq'::regclass);


--
-- Name: units_unit id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unit ALTER COLUMN id SET DEFAULT nextval('public.units_unit_id_seq'::regclass);


--
-- Name: units_unit_modalities id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unit_modalities ALTER COLUMN id SET DEFAULT nextval('public.units_unit_modalities_id_seq'::regclass);


--
-- Name: units_unitavailabletime id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unitavailabletime ALTER COLUMN id SET DEFAULT nextval('public.units_unitavailabletime_id_seq'::regclass);


--
-- Name: units_unitavailabletimeedit id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unitavailabletimeedit ALTER COLUMN id SET DEFAULT nextval('public.units_unitavailabletimeedit_id_seq'::regclass);


--
-- Name: units_unitclass id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unitclass ALTER COLUMN id SET DEFAULT nextval('public.units_unitclass_id_seq'::regclass);


--
-- Name: units_unittype id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unittype ALTER COLUMN id SET DEFAULT nextval('public.units_unittype_id_seq'::regclass);


--
-- Name: units_vendor id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_vendor ALTER COLUMN id SET DEFAULT nextval('public.units_vendor_id_seq'::regclass);


--
-- Data for Name: accounts_activedirectorygroupmap; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts_activedirectorygroupmap (id, ad_group, account_qualifier) FROM stdin;
\.


--
-- Data for Name: accounts_activedirectorygroupmap_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts_activedirectorygroupmap_groups (id, activedirectorygroupmap_id, group_id) FROM stdin;
\.


--
-- Data for Name: accounts_defaultgroup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts_defaultgroup (id, group_id) FROM stdin;
\.


--
-- Data for Name: attachments_attachment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attachments_attachment (id, attachment, label, comment, created, created_by_id, test_id, testinstance_id, testlist_id, testlistcycle_id, testlistinstance_id, serviceevent_id, part_id, fault_id) FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add saved report	3	add_savedreport
2	Can change saved report	3	change_savedreport
3	Can delete saved report	3	delete_savedreport
4	Can view saved report	3	view_savedreport
5	Can Run Reports	3	can_run_reports
6	Can create Reports	3	can_create_reports
7	Can run SQL Data Reports	3	can_run_sql_reports
8	Can create SQL Data Reports	3	can_create_sql_reports
9	Can add report note	4	add_reportnote
10	Can change report note	4	change_reportnote
11	Can delete report note	4	delete_reportnote
12	Can view report note	4	view_reportnote
13	Can add report schedule	5	add_reportschedule
14	Can change report schedule	5	change_reportschedule
15	Can delete report schedule	5	delete_reportschedule
16	Can view report schedule	5	view_reportschedule
17	Can add log entry	6	add_logentry
18	Can change log entry	6	change_logentry
19	Can delete log entry	6	delete_logentry
20	Can view log entry	6	view_logentry
21	Can add content type	7	add_contenttype
22	Can change content type	7	change_contenttype
23	Can delete content type	7	delete_contenttype
24	Can view content type	7	view_contenttype
25	Can add permission	8	add_permission
26	Can change permission	8	change_permission
27	Can delete permission	8	delete_permission
28	Can view permission	8	view_permission
29	Can add group	9	add_group
30	Can change group	9	change_group
31	Can delete group	9	delete_group
32	Can view group	9	view_group
33	Can add user	10	add_user
34	Can change user	10	change_user
35	Can delete user	10	delete_user
36	Can view user	10	view_user
37	Can add session	11	add_session
38	Can change session	11	change_session
39	Can delete session	11	delete_session
40	Can view session	11	view_session
41	Can add site	12	add_site
42	Can change site	12	change_site
43	Can delete site	12	delete_site
44	Can view site	12	view_site
45	Can add Scheduled task	13	add_schedule
46	Can change Scheduled task	13	change_schedule
47	Can delete Scheduled task	13	delete_schedule
48	Can view Scheduled task	13	view_schedule
49	Can add task	14	add_task
50	Can change task	14	change_task
51	Can delete task	14	delete_task
52	Can view task	14	view_task
53	Can add Failed task	15	add_failure
54	Can change Failed task	15	change_failure
55	Can delete Failed task	15	delete_failure
56	Can view Failed task	15	view_failure
57	Can add Successful task	16	add_success
58	Can change Successful task	16	change_success
59	Can delete Successful task	16	delete_success
60	Can view Successful task	16	view_success
61	Can add Queued task	17	add_ormq
62	Can change Queued task	17	change_ormq
63	Can delete Queued task	17	delete_ormq
64	Can view Queued task	17	view_ormq
65	Can add comment	18	add_comment
66	Can change comment	18	change_comment
67	Can delete comment	18	delete_comment
68	Can view comment	18	view_comment
69	Can moderate comments	18	can_moderate
70	Can add comment flag	19	add_commentflag
71	Can change comment flag	19	change_commentflag
72	Can delete comment flag	19	delete_commentflag
73	Can view comment flag	19	view_commentflag
74	Can add Token	20	add_token
75	Can change Token	20	change_token
76	Can delete Token	20	delete_token
77	Can view Token	20	view_token
78	Can add token	21	add_tokenproxy
79	Can change token	21	change_tokenproxy
80	Can delete token	21	delete_tokenproxy
81	Can view token	21	view_tokenproxy
82	Can add date	22	add_date
83	Can change date	22	change_date
84	Can delete date	22	delete_date
85	Can view date	22	view_date
86	Can add param	23	add_param
87	Can change param	23	change_param
88	Can delete param	23	delete_param
89	Can view param	23	view_param
90	Can add recurrence	24	add_recurrence
91	Can change recurrence	24	change_recurrence
92	Can delete recurrence	24	delete_recurrence
93	Can view recurrence	24	view_recurrence
94	Can add rule	25	add_rule
95	Can change rule	25	change_rule
96	Can delete rule	25	delete_rule
97	Can view rule	25	view_rule
98	Can add Active Directory Group to QATrack+ Group Map	26	add_activedirectorygroupmap
99	Can change Active Directory Group to QATrack+ Group Map	26	change_activedirectorygroupmap
100	Can delete Active Directory Group to QATrack+ Group Map	26	delete_activedirectorygroupmap
101	Can view Active Directory Group to QATrack+ Group Map	26	view_activedirectorygroupmap
102	Can add default group	27	add_defaultgroup
103	Can change default group	27	change_defaultgroup
104	Can delete default group	27	delete_defaultgroup
105	Can view default group	27	view_defaultgroup
106	Can add treatment and imaging modality	28	add_modality
107	Can change treatment and imaging modality	28	change_modality
108	Can delete treatment and imaging modality	28	delete_modality
109	Can view treatment and imaging modality	28	view_modality
110	Can add unit	29	add_unit
111	Can change unit	29	change_unit
112	Can delete unit	29	delete_unit
113	Can view unit	29	view_unit
114	Can add unit type	30	add_unittype
115	Can change unit type	30	change_unittype
116	Can delete unit type	30	delete_unittype
117	Can view unit type	30	view_unittype
118	Can add site	31	add_site
119	Can change site	31	change_site
120	Can delete site	31	delete_site
121	Can view site	31	view_site
122	Can add unit class	32	add_unitclass
123	Can change unit class	32	change_unitclass
124	Can delete unit class	32	delete_unitclass
125	Can view unit class	32	view_unitclass
126	Can add Vendor	33	add_vendor
127	Can change Vendor	33	change_vendor
128	Can delete Vendor	33	delete_vendor
129	Can view Vendor	33	view_vendor
130	Can change unit available time	34	change_unitavailabletime
131	Can add auto review rule	36	add_autoreviewrule
132	Can change auto review rule	36	change_autoreviewrule
133	Can delete auto review rule	36	delete_autoreviewrule
134	Can view auto review rule	36	view_autoreviewrule
135	Can add category	37	add_category
136	Can change category	37	change_category
137	Can delete category	37	delete_category
138	Can view category	37	view_category
139	Can add frequency	38	add_frequency
140	Can change frequency	38	change_frequency
141	Can delete frequency	38	delete_frequency
142	Can view frequency	38	view_frequency
143	Choose QC by Frequency	38	can_choose_frequency
144	Can add reference	39	add_reference
145	Can change reference	39	change_reference
146	Can delete reference	39	delete_reference
147	Can view reference	39	view_reference
148	Can add test	40	add_test
149	Can change test	40	change_test
150	Can delete test	40	delete_test
151	Can view test	40	view_test
152	Can add test instance	41	add_testinstance
153	Can change test instance	41	change_testinstance
154	Can delete test instance	41	delete_testinstance
155	Can view test instance	41	view_testinstance
156	Can see test history when performing QC	41	can_view_history
157	Can view charts of test history	41	can_view_charts
158	Can review & approve tests	41	can_review
159	Can skip tests without comment	41	can_skip_without_comment
160	Can review & approve  self-performed tests	41	can_review_own_tests
161	Can add test instance status	42	add_testinstancestatus
162	Can change test instance status	42	change_testinstancestatus
163	Can delete test instance status	42	delete_testinstancestatus
164	Can view test instance status	42	view_testinstancestatus
165	Can add test list	2	add_testlist
166	Can change test list	2	change_testlist
167	Can delete test list	2	delete_testlist
168	Can view test list	2	view_testlist
169	Can add test list cycle	43	add_testlistcycle
170	Can change test list cycle	43	change_testlistcycle
171	Can delete test list cycle	43	delete_testlistcycle
172	Can view test list cycle	43	view_testlistcycle
173	Can add test list cycle membership	44	add_testlistcyclemembership
174	Can change test list cycle membership	44	change_testlistcyclemembership
175	Can delete test list cycle membership	44	delete_testlistcyclemembership
176	Can view test list cycle membership	44	view_testlistcyclemembership
177	Can add test list instance	1	add_testlistinstance
178	Can change test list instance	1	change_testlistinstance
179	Can delete test list instance	1	delete_testlistinstance
180	Can view test list instance	1	view_testlistinstance
181	Can override date	1	can_override_date
182	Can perform subset of tests	1	can_perform_subset
183	Can view previously completed instances	1	can_view_completed
184	Can save test lists as 'In Progress'	1	can_save_in_progress
185	Can add test list membership	45	add_testlistmembership
186	Can change test list membership	45	change_testlistmembership
187	Can delete test list membership	45	delete_testlistmembership
188	Can view test list membership	45	view_testlistmembership
189	Can add tolerance	46	add_tolerance
190	Can change tolerance	46	change_tolerance
191	Can delete tolerance	46	delete_tolerance
192	Can view tolerance	46	view_tolerance
193	Can add unit test collection	47	add_unittestcollection
194	Can change unit test collection	47	change_unittestcollection
195	Can delete unit test collection	47	delete_unittestcollection
196	Can view unit test collection	47	view_unittestcollection
197	Can view program overview	47	can_view_overview
198	Can view tli and utc not visible to user's groups	47	can_review_non_visible_tli
199	Can add unit test info	48	add_unittestinfo
200	Can change unit test info	48	change_unittestinfo
201	Can delete unit test info	48	delete_unittestinfo
202	Can view unit test info	48	view_unittestinfo
203	Can view Refs and Tols	48	can_view_ref_tol
204	Can add sublist	49	add_sublist
205	Can change sublist	49	change_sublist
206	Can delete sublist	49	delete_sublist
207	Can view sublist	49	view_sublist
208	Can add unit test info change	50	add_unittestinfochange
209	Can change unit test info change	50	change_unittestinfochange
210	Can delete unit test info change	50	delete_unittestinfochange
211	Can view unit test info change	50	view_unittestinfochange
212	Can add auto review rule set	51	add_autoreviewruleset
213	Can change auto review rule set	51	change_autoreviewruleset
214	Can delete auto review rule set	51	delete_autoreviewruleset
215	Can view auto review rule set	51	view_autoreviewruleset
216	Can add auto save	52	add_autosave
217	Can change auto save	52	change_autosave
218	Can delete auto save	52	delete_autosave
219	Can view auto save	52	view_autosave
220	Can add QC Completed Notice	53	add_qccompletednotice
221	Can change QC Completed Notice	53	change_qccompletednotice
222	Can delete QC Completed Notice	53	delete_qccompletednotice
223	Can view QC Completed Notice	53	view_qccompletednotice
224	Can add recipient group	54	add_recipientgroup
225	Can change recipient group	54	change_recipientgroup
226	Can delete recipient group	54	delete_recipientgroup
227	Can view recipient group	54	view_recipientgroup
228	Can add test list group	55	add_testlistgroup
229	Can change test list group	55	change_testlistgroup
230	Can delete test list group	55	delete_testlistgroup
231	Can view test list group	55	view_testlistgroup
232	Can add unit group	56	add_unitgroup
233	Can change unit group	56	change_unitgroup
234	Can delete unit group	56	delete_unitgroup
235	Can view unit group	56	view_unitgroup
236	Can add QC Scheduling Notice	57	add_qcschedulingnotice
237	Can change QC Scheduling Notice	57	change_qcschedulingnotice
238	Can delete QC Scheduling Notice	57	delete_qcschedulingnotice
239	Can view QC Scheduling Notice	57	view_qcschedulingnotice
240	Can add Service Event Notice	58	add_serviceeventnotice
241	Can change Service Event Notice	58	change_serviceeventnotice
242	Can delete Service Event Notice	58	delete_serviceeventnotice
243	Can view Service Event Notice	58	view_serviceeventnotice
244	Can add QC Review Notice	59	add_qcreviewnotice
245	Can change QC Review Notice	59	change_qcreviewnotice
246	Can delete QC Review Notice	59	delete_qcreviewnotice
247	Can view QC Review Notice	59	view_qcreviewnotice
248	Can add Service Event Review Notice	60	add_serviceeventreviewnotice
249	Can change Service Event Review Notice	60	change_serviceeventreviewnotice
250	Can delete Service Event Review Notice	60	delete_serviceeventreviewnotice
251	Can view Service Event Review Notice	60	view_serviceeventreviewnotice
252	Can add part category group	61	add_partcategorygroup
253	Can change part category group	61	change_partcategorygroup
254	Can delete part category group	61	delete_partcategorygroup
255	Can view part category group	61	view_partcategorygroup
256	Can add Part Notice	62	add_partnotice
257	Can change Part Notice	62	change_partnotice
258	Can delete Part Notice	62	delete_partnotice
259	Can view Part Notice	62	view_partnotice
260	Can add Fault Logged Notice	63	add_faultnotice
261	Can change Fault Logged Notice	63	change_faultnotice
262	Can delete Fault Logged Notice	63	delete_faultnotice
263	Can view Fault Logged Notice	63	view_faultnotice
264	Can add Fault Review Notice	64	add_faultsreviewnotice
265	Can change Fault Review Notice	64	change_faultsreviewnotice
266	Can delete Fault Review Notice	64	delete_faultsreviewnotice
267	Can view Fault Review Notice	64	view_faultsreviewnotice
268	Can add Service Event Scheduling Notice	65	add_serviceeventschedulingnotice
269	Can change Service Event Scheduling Notice	65	change_serviceeventschedulingnotice
270	Can delete Service Event Scheduling Notice	65	delete_serviceeventschedulingnotice
271	Can view Service Event Scheduling Notice	65	view_serviceeventschedulingnotice
272	Can add contact	66	add_contact
273	Can change contact	66	change_contact
274	Can delete contact	66	delete_contact
275	Can view contact	66	view_contact
276	Can add issue	67	add_issue
277	Can change issue	67	change_issue
278	Can delete issue	67	delete_issue
279	Can view issue	67	view_issue
280	Can add issue type	68	add_issuetype
281	Can change issue type	68	change_issuetype
282	Can delete issue type	68	delete_issuetype
283	Can view issue type	68	view_issuetype
284	Can add issue priority	69	add_issuepriority
285	Can change issue priority	69	change_issuepriority
286	Can delete issue priority	69	delete_issuepriority
287	Can view issue priority	69	view_issuepriority
288	Can add issue tag	70	add_issuetag
289	Can change issue tag	70	change_issuetag
290	Can delete issue tag	70	delete_issuetag
291	Can view issue tag	70	view_issuetag
292	Can add issue status	71	add_issuestatus
293	Can change issue status	71	change_issuestatus
294	Can delete issue status	71	delete_issuestatus
295	Can view issue status	71	view_issuestatus
296	Can have hours	72	can_have_hours
297	Can add service area	73	add_servicearea
298	Can change service area	73	change_servicearea
299	Can delete service area	73	delete_servicearea
300	Can view service area	73	view_servicearea
301	Can add service event	74	add_serviceevent
302	Can change service event	74	change_serviceevent
303	Can delete service event	74	delete_serviceevent
304	Can review service event	74	review_serviceevent
305	Can review service event	74	view_serviceevent
306	Can add service event status	75	add_serviceeventstatus
307	Can change service event status	75	change_serviceeventstatus
308	Can delete service event status	75	delete_serviceeventstatus
309	Can view service event status	75	view_serviceeventstatus
310	Can add service type	76	add_servicetype
311	Can change service type	76	change_servicetype
312	Can delete service type	76	delete_servicetype
313	Can view service type	76	view_servicetype
314	Can add third party	77	add_thirdparty
315	Can change third party	77	change_thirdparty
316	Can delete third party	77	delete_thirdparty
317	Can view third party	77	view_thirdparty
318	Can add unit service area	78	add_unitservicearea
319	Can change unit service area	78	change_unitservicearea
320	Can delete unit service area	78	delete_unitservicearea
321	Can view unit service area	78	view_unitservicearea
322	Can add group linker	79	add_grouplinker
323	Can change group linker	79	change_grouplinker
324	Can delete group linker	79	delete_grouplinker
325	Can view group linker	79	view_grouplinker
326	Can add return to service qc	81	add_returntoserviceqa
327	Can change return to service qc	81	change_returntoserviceqa
328	Can delete return to service qc	81	delete_returntoserviceqa
329	Can view Return To Service QC	81	view_returntoserviceqa
330	Can perform Return To Service QC	81	perform_returntoserviceqa
331	Can add service event schedule	83	add_serviceeventschedule
332	Can change service event schedule	83	change_serviceeventschedule
333	Can delete service event schedule	83	delete_serviceeventschedule
334	Can view service event schedule	83	view_serviceeventschedule
335	Can add service event template	84	add_serviceeventtemplate
336	Can change service event template	84	change_serviceeventtemplate
337	Can delete service event template	84	delete_serviceeventtemplate
338	Can view service event template	84	view_serviceeventtemplate
339	Can add part category	85	add_partcategory
340	Can change part category	85	change_partcategory
341	Can delete part category	85	delete_partcategory
342	Can view part category	85	view_partcategory
343	Can add part	86	add_part
344	Can change part	86	change_part
345	Can delete part	86	delete_part
346	Can view part	86	view_part
347	Can add part used	89	add_partused
348	Can change part used	89	change_partused
349	Can delete part used	89	delete_partused
350	Can view part used	89	view_partused
351	Can add room	90	add_room
352	Can change room	90	change_room
353	Can delete room	90	delete_room
354	Can view room	90	view_room
355	Can add storage	91	add_storage
356	Can change storage	91	change_storage
357	Can delete storage	91	delete_storage
358	Can view storage	91	view_storage
359	Can add supplier	92	add_supplier
360	Can change supplier	92	change_supplier
361	Can delete supplier	92	delete_supplier
362	Can view supplier	92	view_supplier
363	Can add Contact	93	add_contact
364	Can change Contact	93	change_contact
365	Can delete Contact	93	delete_contact
366	Can view Contact	93	view_contact
367	Can add fault	94	add_fault
368	Can change fault	94	change_fault
369	Can delete fault	94	delete_fault
370	Can view fault	94	view_fault
371	Can review faults	94	can_review
372	Can add fault type	95	add_faulttype
373	Can change fault type	95	change_faulttype
374	Can delete fault type	95	delete_faulttype
375	Can view fault type	95	view_faulttype
376	Can add fault review group	96	add_faultreviewgroup
377	Can change fault review group	96	change_faultreviewgroup
378	Can delete fault review group	96	delete_faultreviewgroup
379	Can view fault review group	96	view_faultreviewgroup
380	Can add fault review instance	97	add_faultreviewinstance
381	Can change fault review instance	97	change_faultreviewinstance
382	Can delete fault review instance	97	delete_faultreviewinstance
383	Can view fault review instance	97	view_faultreviewinstance
384	Can add attachment	98	add_attachment
385	Can change attachment	98	change_attachment
386	Can delete attachment	98	delete_attachment
387	Can view attachment	98	view_attachment
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
1	pbkdf2_sha256$150000$cPQ0SGJ0bdoC$M4BBLzSe4JvVIDa8ctNKv7K//uUR24f8+y3boN25dH8=	\N	f	QATrack+ Internal				f	f	2026-01-29 23:51:00.666002+00
2	pbkdf2_sha256$150000$5xLmxeyNW8ZT$me7mZ4nX1ndTzlBBwKvsvoOH0mvgrjO+ARnNUrcpZqA=	\N	t	admin			admin@example.com	t	t	2026-01-29 23:51:20.285892+00
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: authtoken_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.authtoken_token (key, created, user_id) FROM stdin;
\.


--
-- Data for Name: contacts_contact; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contacts_contact (id, name, number, description) FROM stdin;
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.


--
-- Data for Name: django_comment_flags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_comment_flags (id, flag, flag_date, comment_id, user_id) FROM stdin;
\.


--
-- Data for Name: django_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_comments (id, object_pk, user_name, user_email, user_url, comment, submit_date, ip_address, is_public, is_removed, content_type_id, site_id, user_id) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	qa	testlistinstance
2	qa	testlist
3	reports	savedreport
4	reports	reportnote
5	reports	reportschedule
6	admin	logentry
7	contenttypes	contenttype
8	auth	permission
9	auth	group
10	auth	user
11	sessions	session
12	sites	site
13	django_q	schedule
14	django_q	task
15	django_q	failure
16	django_q	success
17	django_q	ormq
18	django_comments	comment
19	django_comments	commentflag
20	authtoken	token
21	authtoken	tokenproxy
22	recurrence	date
23	recurrence	param
24	recurrence	recurrence
25	recurrence	rule
26	accounts	activedirectorygroupmap
27	accounts	defaultgroup
28	units	modality
29	units	unit
30	units	unittype
31	units	site
32	units	unitclass
33	units	vendor
34	units	unitavailabletime
35	units	unitavailabletimeedit
36	qa	autoreviewrule
37	qa	category
38	qa	frequency
39	qa	reference
40	qa	test
41	qa	testinstance
42	qa	testinstancestatus
43	qa	testlistcycle
44	qa	testlistcyclemembership
45	qa	testlistmembership
46	qa	tolerance
47	qa	unittestcollection
48	qa	unittestinfo
49	qa	sublist
50	qa	unittestinfochange
51	qa	autoreviewruleset
52	qa	autosave
53	notifications	qccompletednotice
54	notifications	recipientgroup
55	notifications	testlistgroup
56	notifications	unitgroup
57	notifications	qcschedulingnotice
58	notifications	serviceeventnotice
59	notifications	qcreviewnotice
60	notifications	serviceeventreviewnotice
61	notifications	partcategorygroup
62	notifications	partnotice
63	notifications	faultnotice
64	notifications	faultsreviewnotice
65	notifications	serviceeventschedulingnotice
66	contacts	contact
67	issue_tracker	issue
68	issue_tracker	issuetype
69	issue_tracker	issuepriority
70	issue_tracker	issuetag
71	issue_tracker	issuestatus
72	service_log	hours
73	service_log	servicearea
74	service_log	serviceevent
75	service_log	serviceeventstatus
76	service_log	servicetype
77	service_log	thirdparty
78	service_log	unitservicearea
79	service_log	grouplinker
80	service_log	grouplinkerinstance
81	service_log	returntoserviceqa
82	service_log	servicelog
83	service_log	serviceeventschedule
84	service_log	serviceeventtemplate
85	parts	partcategory
86	parts	part
87	parts	partstoragecollection
88	parts	partsuppliercollection
89	parts	partused
90	parts	room
91	parts	storage
92	parts	supplier
93	parts	contact
94	faults	fault
95	faults	faulttype
96	faults	faultreviewgroup
97	faults	faultreviewinstance
98	attachments	attachment
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2026-01-29 23:50:58.879164+00
2	contenttypes	0002_remove_content_type_name	2026-01-29 23:50:58.891345+00
3	auth	0001_initial	2026-01-29 23:50:58.92844+00
4	auth	0002_alter_permission_name_max_length	2026-01-29 23:50:58.963013+00
5	auth	0003_alter_user_email_max_length	2026-01-29 23:50:58.971282+00
6	auth	0004_alter_user_username_opts	2026-01-29 23:50:58.980323+00
7	auth	0005_alter_user_last_login_null	2026-01-29 23:50:58.988319+00
8	auth	0006_require_contenttypes_0002	2026-01-29 23:50:58.990331+00
9	auth	0007_alter_validators_add_error_messages	2026-01-29 23:50:58.998073+00
10	auth	0008_alter_user_username_max_length	2026-01-29 23:50:59.009555+00
11	auth	0009_alter_user_last_name_max_length	2026-01-29 23:50:59.017684+00
12	units	0001_initial	2026-01-29 23:50:59.048179+00
13	qa	0001_initial	2026-01-29 23:50:59.642009+00
14	sites	0001_initial	2026-01-29 23:50:59.812731+00
15	django_comments	0001_initial	2026-01-29 23:50:59.882607+00
16	django_comments	0002_update_user_email_field_length	2026-01-29 23:50:59.910801+00
17	django_comments	0003_add_submit_date_index	2026-01-29 23:50:59.92786+00
18	qa	0002_029_to_030_first	2026-01-29 23:51:00.30385+00
19	qa	0002_029_to_030_2nd	2026-01-29 23:51:00.337034+00
20	qa	0002_auto_20161218_1851	2026-01-29 23:51:00.489528+00
21	qa	0003_auto_20171103_1256	2026-01-29 23:51:00.530049+00
22	qa	0004_auto_20171103_1615	2026-01-29 23:51:00.550793+00
23	qa	0005_auto_20171103_2158	2026-01-29 23:51:00.676158+00
24	qa	0006_auto_20171120_2126	2026-01-29 23:51:00.717629+00
25	qa	0007_auto_20171124_1102	2026-01-29 23:51:00.757023+00
26	qa	0008_sublist_to_children	2026-01-29 23:51:00.789647+00
27	qa	0009_remove_testlist_sublists	2026-01-29 23:51:00.890496+00
28	qa	0010_auto_20171208_1411	2026-01-29 23:51:00.914086+00
29	qa	0011_unittestinfochange	2026-01-29 23:51:00.94514+00
30	qa	0012_testinstancestatus_colour	2026-01-29 23:51:00.983576+00
31	qa	0013_auto_20180511_2341	2026-01-29 23:51:01.043866+00
32	qa	0014_convert_file_uploads	2026-01-29 23:51:01.067727+00
33	qa	0015_auto_20180601_1212	2026-01-29 23:51:01.092317+00
34	qa	0016_tolerance_name	2026-01-29 23:51:01.106533+00
35	qa	0017_set_tolerance_names	2026-01-29 23:51:01.132948+00
36	qa	0018_unique_tolerance_names	2026-01-29 23:51:01.158939+00
37	qa	0019_unique_tolerance_names_schema	2026-01-29 23:51:01.17716+00
38	qa	0020_auto_20180924_2313	2026-01-29 23:51:01.243598+00
39	qa	0021_check_py3_calcs	2026-01-29 23:51:01.269214+00
40	qa	0022_auto_20181120_1607	2026-01-29 23:51:01.290276+00
41	qa	0023_set_recurrences	2026-01-29 23:51:01.317471+00
42	qa	0024_remove_frequency_due_interval	2026-01-29 23:51:01.324628+00
43	qa	0025_auto_20181129_1449	2026-01-29 23:51:01.343584+00
44	qa	0026_copy_overdue_interval	2026-01-29 23:51:01.373165+00
45	qa	0027_remove_frequency_overdue_interval	2026-01-29 23:51:01.380743+00
46	qa	0028_auto_20181214_2209	2026-01-29 23:51:01.552708+00
47	qa	0029_auto_20181217_0945	2026-01-29 23:51:01.576282+00
48	qa	0030_auto_20190129_2156	2026-01-29 23:51:01.818429+00
49	accounts	0001_initial	2026-01-29 23:51:01.917258+00
50	accounts	0002_activedirectorygroupmap_defaultgroup	2026-01-29 23:51:01.97262+00
51	accounts	0003_auto_20210207_1027	2026-01-29 23:51:01.992917+00
52	admin	0001_initial	2026-01-29 23:51:02.023069+00
53	admin	0002_logentry_remove_auto_add	2026-01-29 23:51:02.045032+00
54	admin	0003_logentry_add_action_flag_choices	2026-01-29 23:51:02.062675+00
55	units	0002_029_to_030_first	2026-01-29 23:51:02.360843+00
56	units	0003_auto_20171204_1232	2026-01-29 23:51:02.384795+00
57	units	0004_auto_20171222_1045	2026-01-29 23:51:02.395606+00
58	units	0005_auto_20180110_1257	2026-01-29 23:51:02.411114+00
59	units	0006_auto_20180426_1621	2026-01-29 23:51:02.420876+00
60	units	0007_auto_20180601_1212	2026-01-29 23:51:02.451989+00
61	units	0008_auto_20180725_1230	2026-01-29 23:51:02.46033+00
62	units	0009_remove_unit_restricted	2026-01-29 23:51:02.469446+00
63	units	0010_default_is_serviceable	2026-01-29 23:51:02.519757+00
64	units	0011_auto_20190410_1101	2026-01-29 23:51:02.528632+00
65	units	0012_site_slug	2026-01-29 23:51:02.535906+00
66	units	0013_site_slugs	2026-01-29 23:51:02.568666+00
67	units	0014_auto_20191128_2343	2026-01-29 23:51:02.580987+00
68	units	0015_auto_20200729_1654	2026-01-29 23:51:02.653304+00
69	units	0016_datetimes_to_dates	2026-01-29 23:51:02.655588+00
70	units	0017_auto_20210126_2104	2026-01-29 23:51:02.673283+00
71	service_log	0001_initial	2026-01-29 23:51:03.531581+00
72	service_log	0002_auto_20171101_1115	2026-01-29 23:51:03.694751+00
73	service_log	0003_auto_20171204_1232	2026-01-29 23:51:03.794113+00
74	service_log	0004_auto_20180110_1257	2026-01-29 23:51:03.8158+00
75	service_log	0005_auto_20180327_1157	2026-01-29 23:51:03.840565+00
76	service_log	0006_auto_20180329_1410	2026-01-29 23:51:03.922781+00
77	service_log	0007_servicelog	2026-01-29 23:51:03.957147+00
78	service_log	0008_auto_20180403_1321	2026-01-29 23:51:04.077961+00
79	service_log	0009_auto_20180411_1644	2026-01-29 23:51:04.104583+00
80	service_log	0010_hours_unique_constraint	2026-01-29 23:51:04.145442+00
81	service_log	0011_auto_20180529_0917	2026-01-29 23:51:04.189203+00
82	service_log	0012_auto_20180425_1623	2026-01-29 23:51:04.195924+00
83	service_log	0013_auto_20180425_1625	2026-01-29 23:51:04.202259+00
84	service_log	0014_auto_20180601_1212	2026-01-29 23:51:04.254581+00
85	service_log	0015_auto_20180725_1230	2026-01-29 23:51:04.291403+00
86	service_log	0016_auto_20180725_1651	2026-01-29 23:51:04.298067+00
87	service_log	0017_auto_20180814_1312	2026-01-29 23:51:04.361898+00
88	service_log	0018_auto_20181119_1252	2026-01-29 23:51:04.369296+00
89	service_log	0019_auto_20181214_2209	2026-01-29 23:51:04.375815+00
90	service_log	0020_auto_20190129_2119	2026-01-29 23:51:04.473323+00
91	service_log	0021_auto_20190729_2228	2026-01-29 23:51:04.654915+00
92	service_log	0022_auto_20190903_1336	2026-01-29 23:51:04.669017+00
93	service_log	0022_auto_20190819_1531	2026-01-29 23:51:04.69047+00
94	service_log	0023_merge_20190903_1429	2026-01-29 23:51:04.692595+00
95	service_log	0024_grouplinker_required	2026-01-29 23:51:04.702126+00
96	reports	0001_initial	2026-01-29 23:51:04.741397+00
97	reports	0002_auto_20190502_1418	2026-01-29 23:51:04.809709+00
98	reports	0003_copy_report_permissions	2026-01-29 23:51:04.85901+00
99	qa	0031_convert_null_mc_tols	2026-01-29 23:51:04.901029+00
100	qa	0032_auto_20190313_2112	2026-01-29 23:51:04.977815+00
101	qa	0033_test_formatting	2026-01-29 23:51:04.999732+00
102	qa	0034_auto_20190418_2308	2026-01-29 23:51:05.056208+00
103	qa	0035_remove_sql_reports_perms	2026-01-29 23:51:05.097123+00
104	qa	0034_auto_20190805_1248	2026-01-29 23:51:05.25517+00
105	qa	0036_merge_20190805_2059	2026-01-29 23:51:05.258239+00
106	qa	0037_auto_20191009_1919	2026-01-29 23:51:05.330062+00
107	qa	0038_testinstance_order	2026-01-29 23:51:05.358303+00
108	qa	0039_auto_20191016_1401	2026-01-29 23:51:05.445156+00
109	qa	0040_add_default_autoreviewruleset	2026-01-29 23:51:05.493936+00
110	qa	0041_auto_20191017_1604	2026-01-29 23:51:05.525359+00
111	qa	0042_auto_20191119_1011	2026-01-29 23:51:05.568635+00
112	qa	0043_category_tree	2026-01-29 23:51:05.625613+00
113	qa	0044_category_tree_rebuild	2026-01-29 23:51:05.672581+00
114	qa	0045_auto_20191203_1409	2026-01-29 23:51:05.730765+00
115	qa	0046_datestrings_to_dates	2026-01-29 23:51:05.896184+00
116	qa	0047_fix_serialized_uploads	2026-01-29 23:51:05.945455+00
117	qa	0048_auto_20200102_1356	2026-01-29 23:51:05.972592+00
118	qa	0049_convert_upload_attachments	2026-01-29 23:51:06.015176+00
119	qa	0050_auto_20200131_1020	2026-01-29 23:51:06.07459+00
120	qa	0051_wraparound_test	2026-01-29 23:51:06.122297+00
121	qa	0052_auto_20200302_2014	2026-01-29 23:51:06.289288+00
122	qa	0053_testlist_test_lists	2026-01-29 23:51:06.322117+00
123	qa	0054_testlistinstance_include_for_scheduling	2026-01-29 23:51:06.350565+00
124	qa	0055_test_require_comment	2026-01-29 23:51:06.373641+00
125	qa	0056_autosave	2026-01-29 23:51:06.536964+00
126	qa	0057_auto_20200825_2233	2026-01-29 23:51:06.642217+00
127	service_log	0025_auto_20210114_0951	2026-01-29 23:51:09.298985+00
128	service_log	0026_auto_20210126_2104	2026-01-29 23:51:09.349369+00
129	faults	0001_initial	2026-01-29 23:51:09.787233+00
130	faults	0002_auto_20210202_1653	2026-01-29 23:51:09.83046+00
131	faults	0003_auto_20210202_1703	2026-01-29 23:51:09.846272+00
132	faults	0004_nullify_techniques	2026-01-29 23:51:09.893745+00
133	faults	0005_auto_20210317_1538	2026-01-29 23:51:09.986644+00
134	auth	0010_alter_group_name_max_length	2026-01-29 23:51:10.002437+00
135	auth	0011_update_proxy_permissions	2026-01-29 23:51:10.056308+00
136	faults	0006_auto_20210317_1651	2026-01-29 23:51:10.235214+00
137	faults	0007_fault_fault_types	2026-01-29 23:51:10.39415+00
138	faults	0008_move_fault_type_to_fault_types	2026-01-29 23:51:10.458165+00
139	faults	0009_remove_fault_fault_type	2026-01-29 23:51:10.50938+00
140	faults	0010_auto_20210323_1324	2026-01-29 23:51:10.557607+00
141	parts	0001_initial	2026-01-29 23:51:11.314014+00
142	parts	0002_auto_20171027_1151	2026-01-29 23:51:11.399677+00
143	parts	0003_auto_20180327_1157	2026-01-29 23:51:11.536738+00
144	parts	0004_auto_20180529_0917	2026-01-29 23:51:11.546941+00
145	parts	0005_auto_20180601_1212	2026-01-29 23:51:11.564054+00
146	parts	0006_auto_20180725_1230	2026-01-29 23:51:11.582159+00
147	parts	0007_part_name	2026-01-29 23:51:11.592111+00
148	parts	0008_copy_description_to_name	2026-01-29 23:51:11.643769+00
149	parts	0009_remove_part_description	2026-01-29 23:51:11.655316+00
150	parts	0010_auto_20190129_2120	2026-01-29 23:51:11.84319+00
151	parts	0011_auto_20191203_1123	2026-01-29 23:51:12.762439+00
152	parts	0012_auto_20200119_2149	2026-01-29 23:51:12.774863+00
153	parts	0013_auto_20201229_1302	2026-01-29 23:51:12.905105+00
154	parts	0014_auto_20201230_0955	2026-01-29 23:51:12.925338+00
155	attachments	0001_initial	2026-01-29 23:51:12.989798+00
156	attachments	0002_auto_20161218_1859	2026-01-29 23:51:13.221623+00
157	attachments	0003_attachment_serviceevent	2026-01-29 23:51:13.296227+00
158	attachments	0004_auto_20180906_0946	2026-01-29 23:51:13.351406+00
159	attachments	0005_add_attach_perm	2026-01-29 23:51:13.408339+00
160	attachments	0006_auto_20190129_2156	2026-01-29 23:51:13.482273+00
161	attachments	0007_attachment_part	2026-01-29 23:51:13.547437+00
162	attachments	0008_attachment_fault	2026-01-29 23:51:13.607733+00
163	authtoken	0001_initial	2026-01-29 23:51:13.66307+00
164	authtoken	0002_auto_20160226_1747	2026-01-29 23:51:13.941272+00
165	authtoken	0003_tokenproxy	2026-01-29 23:51:13.948136+00
166	contacts	0001_initial	2026-01-29 23:51:13.957308+00
167	django_q	0001_initial	2026-01-29 23:51:13.97925+00
168	django_q	0002_auto_20150630_1624	2026-01-29 23:51:13.991661+00
169	django_q	0003_auto_20150708_1326	2026-01-29 23:51:14.01928+00
170	django_q	0004_auto_20150710_1043	2026-01-29 23:51:14.038223+00
171	django_q	0005_auto_20150718_1506	2026-01-29 23:51:14.052077+00
172	django_q	0006_auto_20150805_1817	2026-01-29 23:51:14.066658+00
173	django_q	0007_ormq	2026-01-29 23:51:14.077403+00
174	django_q	0008_auto_20160224_1026	2026-01-29 23:51:14.085515+00
175	django_q	0009_auto_20171009_0915	2026-01-29 23:51:14.099737+00
176	django_q	0010_auto_20200610_0856	2026-01-29 23:51:14.118356+00
177	django_q	0011_auto_20200628_1055	2026-01-29 23:51:14.131462+00
178	django_q	0012_auto_20200702_1608	2026-01-29 23:51:14.140464+00
179	django_q	0013_task_attempt_count	2026-01-29 23:51:14.148401+00
180	faults	0011_auto_20210406_1026	2026-01-29 23:51:14.263355+00
181	faults	0012_eliminate_duplicate_fault_codes	2026-01-29 23:51:14.320703+00
182	faults	0013_auto_20220617_1240	2026-01-29 23:51:14.335129+00
183	issue_tracker	0001_initial	2026-01-29 23:51:14.403714+00
184	issue_tracker	0002_auto_20170505_1334	2026-01-29 23:51:14.472185+00
185	issue_tracker	0003_auto_20170505_1341	2026-01-29 23:51:14.483371+00
186	issue_tracker	0004_auto_20170505_1453	2026-01-29 23:51:14.492155+00
187	issue_tracker	0005_auto_20170505_1457	2026-01-29 23:51:14.683017+00
188	issue_tracker	0006_issuetag_description	2026-01-29 23:51:14.707585+00
189	issue_tracker	0007_auto_20170505_1522	2026-01-29 23:51:14.757809+00
190	issue_tracker	0008_auto_20170505_1549	2026-01-29 23:51:14.841297+00
191	issue_tracker	0009_auto_20170505_1623	2026-01-29 23:51:15.029259+00
192	issue_tracker	0010_auto_20170531_1149	2026-01-29 23:51:15.092741+00
193	issue_tracker	0011_auto_20170531_1255	2026-01-29 23:51:15.10442+00
194	issue_tracker	0012_auto_20170531_1453	2026-01-29 23:51:15.34235+00
195	issue_tracker	0013_auto_20170531_1516	2026-01-29 23:51:15.356242+00
196	issue_tracker	0014_auto_20171027_1151	2026-01-29 23:51:15.432823+00
197	issue_tracker	0015_auto_20190129_2156	2026-01-29 23:51:15.492014+00
198	notifications	0001_initial	2026-01-29 23:51:15.546737+00
199	notifications	0002_auto_20161003_2213	2026-01-29 23:51:15.60323+00
200	notifications	0003_auto_20190410_2251	2026-01-29 23:51:15.808427+00
201	notifications	0004_copy_group_to_groups	2026-01-29 23:51:15.894074+00
202	notifications	0005_remove_notificationsubscription_group	2026-01-29 23:51:16.091905+00
203	notifications	0006_auto_20190501_1526	2026-01-29 23:51:16.261206+00
204	notifications	0007_auto_20190620_1031	2026-01-29 23:51:16.389627+00
205	notifications	0008_copy_notification_type	2026-01-29 23:51:16.451158+00
206	notifications	0009_remove_notificationsubscription_warning_level	2026-01-29 23:51:16.493617+00
207	notifications	0010_auto_20190801_2148	2026-01-29 23:51:17.000408+00
208	notifications	0011_copy_qccompleted_notice	2026-01-29 23:51:17.11656+00
209	notifications	0012_auto_20190802_2018	2026-01-29 23:51:17.501543+00
210	notifications	0013_auto_20190803_0022	2026-01-29 23:51:17.664713+00
211	notifications	0014_qcschedulingnotice_last_sent	2026-01-29 23:51:17.688656+00
212	notifications	0015_serviceeventnotice	2026-01-29 23:51:17.74091+00
213	notifications	0016_qcreviewnotice	2026-01-29 23:51:17.937989+00
214	notifications	0017_auto_20200515_2014	2026-01-29 23:51:18.010422+00
215	notifications	0018_auto_20200529_2126	2026-01-29 23:51:18.03379+00
216	notifications	0019_change_choices	2026-01-29 23:51:18.108462+00
217	notifications	0020_auto_20200530_0008	2026-01-29 23:51:18.197125+00
218	notifications	0021_partcategorygroup_partnotice	2026-01-29 23:51:18.409773+00
219	notifications	0022_faultnotice	2026-01-29 23:51:18.497131+00
220	notifications	0023_faultsreviewnotice	2026-01-29 23:51:18.713131+00
221	notifications	0024_serviceeventschedulingnotice	2026-01-29 23:51:18.800574+00
222	parts	0013_auto_20200418_1958	2026-01-29 23:51:18.821563+00
223	parts	0015_merge_20201231_0928	2026-01-29 23:51:18.82431+00
224	parts	0016_auto_20210127_1624	2026-01-29 23:51:18.835269+00
225	qa	0058_testlistinstance_user_key	2026-01-29 23:51:18.877854+00
226	reports	0004_auto_20190517_2210	2026-01-29 23:51:18.986166+00
227	reports	0005_auto_20190704_1603	2026-01-29 23:51:19.282301+00
228	reports	0006_reportschedule_last_sent	2026-01-29 23:51:19.477954+00
229	reports	0007_utc_to_tli_details	2026-01-29 23:51:19.55421+00
230	reports	0008_auto_20200722_1707	2026-01-29 23:51:19.665147+00
231	qatrack_core	0001_update_recurrences	2026-01-29 23:51:19.767321+00
232	recurrence	0001_initial	2026-01-29 23:51:19.816333+00
233	sessions	0001_initial	2026-01-29 23:51:19.83527+00
234	sites	0002_alter_domain_unique	2026-01-29 23:51:19.850595+00
235	units	0018_auto_20210317_1538	2026-01-29 23:51:19.911995+00
236	units	0019_auto_20210323_1324	2026-01-29 23:51:19.931437+00
\.


--
-- Data for Name: django_q_ormq; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_q_ormq (id, key, payload, lock) FROM stdin;
\.


--
-- Data for Name: django_q_schedule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_q_schedule (id, func, hook, args, kwargs, schedule_type, repeats, next_run, task, name, minutes, cron) FROM stdin;
1	qatrack.qa.tasks.clean_autosaves	\N	()	{}	D	-1	2026-01-30 04:51:28.662628+00	\N	QATrack+ Autosave Cleaner	\N	\N
2	qatrack.notifications.qcscheduling.tasks.run_scheduling_notices	\N	()	{}	I	-1	2026-01-29 23:52:30+00	\N	QATrack+ Scheduling Notices	15	\N
3	qatrack.notifications.qcreview.tasks.run_review_notices	\N	()	{}	I	-1	2026-01-29 23:52:30+00	\N	QATrack+ Review Notices	15	\N
4	qatrack.notifications.service_log_review.tasks.run_service_event_review_notices	\N	()	{}	I	-1	2026-01-29 23:52:30+00	\N	QATrack+ Service Event Review Notices	15	\N
5	qatrack.notifications.service_log_scheduling.tasks.run_scheduling_notices	\N	()	{}	I	-1	2026-01-29 23:52:30+00	\N	QATrack+ Service Event Scheduling Notices	15	\N
6	qatrack.notifications.faults_review.tasks.run_faults_review_notices	\N	()	{}	I	-1	2026-01-29 23:52:30+00	\N	QATrack+ Fault Review Notices	15	\N
7	qatrack.reports.tasks.run_reports	\N	()	{}	I	-1	2026-01-29 23:52:30+00	\N	QATrack+ Report Sender	15	\N
\.


--
-- Data for Name: django_q_task; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_q_task (name, func, hook, args, kwargs, result, started, stopped, success, id, "group", attempt_count) FROM stdin;
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_site (id, domain, name) FROM stdin;
1	example.com	example.com
\.


--
-- Data for Name: faults_fault; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.faults_fault (id, occurred, created, modified, created_by_id, modality_id, modified_by_id, unit_id) FROM stdin;
\.


--
-- Data for Name: faults_fault_fault_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.faults_fault_fault_types (id, fault_id, faulttype_id) FROM stdin;
\.


--
-- Data for Name: faults_fault_related_service_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.faults_fault_related_service_events (id, fault_id, serviceevent_id) FROM stdin;
\.


--
-- Data for Name: faults_faultreviewgroup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.faults_faultreviewgroup (id, required, group_id) FROM stdin;
\.


--
-- Data for Name: faults_faultreviewinstance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.faults_faultreviewinstance (id, reviewed, fault_id, fault_review_group_id, reviewed_by_id) FROM stdin;
\.


--
-- Data for Name: faults_faulttype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.faults_faulttype (id, code, slug, description) FROM stdin;
\.


--
-- Data for Name: issue_tracker_issue; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.issue_tracker_issue (id, datetime_submitted, description, error_screen, issue_type_id, user_submitted_by_id, issue_priority_id, issue_status_id) FROM stdin;
\.


--
-- Data for Name: issue_tracker_issue_issue_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.issue_tracker_issue_issue_tags (id, issue_id, issuetag_id) FROM stdin;
\.


--
-- Data for Name: issue_tracker_issuepriority; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.issue_tracker_issuepriority (id, name, colour, "order") FROM stdin;
\.


--
-- Data for Name: issue_tracker_issuestatus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.issue_tracker_issuestatus (id, name, description, colour, "order") FROM stdin;
\.


--
-- Data for Name: issue_tracker_issuetag; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.issue_tracker_issuetag (id, name, description) FROM stdin;
\.


--
-- Data for Name: issue_tracker_issuetype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.issue_tracker_issuetype (id, name) FROM stdin;
\.


--
-- Data for Name: notifications_faultnotice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications_faultnotice (id, notification_type, recipients_id, units_id) FROM stdin;
\.


--
-- Data for Name: notifications_faultsreviewnotice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications_faultsreviewnotice (id, notification_type, send_empty, recurrences, "time", last_sent, recipients_id, units_id) FROM stdin;
\.


--
-- Data for Name: notifications_partcategorygroup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications_partcategorygroup (id, name) FROM stdin;
\.


--
-- Data for Name: notifications_partcategorygroup_part_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications_partcategorygroup_part_categories (id, partcategorygroup_id, partcategory_id) FROM stdin;
\.


--
-- Data for Name: notifications_partnotice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications_partnotice (id, notification_type, part_categories_id, recipients_id) FROM stdin;
\.


--
-- Data for Name: notifications_qccompletednotice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications_qccompletednotice (id, notification_type, follow_up_days, recipients_id, test_lists_id, units_id) FROM stdin;
\.


--
-- Data for Name: notifications_qcreviewnotice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications_qcreviewnotice (id, notification_type, recurrences, "time", last_sent, recipients_id, test_lists_id, units_id, send_empty) FROM stdin;
\.


--
-- Data for Name: notifications_qcschedulingnotice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications_qcschedulingnotice (id, notification_type, recurrences, "time", future_days, recipients_id, test_lists_id, units_id, last_sent, send_empty) FROM stdin;
\.


--
-- Data for Name: notifications_recipientgroup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications_recipientgroup (id, name, emails) FROM stdin;
\.


--
-- Data for Name: notifications_recipientgroup_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications_recipientgroup_groups (id, recipientgroup_id, group_id) FROM stdin;
\.


--
-- Data for Name: notifications_recipientgroup_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications_recipientgroup_users (id, recipientgroup_id, user_id) FROM stdin;
\.


--
-- Data for Name: notifications_serviceeventnotice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications_serviceeventnotice (id, notification_type, recipients_id, units_id) FROM stdin;
\.


--
-- Data for Name: notifications_serviceeventreviewnotice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications_serviceeventreviewnotice (id, notification_type, send_empty, recurrences, "time", last_sent, recipients_id, units_id) FROM stdin;
\.


--
-- Data for Name: notifications_serviceeventschedulingnotice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications_serviceeventschedulingnotice (id, notification_type, send_empty, recurrences, "time", future_days, last_sent, recipients_id, units_id) FROM stdin;
\.


--
-- Data for Name: notifications_testlistgroup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications_testlistgroup (id, name) FROM stdin;
\.


--
-- Data for Name: notifications_testlistgroup_test_lists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications_testlistgroup_test_lists (id, testlistgroup_id, testlist_id) FROM stdin;
\.


--
-- Data for Name: notifications_unitgroup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications_unitgroup (id, name) FROM stdin;
\.


--
-- Data for Name: notifications_unitgroup_units; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications_unitgroup_units (id, unitgroup_id, unit_id) FROM stdin;
\.


--
-- Data for Name: parts_contact; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parts_contact (id, first_name, last_name, email, phone_number, supplier_id) FROM stdin;
\.


--
-- Data for Name: parts_part; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parts_part (id, part_number, alt_part_number, quantity_min, quantity_current, cost, notes, is_obsolete, part_category_id, name, new_or_used) FROM stdin;
\.


--
-- Data for Name: parts_partcategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parts_partcategory (id, name) FROM stdin;
\.


--
-- Data for Name: parts_partstoragecollection; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parts_partstoragecollection (id, quantity, part_id, storage_id) FROM stdin;
\.


--
-- Data for Name: parts_partsuppliercollection; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parts_partsuppliercollection (id, part_number, part_id, supplier_id) FROM stdin;
\.


--
-- Data for Name: parts_partused; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parts_partused (id, quantity, part_id, service_event_id, from_storage_id) FROM stdin;
\.


--
-- Data for Name: parts_room; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parts_room (id, name, site_id) FROM stdin;
\.


--
-- Data for Name: parts_storage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parts_storage (id, location, description, room_id) FROM stdin;
\.


--
-- Data for Name: parts_supplier; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parts_supplier (id, name, notes, address, phone_number, website) FROM stdin;
\.


--
-- Data for Name: qa_autoreviewrule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_autoreviewrule (id, pass_fail, status_id) FROM stdin;
\.


--
-- Data for Name: qa_autoreviewruleset; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_autoreviewruleset (id, name, is_default) FROM stdin;
\.


--
-- Data for Name: qa_autoreviewruleset_rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_autoreviewruleset_rules (id, autoreviewruleset_id, autoreviewrule_id) FROM stdin;
\.


--
-- Data for Name: qa_autosave; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_autosave (id, work_started, work_completed, day, created, modified, data, created_by_id, modified_by_id, test_list_id, unit_test_collection_id, test_list_instance_id) FROM stdin;
\.


--
-- Data for Name: qa_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_category (id, name, slug, description, level, lft, parent_id, rght, tree_id) FROM stdin;
1	Dosimetry	dosimetry	Dosimetry	0	1	\N	2	1
2	Mechanical and safety	mechanical-and-safety	Mechanical & Safety	0	1	\N	2	2
\.


--
-- Data for Name: qa_frequency; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_frequency (id, name, slug, nominal_interval, recurrences, window_end, window_start) FROM stdin;
1	Daily	daily	0	DTSTART:20120101T051800Z\nRRULE:FREQ=DAILY	0	\N
2	Weekly	weekly	6	DTSTART:20120101T051800Z\nRRULE:FREQ=DAILY;INTERVAL=7	2	\N
3	Monthly	monthly	26	DTSTART:20120101T051800Z\nRRULE:FREQ=DAILY;INTERVAL=28	7	\N
4	Semi Annual	semi-annual	121	DTSTART:20120101T051800Z\nRRULE:FREQ=DAILY;INTERVAL=180	30	\N
5	Annual	annual	182	DTSTART:20120101T051800Z\nRRULE:FREQ=DAILY;INTERVAL=300	55	\N
6	Tues Thurs	tues-thurs	3	DTSTART:20120101T051800Z\nRRULE:FREQ=WEEKLY;BYDAY=TU,TH	0	0
7	MWF	mwf	2	DTSTART:20120101T051800Z\nRRULE:FREQ=WEEKLY;BYDAY=MO,WE,FR	0	0
\.


--
-- Data for Name: qa_reference; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_reference (id, name, type, value, created, modified, created_by_id, modified_by_id) FROM stdin;
\.


--
-- Data for Name: qa_sublist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_sublist (id, "order", child_id, parent_id, outline) FROM stdin;
\.


--
-- Data for Name: qa_test; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_test (id, name, slug, description, procedure, chart_visibility, type, hidden, skip_without_comment, display_image, choices, constant_value, calculation_procedure, created, modified, category_id, created_by_id, modified_by_id, formatting, flag_when, autoreviewruleset_id, display_name, wrap_high, wrap_low, require_comment) FROM stdin;
\.


--
-- Data for Name: qa_testinstance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_testinstance (id, review_date, pass_fail, value, string_value, skipped, comment, work_started, work_completed, created, modified, created_by_id, modified_by_id, reference_id, reviewed_by_id, status_id, test_list_instance_id, tolerance_id, unit_test_info_id, "order", date_value, datetime_value, json_value) FROM stdin;
\.


--
-- Data for Name: qa_testinstancestatus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_testinstancestatus (id, name, slug, description, is_default, requires_review, export_by_default, valid, colour) FROM stdin;
1	Unreviewed	unreviewed	\N	t	t	t	t	rgba(243,156,18,1)
2	Approved	Approved	\N	f	f	t	t	rgba(243,156,18,1)
3	Rejected	rejected	\N	f	f	f	f	rgba(243,156,18,1)
\.


--
-- Data for Name: qa_testlist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_testlist (id, name, slug, description, created, modified, warning_message, created_by_id, modified_by_id, javascript) FROM stdin;
\.


--
-- Data for Name: qa_testlistcycle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_testlistcycle (id, name, slug, description, created, modified, drop_down_label, day_option_text, created_by_id, modified_by_id, javascript) FROM stdin;
\.


--
-- Data for Name: qa_testlistcyclemembership; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_testlistcyclemembership (id, "order", cycle_id, test_list_id) FROM stdin;
\.


--
-- Data for Name: qa_testlistinstance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_testlistinstance (id, work_started, work_completed, in_progress, reviewed, all_reviewed, day, created, modified, created_by_id, modified_by_id, reviewed_by_id, test_list_id, unit_test_collection_id, due_date, flagged, include_for_scheduling, user_key) FROM stdin;
\.


--
-- Data for Name: qa_testlistmembership; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_testlistmembership (id, "order", test_id, test_list_id) FROM stdin;
\.


--
-- Data for Name: qa_tolerance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_tolerance (id, type, act_low, tol_low, tol_high, act_high, mc_pass_choices, mc_tol_choices, created_date, modified_date, created_by_id, modified_by_id, bool_warning_only, name) FROM stdin;
1	boolean	\N	\N	\N	\N			2026-01-29 23:51:00.672163+00	2026-01-29 23:51:01.130709+00	1	1	t	Boolean(Tolerance on fail)
2	boolean	\N	\N	\N	\N			2026-01-29 23:51:00.674681+00	2026-01-29 23:51:01.131603+00	1	1	f	Boolean(Action on fail)
3	absolute	-3	-2	2	3			2018-06-01 17:59:43.086+00	2018-06-01 17:59:43.086+00	1	1	f	Absolute(-3.000, -2.000, 2.000, 3.000)
4	absolute	-2	-1	1	2			2018-06-01 17:59:57.999+00	2018-06-01 17:59:57.999+00	1	1	f	Absolute(-2.000, -1.000, 1.000, 2.000)
5	percent	-3	-2	2	3			2018-06-01 18:00:08.242+00	2018-06-01 18:00:08.242+00	1	1	f	Percent(-3.00%, -2.00%, 2.00%, 3.00%)
6	percent	-2	-1	1	2			2018-06-01 18:00:22.746+00	2018-06-01 18:00:22.746+00	1	1	f	Percent(-2.00%, -1.00%, 1.00%, 2.00%)
7	multchoice	\N	\N	\N	\N	PASS	TOL	2018-06-01 18:01:42.252+00	2018-06-01 18:01:42.252+00	1	1	f	M.C.(OK=PASS, Tolerance=TOL)
\.


--
-- Data for Name: qa_unittestcollection; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_unittestcollection (id, due_date, auto_schedule, active, object_id, assigned_to_id, content_type_id, frequency_id, last_instance_id, unit_id, name) FROM stdin;
\.


--
-- Data for Name: qa_unittestcollection_visible_to; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_unittestcollection_visible_to (id, unittestcollection_id, group_id) FROM stdin;
\.


--
-- Data for Name: qa_unittestinfo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_unittestinfo (id, active, assigned_to_id, reference_id, test_id, tolerance_id, unit_id) FROM stdin;
\.


--
-- Data for Name: qa_unittestinfochange; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_unittestinfochange (id, reference_changed, tolerance_changed, comment, changed, changed_by_id, reference_id, tolerance_id, unit_test_info_id) FROM stdin;
\.


--
-- Data for Name: qatrack_cache_table; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qatrack_cache_table (cache_key, value, expires) FROM stdin;
:1:unreviewed-count	gAVLAC4=	2026-01-29 23:57:16+00
:1:unreviewed-count-user	gAWVBwAAAAAAAAB9lE5LAHMu	2026-01-29 23:57:16+00
:1:default-se-status	gAWVdgEAAAAAAACMFWRqYW5nby5kYi5tb2RlbHMuYmFzZZSMDm1vZGVsX3VucGlja2xllJOUjAtzZXJ2aWNlX2xvZ5SMElNlcnZpY2VFdmVudFN0YXR1c5SGlIWUUpR9lCiMBl9zdGF0ZZRoAIwKTW9kZWxTdGF0ZZSTlCmBlH2UKIwGYWRkaW5nlImMAmRilIwHZGVmYXVsdJSMDGZpZWxkc19jYWNoZZR9lHVijAJpZJRLAYwEbmFtZZSMD1NlcnZpY2UgUGVuZGluZ5SMCmlzX2RlZmF1bHSUiIwSaXNfcmV2aWV3X3JlcXVpcmVklIiMF3J0c19xYV9tdXN0X2JlX3Jldmlld2VklImMC2Rlc2NyaXB0aW9ulIwcRGVmYXVsdCBzZXJ2aWNlIGV2ZW50IHN0YXR1c5SMBmNvbG91cpSME3JnYmEoMjEwLDIxNCwyMjIsMSmUjAVvcmRlcpRLAIwPX2RqYW5nb192ZXJzaW9ulIwGMi4yLjE4lHViLg==	2026-01-29 23:57:16+00
:1:se_needing_review_count	gAVLAC4=	2026-01-29 23:57:16+00
:1:incomplete-rts-qa	gAVLAC4=	2026-01-29 23:57:16+00
:1:unreviewed-rts-qa	gAVLAC4=	2026-01-29 23:57:16+00
:1:sl-notification-total	gAVLAC4=	2026-01-29 23:57:16+00
:1:unreviewed-fault-count	gAVLAC4=	2026-01-29 23:57:16+00
:1:in-progress-count-users	gAWVBwAAAAAAAAB9lE5LAHMu	2026-01-29 23:57:16+00
:1:service-status-colours	gAWVswAAAAAAAAB9lCiMD1NlcnZpY2UgUGVuZGluZ5SME3JnYmEoMjEwLDIxNCwyMjIsMSmUjBBTZXJ2aWNlIENvbXBsZXRllIwScmdiYSg2MCwxNDEsMTg4LDEplIwIQXBwcm92ZWSUjBByZ2JhKDAsMTY2LDkwLDEplIwIUmVqZWN0ZWSUjBFyZ2JhKDIyMSw3NSw1NywxKZSMCVRlc3QgRGF0YZSMEnJnYmEoMjQzLDI0NywxMCwxKZR1Lg==	2026-01-29 23:57:16+00
\.


--
-- Data for Name: recurrence_date; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recurrence_date (id, mode, dt, recurrence_id) FROM stdin;
\.


--
-- Data for Name: recurrence_param; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recurrence_param (id, param, value, index, rule_id) FROM stdin;
\.


--
-- Data for Name: recurrence_recurrence; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recurrence_recurrence (id, dtstart, dtend) FROM stdin;
\.


--
-- Data for Name: recurrence_rule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recurrence_rule (id, mode, freq, "interval", wkst, count, until, recurrence_id) FROM stdin;
\.


--
-- Data for Name: reports_reportnote; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reports_reportnote (id, heading, content, report_id) FROM stdin;
\.


--
-- Data for Name: reports_reportschedule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reports_reportschedule (id, schedule, "time", emails, created, modified, created_by_id, modified_by_id, report_id, last_sent) FROM stdin;
\.


--
-- Data for Name: reports_reportschedule_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reports_reportschedule_groups (id, reportschedule_id, group_id) FROM stdin;
\.


--
-- Data for Name: reports_reportschedule_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reports_reportschedule_users (id, reportschedule_id, user_id) FROM stdin;
\.


--
-- Data for Name: reports_savedreport; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reports_savedreport (id, title, report_type, report_format, include_signature, filters, created, modified, created_by_id, modified_by_id) FROM stdin;
\.


--
-- Data for Name: reports_savedreport_visible_to; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reports_savedreport_visible_to (id, savedreport_id, group_id) FROM stdin;
\.


--
-- Data for Name: service_log_grouplinker; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_log_grouplinker (id, name, description, help_text, group_id, multiple, required) FROM stdin;
\.


--
-- Data for Name: service_log_grouplinkerinstance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_log_grouplinkerinstance (id, datetime_linked, group_linker_id, service_event_id, user_id) FROM stdin;
\.


--
-- Data for Name: service_log_hours; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_log_hours (id, "time", service_event_id, third_party_id, user_id) FROM stdin;
\.


--
-- Data for Name: service_log_returntoserviceqa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_log_returntoserviceqa (id, datetime_assigned, service_event_id, test_list_instance_id, unit_test_collection_id, user_assigned_by_id) FROM stdin;
\.


--
-- Data for Name: service_log_servicearea; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_log_servicearea (id, name) FROM stdin;
1	Accelerator
2	iView
3	XVI
4	Treatment Table
5	Lasers
6	CTSim
7	Orthovoltage
8	TBI
9	Misc.
10	TLS
11	HDR
12	Injector
13	iGuide/HexaPOD
14	C-Arm
\.


--
-- Data for Name: service_log_serviceevent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_log_serviceevent (id, datetime_status_changed, datetime_created, datetime_service, datetime_modified, safety_precautions, problem_description, work_description, duration_service_time, duration_lost_time, is_review_required, service_status_id, service_type_id, unit_service_area_id, user_created_by_id, user_modified_by_id, user_status_changed_by_id, test_list_instance_initiated_by_id, is_active, due_date, include_for_scheduling, service_event_schedule_id, service_event_template_id) FROM stdin;
\.


--
-- Data for Name: service_log_serviceevent_service_event_related; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_log_serviceevent_service_event_related (id, from_serviceevent_id, to_serviceevent_id) FROM stdin;
\.


--
-- Data for Name: service_log_serviceeventschedule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_log_serviceeventschedule (id, due_date, auto_schedule, active, assigned_to_id, frequency_id, last_instance_id, service_event_template_id, unit_service_area_id) FROM stdin;
\.


--
-- Data for Name: service_log_serviceeventschedule_visible_to; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_log_serviceeventschedule_visible_to (id, serviceeventschedule_id, group_id) FROM stdin;
\.


--
-- Data for Name: service_log_serviceeventstatus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_log_serviceeventstatus (id, name, is_default, is_review_required, rts_qa_must_be_reviewed, description, colour, "order") FROM stdin;
1	Service Pending	t	t	f	Default service event status	rgba(210,214,222,1)	0
2	Service Complete	f	t	f	Work on service event is complete. Awaiting review if required	rgba(60,141,188,1)	0
3	Approved	f	f	t	Return to service has been performed and reviewed. Physics has reviewed and approved service event	rgba(0,166,90,1)	0
4	Rejected	f	f	f	Physics has reviewed rejected service event	rgba(221,75,57,1)	0
5	Test Data	f	f	f		rgba(243,247,10,1)	0
\.


--
-- Data for Name: service_log_serviceeventtemplate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_log_serviceeventtemplate (id, problem_description, work_description, is_review_required, name, created, modified, created_by_id, modified_by_id, service_area_id, service_type_id) FROM stdin;
\.


--
-- Data for Name: service_log_serviceeventtemplate_return_to_service_cycles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_log_serviceeventtemplate_return_to_service_cycles (id, serviceeventtemplate_id, testlistcycle_id) FROM stdin;
\.


--
-- Data for Name: service_log_serviceeventtemplate_return_to_service_test_lists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_log_serviceeventtemplate_return_to_service_test_lists (id, serviceeventtemplate_id, testlist_id) FROM stdin;
\.


--
-- Data for Name: service_log_servicelog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_log_servicelog (id, log_type, extra_info, datetime, service_event_id, user_id) FROM stdin;
\.


--
-- Data for Name: service_log_servicetype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_log_servicetype (id, name, is_review_required, is_active, description) FROM stdin;
1	Minor	f	t	Anything that is not part of a routine schedule and requires intervention without parts replacement.
2	Preventive	f	t	Anything that is recommended by the manufacturer for routine (e.g. daily, weekly, monthly, quarterly and annual) maintenance and is on a schedule.
3	Extensive	t	t	Any repair that is not part of a routine schedule and involves the replacement of parts. In addition, any action that involves changes to ANY operating parameter (i.e. steering coils, gun current, readout calibration, etc.).
4	Safety Systems	t	t	Any repair that involves a CNSC regulated safety system. Examples are in-room monitors, room interlocks, prim alert, etc.
\.


--
-- Data for Name: service_log_thirdparty; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_log_thirdparty (id, first_name, last_name, vendor_id) FROM stdin;
\.


--
-- Data for Name: service_log_unitservicearea; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_log_unitservicearea (id, service_area_id, unit_id, notes) FROM stdin;
\.


--
-- Data for Name: units_modality; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.units_modality (id, name) FROM stdin;
1	6MV Photon
2	10MV Photon
3	15MV Photon
4	18MV Photon
5	6MV FFF Photon
6	10MV FFF Photon
7	6MeV Electron
8	9MeV Electron
9	11MeV Electron
10	12MeV Electron
11	13MeV Electron
12	15MeV Electron
13	17MeV Electron
14	Ir192 HDR
15	100kV Photon
16	120kV Photon
17	150kV Photon
18	200kV Photon
19	300kV Photon
20	380kV Photon
21	1.25MV Photon (Cobalt)
22	6MeV HDTSE
23	9MeV HDTSE
24	18MeV Electron
25	20MeV Electron
26	22MeV Electron
\.


--
-- Data for Name: units_site; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.units_site (id, name, slug) FROM stdin;
\.


--
-- Data for Name: units_unit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.units_unit (id, number, name, serial_number, location, install_date, type_id, active, date_acceptance, site_id, is_serviceable) FROM stdin;
\.


--
-- Data for Name: units_unit_modalities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.units_unit_modalities (id, unit_id, modality_id) FROM stdin;
\.


--
-- Data for Name: units_unitavailabletime; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.units_unitavailabletime (id, date_changed, hours_monday, hours_tuesday, hours_wednesday, hours_thursday, hours_friday, hours_saturday, hours_sunday, unit_id) FROM stdin;
\.


--
-- Data for Name: units_unitavailabletimeedit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.units_unitavailabletimeedit (id, name, date, hours, unit_id) FROM stdin;
\.


--
-- Data for Name: units_unitclass; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.units_unitclass (id, name) FROM stdin;
1	Linac
2	MRI
3	Orthovoltage
4	CT
5	PET
6	PET-CT
7	X-Ray
8	MRI Linac
9	HDR Brachytherapy
10	Cobalt
\.


--
-- Data for Name: units_unittype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.units_unittype (id, name, model, vendor_id, unit_class_id, collapse) FROM stdin;
1	Cyberknife	\N	1	1	f
2	Tomotherapy	Hi-Art	1	1	f
3	Tomotherapy	TomoHD	1	1	f
4	Tomotherapy	Corvus	1	1	f
5	Precise	\N	3	1	f
6	Synergy	S	3	1	f
7	Synergy	\N	3	1	f
8	Therapax-300	\N	14	3	f
9	Axesse	\N	3	1	f
10	Agility	\N	3	1	f
11	TrueBeam	\N	13	1	f
12	Clinac	\N	13	1	f
13	Trilogy	\N	13	1	f
14	Novalis	\N	13	1	f
15	EDGE	\N	13	1	f
16	Primus	\N	12	1	f
17	Oncor	\N	12	1	f
\.


--
-- Data for Name: units_vendor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.units_vendor (id, name, notes) FROM stdin;
1	Accuray	
2	Best Medical	
3	Elekta	
4	Fluke Biomedical	
5	GE Healthcare	
6	IBA	
7	Nucletron	
8	Philips	
9	Standard Imaging	
10	Sun Nuclear	
11	ScandiDos	
12	Siemens	
13	Varian	
14	Pantak	
\.


--
-- Name: accounts_activedirectorygroupmap_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounts_activedirectorygroupmap_groups_id_seq', 1, false);


--
-- Name: accounts_activedirectorygroupmap_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounts_activedirectorygroupmap_id_seq', 1, false);


--
-- Name: accounts_defaultgroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounts_defaultgroup_id_seq', 1, false);


--
-- Name: attachments_attachment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attachments_attachment_id_seq', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 387, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 2, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: contacts_contact_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contacts_contact_id_seq', 1, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1, false);


--
-- Name: django_comment_flags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_comment_flags_id_seq', 1, false);


--
-- Name: django_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_comments_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 98, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 236, true);


--
-- Name: django_q_ormq_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_q_ormq_id_seq', 1, false);


--
-- Name: django_q_schedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_q_schedule_id_seq', 7, true);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_site_id_seq', 1, true);


--
-- Name: faults_fault_fault_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.faults_fault_fault_types_id_seq', 1, false);


--
-- Name: faults_fault_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.faults_fault_id_seq', 1, false);


--
-- Name: faults_fault_related_service_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.faults_fault_related_service_events_id_seq', 1, false);


--
-- Name: faults_faultreviewgroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.faults_faultreviewgroup_id_seq', 1, false);


--
-- Name: faults_faultreviewinstance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.faults_faultreviewinstance_id_seq', 1, false);


--
-- Name: faults_faulttype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.faults_faulttype_id_seq', 1, false);


--
-- Name: issue_tracker_issue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.issue_tracker_issue_id_seq', 1, false);


--
-- Name: issue_tracker_issue_issue_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.issue_tracker_issue_issue_tags_id_seq', 1, false);


--
-- Name: issue_tracker_issuepriority_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.issue_tracker_issuepriority_id_seq', 1, false);


--
-- Name: issue_tracker_issuestatus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.issue_tracker_issuestatus_id_seq', 1, false);


--
-- Name: issue_tracker_issuetag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.issue_tracker_issuetag_id_seq', 1, false);


--
-- Name: issue_tracker_issuetype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.issue_tracker_issuetype_id_seq', 1, false);


--
-- Name: notifications_faultnotice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_faultnotice_id_seq', 1, false);


--
-- Name: notifications_faultsreviewnotice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_faultsreviewnotice_id_seq', 1, false);


--
-- Name: notifications_partcategorygroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_partcategorygroup_id_seq', 1, false);


--
-- Name: notifications_partcategorygroup_part_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_partcategorygroup_part_categories_id_seq', 1, false);


--
-- Name: notifications_partnotice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_partnotice_id_seq', 1, false);


--
-- Name: notifications_qccompletednotice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_qccompletednotice_id_seq', 1, false);


--
-- Name: notifications_qcreviewnotice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_qcreviewnotice_id_seq', 1, false);


--
-- Name: notifications_qcschedulingnotice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_qcschedulingnotice_id_seq', 1, false);


--
-- Name: notifications_recipientgroup_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_recipientgroup_groups_id_seq', 1, false);


--
-- Name: notifications_recipientgroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_recipientgroup_id_seq', 1, false);


--
-- Name: notifications_recipientgroup_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_recipientgroup_users_id_seq', 1, false);


--
-- Name: notifications_serviceeventnotice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_serviceeventnotice_id_seq', 1, false);


--
-- Name: notifications_serviceeventreviewnotice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_serviceeventreviewnotice_id_seq', 1, false);


--
-- Name: notifications_serviceeventschedulingnotice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_serviceeventschedulingnotice_id_seq', 1, false);


--
-- Name: notifications_testlistgroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_testlistgroup_id_seq', 1, false);


--
-- Name: notifications_testlistgroup_test_lists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_testlistgroup_test_lists_id_seq', 1, false);


--
-- Name: notifications_unitgroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_unitgroup_id_seq', 1, false);


--
-- Name: notifications_unitgroup_units_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_unitgroup_units_id_seq', 1, false);


--
-- Name: parts_contact_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.parts_contact_id_seq', 1, false);


--
-- Name: parts_part_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.parts_part_id_seq', 1, false);


--
-- Name: parts_partcategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.parts_partcategory_id_seq', 1, false);


--
-- Name: parts_partstoragecollection_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.parts_partstoragecollection_id_seq', 1, false);


--
-- Name: parts_partsuppliercollection_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.parts_partsuppliercollection_id_seq', 1, false);


--
-- Name: parts_partused_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.parts_partused_id_seq', 1, false);


--
-- Name: parts_room_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.parts_room_id_seq', 1, false);


--
-- Name: parts_storage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.parts_storage_id_seq', 1, false);


--
-- Name: parts_supplier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.parts_supplier_id_seq', 1, false);


--
-- Name: qa_autoreviewrule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_autoreviewrule_id_seq', 1, false);


--
-- Name: qa_autoreviewruleset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_autoreviewruleset_id_seq', 1, false);


--
-- Name: qa_autoreviewruleset_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_autoreviewruleset_rules_id_seq', 1, false);


--
-- Name: qa_autosave_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_autosave_id_seq', 1, false);


--
-- Name: qa_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_category_id_seq', 2, true);


--
-- Name: qa_frequency_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_frequency_id_seq', 7, true);


--
-- Name: qa_reference_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_reference_id_seq', 1, false);


--
-- Name: qa_sublist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_sublist_id_seq', 1, false);


--
-- Name: qa_test_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_test_id_seq', 1, false);


--
-- Name: qa_testinstance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_testinstance_id_seq', 1, false);


--
-- Name: qa_testinstancestatus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_testinstancestatus_id_seq', 3, true);


--
-- Name: qa_testlist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_testlist_id_seq', 1, false);


--
-- Name: qa_testlistcycle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_testlistcycle_id_seq', 1, false);


--
-- Name: qa_testlistcyclemembership_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_testlistcyclemembership_id_seq', 1, false);


--
-- Name: qa_testlistinstance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_testlistinstance_id_seq', 1, false);


--
-- Name: qa_testlistmembership_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_testlistmembership_id_seq', 1, false);


--
-- Name: qa_tolerance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_tolerance_id_seq', 7, true);


--
-- Name: qa_unittestcollection_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_unittestcollection_id_seq', 1, false);


--
-- Name: qa_unittestcollection_visible_to_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_unittestcollection_visible_to_id_seq', 1, false);


--
-- Name: qa_unittestinfo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_unittestinfo_id_seq', 1, false);


--
-- Name: qa_unittestinfochange_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_unittestinfochange_id_seq', 1, false);


--
-- Name: recurrence_date_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recurrence_date_id_seq', 1, false);


--
-- Name: recurrence_param_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recurrence_param_id_seq', 1, false);


--
-- Name: recurrence_recurrence_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recurrence_recurrence_id_seq', 1, false);


--
-- Name: recurrence_rule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recurrence_rule_id_seq', 1, false);


--
-- Name: reports_reportnote_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reports_reportnote_id_seq', 1, false);


--
-- Name: reports_reportschedule_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reports_reportschedule_groups_id_seq', 1, false);


--
-- Name: reports_reportschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reports_reportschedule_id_seq', 1, false);


--
-- Name: reports_reportschedule_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reports_reportschedule_users_id_seq', 1, false);


--
-- Name: reports_savedreport_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reports_savedreport_id_seq', 1, false);


--
-- Name: reports_savedreport_visible_to_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reports_savedreport_visible_to_id_seq', 1, false);


--
-- Name: service_log_grouplinker_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_log_grouplinker_id_seq', 1, false);


--
-- Name: service_log_grouplinkerinstance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_log_grouplinkerinstance_id_seq', 1, false);


--
-- Name: service_log_hours_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_log_hours_id_seq', 1, false);


--
-- Name: service_log_qafollowup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_log_qafollowup_id_seq', 1, false);


--
-- Name: service_log_servicearea_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_log_servicearea_id_seq', 14, true);


--
-- Name: service_log_serviceevent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_log_serviceevent_id_seq', 1, false);


--
-- Name: service_log_serviceevent_service_event_related_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_log_serviceevent_service_event_related_id_seq', 1, false);


--
-- Name: service_log_serviceeventschedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_log_serviceeventschedule_id_seq', 1, false);


--
-- Name: service_log_serviceeventschedule_visible_to_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_log_serviceeventschedule_visible_to_id_seq', 1, false);


--
-- Name: service_log_serviceeventstatus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_log_serviceeventstatus_id_seq', 5, true);


--
-- Name: service_log_serviceeventtemplate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_log_serviceeventtemplate_id_seq', 1, false);


--
-- Name: service_log_serviceeventtemplate_return_to_service_cycle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_log_serviceeventtemplate_return_to_service_cycle_id_seq', 1, false);


--
-- Name: service_log_serviceeventtemplate_return_to_service_test__id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_log_serviceeventtemplate_return_to_service_test__id_seq', 1, false);


--
-- Name: service_log_servicelog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_log_servicelog_id_seq', 1, false);


--
-- Name: service_log_servicetype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_log_servicetype_id_seq', 4, true);


--
-- Name: service_log_thirdparty_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_log_thirdparty_id_seq', 1, false);


--
-- Name: service_log_unitservicearea_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.service_log_unitservicearea_id_seq', 1, false);


--
-- Name: units_modality_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.units_modality_id_seq', 26, true);


--
-- Name: units_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.units_site_id_seq', 1, false);


--
-- Name: units_unit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.units_unit_id_seq', 1, false);


--
-- Name: units_unit_modalities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.units_unit_modalities_id_seq', 1, false);


--
-- Name: units_unitavailabletime_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.units_unitavailabletime_id_seq', 1, false);


--
-- Name: units_unitavailabletimeedit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.units_unitavailabletimeedit_id_seq', 1, false);


--
-- Name: units_unitclass_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.units_unitclass_id_seq', 10, true);


--
-- Name: units_unittype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.units_unittype_id_seq', 17, true);


--
-- Name: units_vendor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.units_vendor_id_seq', 14, true);


--
-- Name: accounts_activedirectorygroupmap_groups accounts_activedirectory_activedirectorygroupmap__8b0394bc_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_activedirectorygroupmap_groups
    ADD CONSTRAINT accounts_activedirectory_activedirectorygroupmap__8b0394bc_uniq UNIQUE (activedirectorygroupmap_id, group_id);


--
-- Name: accounts_activedirectorygroupmap accounts_activedirectorygroupmap_ad_group_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_activedirectorygroupmap
    ADD CONSTRAINT accounts_activedirectorygroupmap_ad_group_key UNIQUE (ad_group);


--
-- Name: accounts_activedirectorygroupmap_groups accounts_activedirectorygroupmap_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_activedirectorygroupmap_groups
    ADD CONSTRAINT accounts_activedirectorygroupmap_groups_pkey PRIMARY KEY (id);


--
-- Name: accounts_activedirectorygroupmap accounts_activedirectorygroupmap_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_activedirectorygroupmap
    ADD CONSTRAINT accounts_activedirectorygroupmap_pkey PRIMARY KEY (id);


--
-- Name: accounts_defaultgroup accounts_defaultgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_defaultgroup
    ADD CONSTRAINT accounts_defaultgroup_pkey PRIMARY KEY (id);


--
-- Name: attachments_attachment attachments_attachment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments_attachment
    ADD CONSTRAINT attachments_attachment_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: authtoken_token authtoken_token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_pkey PRIMARY KEY (key);


--
-- Name: authtoken_token authtoken_token_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_key UNIQUE (user_id);


--
-- Name: contacts_contact contacts_contact_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contacts_contact
    ADD CONSTRAINT contacts_contact_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_comment_flags django_comment_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_comment_flags
    ADD CONSTRAINT django_comment_flags_pkey PRIMARY KEY (id);


--
-- Name: django_comment_flags django_comment_flags_user_id_comment_id_flag_537f77a7_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_comment_flags
    ADD CONSTRAINT django_comment_flags_user_id_comment_id_flag_537f77a7_uniq UNIQUE (user_id, comment_id, flag);


--
-- Name: django_comments django_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_comments
    ADD CONSTRAINT django_comments_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_q_ormq django_q_ormq_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_q_ormq
    ADD CONSTRAINT django_q_ormq_pkey PRIMARY KEY (id);


--
-- Name: django_q_schedule django_q_schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_q_schedule
    ADD CONSTRAINT django_q_schedule_pkey PRIMARY KEY (id);


--
-- Name: django_q_task django_q_task_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_q_task
    ADD CONSTRAINT django_q_task_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: faults_fault_fault_types faults_fault_fault_types_fault_id_faulttype_id_ee7e04d5_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_fault_fault_types
    ADD CONSTRAINT faults_fault_fault_types_fault_id_faulttype_id_ee7e04d5_uniq UNIQUE (fault_id, faulttype_id);


--
-- Name: faults_fault_fault_types faults_fault_fault_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_fault_fault_types
    ADD CONSTRAINT faults_fault_fault_types_pkey PRIMARY KEY (id);


--
-- Name: faults_fault faults_fault_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_fault
    ADD CONSTRAINT faults_fault_pkey PRIMARY KEY (id);


--
-- Name: faults_fault_related_service_events faults_fault_related_ser_fault_id_serviceevent_id_ab266cdf_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_fault_related_service_events
    ADD CONSTRAINT faults_fault_related_ser_fault_id_serviceevent_id_ab266cdf_uniq UNIQUE (fault_id, serviceevent_id);


--
-- Name: faults_fault_related_service_events faults_fault_related_service_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_fault_related_service_events
    ADD CONSTRAINT faults_fault_related_service_events_pkey PRIMARY KEY (id);


--
-- Name: faults_faultreviewgroup faults_faultreviewgroup_group_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_faultreviewgroup
    ADD CONSTRAINT faults_faultreviewgroup_group_id_key UNIQUE (group_id);


--
-- Name: faults_faultreviewgroup faults_faultreviewgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_faultreviewgroup
    ADD CONSTRAINT faults_faultreviewgroup_pkey PRIMARY KEY (id);


--
-- Name: faults_faultreviewinstance faults_faultreviewinstance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_faultreviewinstance
    ADD CONSTRAINT faults_faultreviewinstance_pkey PRIMARY KEY (id);


--
-- Name: faults_faulttype faults_faulttype_code_59df96e3_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_faulttype
    ADD CONSTRAINT faults_faulttype_code_59df96e3_uniq UNIQUE (code);


--
-- Name: faults_faulttype faults_faulttype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_faulttype
    ADD CONSTRAINT faults_faulttype_pkey PRIMARY KEY (id);


--
-- Name: faults_faulttype faults_faulttype_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_faulttype
    ADD CONSTRAINT faults_faulttype_slug_key UNIQUE (slug);


--
-- Name: issue_tracker_issue_issue_tags issue_tracker_issue_issu_issue_id_issuetag_id_e4f821cf_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_tracker_issue_issue_tags
    ADD CONSTRAINT issue_tracker_issue_issu_issue_id_issuetag_id_e4f821cf_uniq UNIQUE (issue_id, issuetag_id);


--
-- Name: issue_tracker_issue_issue_tags issue_tracker_issue_issue_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_tracker_issue_issue_tags
    ADD CONSTRAINT issue_tracker_issue_issue_tags_pkey PRIMARY KEY (id);


--
-- Name: issue_tracker_issue issue_tracker_issue_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_tracker_issue
    ADD CONSTRAINT issue_tracker_issue_pkey PRIMARY KEY (id);


--
-- Name: issue_tracker_issuepriority issue_tracker_issuepriority_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_tracker_issuepriority
    ADD CONSTRAINT issue_tracker_issuepriority_pkey PRIMARY KEY (id);


--
-- Name: issue_tracker_issuestatus issue_tracker_issuestatus_order_40258c0a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_tracker_issuestatus
    ADD CONSTRAINT issue_tracker_issuestatus_order_40258c0a_uniq UNIQUE ("order");


--
-- Name: issue_tracker_issuestatus issue_tracker_issuestatus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_tracker_issuestatus
    ADD CONSTRAINT issue_tracker_issuestatus_pkey PRIMARY KEY (id);


--
-- Name: issue_tracker_issuetag issue_tracker_issuetag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_tracker_issuetag
    ADD CONSTRAINT issue_tracker_issuetag_pkey PRIMARY KEY (id);


--
-- Name: issue_tracker_issuetype issue_tracker_issuetype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_tracker_issuetype
    ADD CONSTRAINT issue_tracker_issuetype_pkey PRIMARY KEY (id);


--
-- Name: notifications_faultnotice notifications_faultnotice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_faultnotice
    ADD CONSTRAINT notifications_faultnotice_pkey PRIMARY KEY (id);


--
-- Name: notifications_faultsreviewnotice notifications_faultsreviewnotice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_faultsreviewnotice
    ADD CONSTRAINT notifications_faultsreviewnotice_pkey PRIMARY KEY (id);


--
-- Name: notifications_partcategorygroup_part_categories notifications_partcatego_partcategorygroup_id_par_2767c250_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_partcategorygroup_part_categories
    ADD CONSTRAINT notifications_partcatego_partcategorygroup_id_par_2767c250_uniq UNIQUE (partcategorygroup_id, partcategory_id);


--
-- Name: notifications_partcategorygroup_part_categories notifications_partcategorygroup_part_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_partcategorygroup_part_categories
    ADD CONSTRAINT notifications_partcategorygroup_part_categories_pkey PRIMARY KEY (id);


--
-- Name: notifications_partcategorygroup notifications_partcategorygroup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_partcategorygroup
    ADD CONSTRAINT notifications_partcategorygroup_pkey PRIMARY KEY (id);


--
-- Name: notifications_partnotice notifications_partnotice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_partnotice
    ADD CONSTRAINT notifications_partnotice_pkey PRIMARY KEY (id);


--
-- Name: notifications_qccompletednotice notifications_qccompletednotice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_qccompletednotice
    ADD CONSTRAINT notifications_qccompletednotice_pkey PRIMARY KEY (id);


--
-- Name: notifications_qcreviewnotice notifications_qcreviewnotice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_qcreviewnotice
    ADD CONSTRAINT notifications_qcreviewnotice_pkey PRIMARY KEY (id);


--
-- Name: notifications_qcschedulingnotice notifications_qcschedulingnotice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_qcschedulingnotice
    ADD CONSTRAINT notifications_qcschedulingnotice_pkey PRIMARY KEY (id);


--
-- Name: notifications_recipientgroup_groups notifications_recipientg_recipientgroup_id_group__0c82dbc7_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_recipientgroup_groups
    ADD CONSTRAINT notifications_recipientg_recipientgroup_id_group__0c82dbc7_uniq UNIQUE (recipientgroup_id, group_id);


--
-- Name: notifications_recipientgroup_users notifications_recipientg_recipientgroup_id_user_i_b219ebf6_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_recipientgroup_users
    ADD CONSTRAINT notifications_recipientg_recipientgroup_id_user_i_b219ebf6_uniq UNIQUE (recipientgroup_id, user_id);


--
-- Name: notifications_recipientgroup_groups notifications_recipientgroup_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_recipientgroup_groups
    ADD CONSTRAINT notifications_recipientgroup_groups_pkey PRIMARY KEY (id);


--
-- Name: notifications_recipientgroup notifications_recipientgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_recipientgroup
    ADD CONSTRAINT notifications_recipientgroup_pkey PRIMARY KEY (id);


--
-- Name: notifications_recipientgroup_users notifications_recipientgroup_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_recipientgroup_users
    ADD CONSTRAINT notifications_recipientgroup_users_pkey PRIMARY KEY (id);


--
-- Name: notifications_serviceeventnotice notifications_serviceeventnotice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_serviceeventnotice
    ADD CONSTRAINT notifications_serviceeventnotice_pkey PRIMARY KEY (id);


--
-- Name: notifications_serviceeventreviewnotice notifications_serviceeventreviewnotice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_serviceeventreviewnotice
    ADD CONSTRAINT notifications_serviceeventreviewnotice_pkey PRIMARY KEY (id);


--
-- Name: notifications_serviceeventschedulingnotice notifications_serviceeventschedulingnotice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_serviceeventschedulingnotice
    ADD CONSTRAINT notifications_serviceeventschedulingnotice_pkey PRIMARY KEY (id);


--
-- Name: notifications_testlistgroup_test_lists notifications_testlistgr_testlistgroup_id_testlis_2aeb093d_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_testlistgroup_test_lists
    ADD CONSTRAINT notifications_testlistgr_testlistgroup_id_testlis_2aeb093d_uniq UNIQUE (testlistgroup_id, testlist_id);


--
-- Name: notifications_testlistgroup notifications_testlistgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_testlistgroup
    ADD CONSTRAINT notifications_testlistgroup_pkey PRIMARY KEY (id);


--
-- Name: notifications_testlistgroup_test_lists notifications_testlistgroup_test_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_testlistgroup_test_lists
    ADD CONSTRAINT notifications_testlistgroup_test_lists_pkey PRIMARY KEY (id);


--
-- Name: notifications_unitgroup_units notifications_unitgroup__unitgroup_id_unit_id_29f77d6c_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_unitgroup_units
    ADD CONSTRAINT notifications_unitgroup__unitgroup_id_unit_id_29f77d6c_uniq UNIQUE (unitgroup_id, unit_id);


--
-- Name: notifications_unitgroup notifications_unitgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_unitgroup
    ADD CONSTRAINT notifications_unitgroup_pkey PRIMARY KEY (id);


--
-- Name: notifications_unitgroup_units notifications_unitgroup_units_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_unitgroup_units
    ADD CONSTRAINT notifications_unitgroup_units_pkey PRIMARY KEY (id);


--
-- Name: parts_contact parts_contact_first_name_last_name_supplier_id_ed251768_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_contact
    ADD CONSTRAINT parts_contact_first_name_last_name_supplier_id_ed251768_uniq UNIQUE (first_name, last_name, supplier_id);


--
-- Name: parts_contact parts_contact_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_contact
    ADD CONSTRAINT parts_contact_pkey PRIMARY KEY (id);


--
-- Name: parts_part parts_part_part_number_new_or_used_20e88a60_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_part
    ADD CONSTRAINT parts_part_part_number_new_or_used_20e88a60_uniq UNIQUE (part_number, new_or_used);


--
-- Name: parts_part parts_part_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_part
    ADD CONSTRAINT parts_part_pkey PRIMARY KEY (id);


--
-- Name: parts_partcategory parts_partcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_partcategory
    ADD CONSTRAINT parts_partcategory_pkey PRIMARY KEY (id);


--
-- Name: parts_partstoragecollection parts_partstoragecollection_part_id_storage_id_57fa2382_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_partstoragecollection
    ADD CONSTRAINT parts_partstoragecollection_part_id_storage_id_57fa2382_uniq UNIQUE (part_id, storage_id);


--
-- Name: parts_partstoragecollection parts_partstoragecollection_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_partstoragecollection
    ADD CONSTRAINT parts_partstoragecollection_pkey PRIMARY KEY (id);


--
-- Name: parts_partsuppliercollection parts_partsuppliercollec_part_id_supplier_id_part_4241656f_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_partsuppliercollection
    ADD CONSTRAINT parts_partsuppliercollec_part_id_supplier_id_part_4241656f_uniq UNIQUE (part_id, supplier_id, part_number);


--
-- Name: parts_partsuppliercollection parts_partsuppliercollection_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_partsuppliercollection
    ADD CONSTRAINT parts_partsuppliercollection_pkey PRIMARY KEY (id);


--
-- Name: parts_partused parts_partused_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_partused
    ADD CONSTRAINT parts_partused_pkey PRIMARY KEY (id);


--
-- Name: parts_room parts_room_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_room
    ADD CONSTRAINT parts_room_pkey PRIMARY KEY (id);


--
-- Name: parts_room parts_room_site_id_name_a7eab9fb_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_room
    ADD CONSTRAINT parts_room_site_id_name_a7eab9fb_uniq UNIQUE (site_id, name);


--
-- Name: parts_storage parts_storage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_storage
    ADD CONSTRAINT parts_storage_pkey PRIMARY KEY (id);


--
-- Name: parts_storage parts_storage_room_id_location_123a9060_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_storage
    ADD CONSTRAINT parts_storage_room_id_location_123a9060_uniq UNIQUE (room_id, location);


--
-- Name: parts_supplier parts_supplier_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_supplier
    ADD CONSTRAINT parts_supplier_name_key UNIQUE (name);


--
-- Name: parts_supplier parts_supplier_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_supplier
    ADD CONSTRAINT parts_supplier_pkey PRIMARY KEY (id);


--
-- Name: qa_autoreviewrule qa_autoreviewrule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_autoreviewrule
    ADD CONSTRAINT qa_autoreviewrule_pkey PRIMARY KEY (id);


--
-- Name: qa_autoreviewruleset qa_autoreviewruleset_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_autoreviewruleset
    ADD CONSTRAINT qa_autoreviewruleset_name_key UNIQUE (name);


--
-- Name: qa_autoreviewruleset qa_autoreviewruleset_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_autoreviewruleset
    ADD CONSTRAINT qa_autoreviewruleset_pkey PRIMARY KEY (id);


--
-- Name: qa_autoreviewruleset_rules qa_autoreviewruleset_rul_autoreviewruleset_id_aut_4033a786_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_autoreviewruleset_rules
    ADD CONSTRAINT qa_autoreviewruleset_rul_autoreviewruleset_id_aut_4033a786_uniq UNIQUE (autoreviewruleset_id, autoreviewrule_id);


--
-- Name: qa_autoreviewruleset_rules qa_autoreviewruleset_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_autoreviewruleset_rules
    ADD CONSTRAINT qa_autoreviewruleset_rules_pkey PRIMARY KEY (id);


--
-- Name: qa_autosave qa_autosave_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_autosave
    ADD CONSTRAINT qa_autosave_pkey PRIMARY KEY (id);


--
-- Name: qa_category qa_category_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_category
    ADD CONSTRAINT qa_category_name_key UNIQUE (name);


--
-- Name: qa_category qa_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_category
    ADD CONSTRAINT qa_category_pkey PRIMARY KEY (id);


--
-- Name: qa_category qa_category_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_category
    ADD CONSTRAINT qa_category_slug_key UNIQUE (slug);


--
-- Name: qa_frequency qa_frequency_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_frequency
    ADD CONSTRAINT qa_frequency_name_key UNIQUE (name);


--
-- Name: qa_frequency qa_frequency_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_frequency
    ADD CONSTRAINT qa_frequency_pkey PRIMARY KEY (id);


--
-- Name: qa_frequency qa_frequency_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_frequency
    ADD CONSTRAINT qa_frequency_slug_key UNIQUE (slug);


--
-- Name: qa_reference qa_reference_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_reference
    ADD CONSTRAINT qa_reference_pkey PRIMARY KEY (id);


--
-- Name: qa_sublist qa_sublist_parent_id_child_id_2aa45fb9_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_sublist
    ADD CONSTRAINT qa_sublist_parent_id_child_id_2aa45fb9_uniq UNIQUE (parent_id, child_id);


--
-- Name: qa_sublist qa_sublist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_sublist
    ADD CONSTRAINT qa_sublist_pkey PRIMARY KEY (id);


--
-- Name: qa_test qa_test_name_2a1f268a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_test
    ADD CONSTRAINT qa_test_name_2a1f268a_uniq UNIQUE (name);


--
-- Name: qa_test qa_test_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_test
    ADD CONSTRAINT qa_test_pkey PRIMARY KEY (id);


--
-- Name: qa_testinstance qa_testinstance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testinstance
    ADD CONSTRAINT qa_testinstance_pkey PRIMARY KEY (id);


--
-- Name: qa_testinstancestatus qa_testinstancestatus_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testinstancestatus
    ADD CONSTRAINT qa_testinstancestatus_name_key UNIQUE (name);


--
-- Name: qa_testinstancestatus qa_testinstancestatus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testinstancestatus
    ADD CONSTRAINT qa_testinstancestatus_pkey PRIMARY KEY (id);


--
-- Name: qa_testinstancestatus qa_testinstancestatus_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testinstancestatus
    ADD CONSTRAINT qa_testinstancestatus_slug_key UNIQUE (slug);


--
-- Name: qa_testlist qa_testlist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlist
    ADD CONSTRAINT qa_testlist_pkey PRIMARY KEY (id);


--
-- Name: qa_testlist qa_testlist_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlist
    ADD CONSTRAINT qa_testlist_slug_key UNIQUE (slug);


--
-- Name: qa_testlistcycle qa_testlistcycle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlistcycle
    ADD CONSTRAINT qa_testlistcycle_pkey PRIMARY KEY (id);


--
-- Name: qa_testlistcycle qa_testlistcycle_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlistcycle
    ADD CONSTRAINT qa_testlistcycle_slug_key UNIQUE (slug);


--
-- Name: qa_testlistcyclemembership qa_testlistcyclemembership_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlistcyclemembership
    ADD CONSTRAINT qa_testlistcyclemembership_pkey PRIMARY KEY (id);


--
-- Name: qa_testlistinstance qa_testlistinstance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlistinstance
    ADD CONSTRAINT qa_testlistinstance_pkey PRIMARY KEY (id);


--
-- Name: qa_testlistinstance qa_testlistinstance_user_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlistinstance
    ADD CONSTRAINT qa_testlistinstance_user_key_key UNIQUE (user_key);


--
-- Name: qa_testlistmembership qa_testlistmembership_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlistmembership
    ADD CONSTRAINT qa_testlistmembership_pkey PRIMARY KEY (id);


--
-- Name: qa_testlistmembership qa_testlistmembership_test_list_id_test_id_43ee3cb2_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlistmembership
    ADD CONSTRAINT qa_testlistmembership_test_list_id_test_id_43ee3cb2_uniq UNIQUE (test_list_id, test_id);


--
-- Name: qa_tolerance qa_tolerance_name_50925047_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_tolerance
    ADD CONSTRAINT qa_tolerance_name_50925047_uniq UNIQUE (name);


--
-- Name: qa_tolerance qa_tolerance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_tolerance
    ADD CONSTRAINT qa_tolerance_pkey PRIMARY KEY (id);


--
-- Name: qa_unittestcollection qa_unittestcollection_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestcollection
    ADD CONSTRAINT qa_unittestcollection_pkey PRIMARY KEY (id);


--
-- Name: qa_unittestcollection qa_unittestcollection_unit_id_frequency_id_con_028429d4_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestcollection
    ADD CONSTRAINT qa_unittestcollection_unit_id_frequency_id_con_028429d4_uniq UNIQUE (unit_id, frequency_id, content_type_id, object_id);


--
-- Name: qa_unittestcollection_visible_to qa_unittestcollection_vi_unittestcollection_id_gr_988fff44_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestcollection_visible_to
    ADD CONSTRAINT qa_unittestcollection_vi_unittestcollection_id_gr_988fff44_uniq UNIQUE (unittestcollection_id, group_id);


--
-- Name: qa_unittestcollection_visible_to qa_unittestcollection_visible_to_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestcollection_visible_to
    ADD CONSTRAINT qa_unittestcollection_visible_to_pkey PRIMARY KEY (id);


--
-- Name: qa_unittestinfo qa_unittestinfo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestinfo
    ADD CONSTRAINT qa_unittestinfo_pkey PRIMARY KEY (id);


--
-- Name: qa_unittestinfo qa_unittestinfo_test_id_unit_id_b3bfd008_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestinfo
    ADD CONSTRAINT qa_unittestinfo_test_id_unit_id_b3bfd008_uniq UNIQUE (test_id, unit_id);


--
-- Name: qa_unittestinfochange qa_unittestinfochange_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestinfochange
    ADD CONSTRAINT qa_unittestinfochange_pkey PRIMARY KEY (id);


--
-- Name: qatrack_cache_table qatrack_cache_table_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qatrack_cache_table
    ADD CONSTRAINT qatrack_cache_table_pkey PRIMARY KEY (cache_key);


--
-- Name: recurrence_date recurrence_date_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurrence_date
    ADD CONSTRAINT recurrence_date_pkey PRIMARY KEY (id);


--
-- Name: recurrence_param recurrence_param_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurrence_param
    ADD CONSTRAINT recurrence_param_pkey PRIMARY KEY (id);


--
-- Name: recurrence_recurrence recurrence_recurrence_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurrence_recurrence
    ADD CONSTRAINT recurrence_recurrence_pkey PRIMARY KEY (id);


--
-- Name: recurrence_rule recurrence_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurrence_rule
    ADD CONSTRAINT recurrence_rule_pkey PRIMARY KEY (id);


--
-- Name: reports_reportnote reports_reportnote_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_reportnote
    ADD CONSTRAINT reports_reportnote_pkey PRIMARY KEY (id);


--
-- Name: reports_reportschedule_groups reports_reportschedule_g_reportschedule_id_group__bdae36a7_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_reportschedule_groups
    ADD CONSTRAINT reports_reportschedule_g_reportschedule_id_group__bdae36a7_uniq UNIQUE (reportschedule_id, group_id);


--
-- Name: reports_reportschedule_groups reports_reportschedule_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_reportschedule_groups
    ADD CONSTRAINT reports_reportschedule_groups_pkey PRIMARY KEY (id);


--
-- Name: reports_reportschedule reports_reportschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_reportschedule
    ADD CONSTRAINT reports_reportschedule_pkey PRIMARY KEY (id);


--
-- Name: reports_reportschedule reports_reportschedule_report_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_reportschedule
    ADD CONSTRAINT reports_reportschedule_report_id_key UNIQUE (report_id);


--
-- Name: reports_reportschedule_users reports_reportschedule_u_reportschedule_id_user_i_d6abc972_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_reportschedule_users
    ADD CONSTRAINT reports_reportschedule_u_reportschedule_id_user_i_d6abc972_uniq UNIQUE (reportschedule_id, user_id);


--
-- Name: reports_reportschedule_users reports_reportschedule_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_reportschedule_users
    ADD CONSTRAINT reports_reportschedule_users_pkey PRIMARY KEY (id);


--
-- Name: reports_savedreport reports_savedreport_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_savedreport
    ADD CONSTRAINT reports_savedreport_pkey PRIMARY KEY (id);


--
-- Name: reports_savedreport_visible_to reports_savedreport_visi_savedreport_id_group_id_607fa00b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_savedreport_visible_to
    ADD CONSTRAINT reports_savedreport_visi_savedreport_id_group_id_607fa00b_uniq UNIQUE (savedreport_id, group_id);


--
-- Name: reports_savedreport_visible_to reports_savedreport_visible_to_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_savedreport_visible_to
    ADD CONSTRAINT reports_savedreport_visible_to_pkey PRIMARY KEY (id);


--
-- Name: service_log_grouplinker service_log_grouplinker_name_group_id_1a9481d5_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_grouplinker
    ADD CONSTRAINT service_log_grouplinker_name_group_id_1a9481d5_uniq UNIQUE (name, group_id);


--
-- Name: service_log_grouplinker service_log_grouplinker_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_grouplinker
    ADD CONSTRAINT service_log_grouplinker_pkey PRIMARY KEY (id);


--
-- Name: service_log_grouplinkerinstance service_log_grouplinkerinstance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_grouplinkerinstance
    ADD CONSTRAINT service_log_grouplinkerinstance_pkey PRIMARY KEY (id);


--
-- Name: service_log_hours service_log_hours_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_hours
    ADD CONSTRAINT service_log_hours_pkey PRIMARY KEY (id);


--
-- Name: service_log_hours service_log_hours_service_event_id_third_p_a9776143_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_hours
    ADD CONSTRAINT service_log_hours_service_event_id_third_p_a9776143_uniq UNIQUE (service_event_id, third_party_id, user_id);


--
-- Name: service_log_returntoserviceqa service_log_qafollowup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_returntoserviceqa
    ADD CONSTRAINT service_log_qafollowup_pkey PRIMARY KEY (id);


--
-- Name: service_log_servicearea service_log_servicearea_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_servicearea
    ADD CONSTRAINT service_log_servicearea_name_key UNIQUE (name);


--
-- Name: service_log_servicearea service_log_servicearea_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_servicearea
    ADD CONSTRAINT service_log_servicearea_pkey PRIMARY KEY (id);


--
-- Name: service_log_serviceevent_service_event_related service_log_serviceevent_from_serviceevent_id_to__34fa3126_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceevent_service_event_related
    ADD CONSTRAINT service_log_serviceevent_from_serviceevent_id_to__34fa3126_uniq UNIQUE (from_serviceevent_id, to_serviceevent_id);


--
-- Name: service_log_serviceevent service_log_serviceevent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceevent
    ADD CONSTRAINT service_log_serviceevent_pkey PRIMARY KEY (id);


--
-- Name: service_log_serviceevent_service_event_related service_log_serviceevent_service_event_related_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceevent_service_event_related
    ADD CONSTRAINT service_log_serviceevent_service_event_related_pkey PRIMARY KEY (id);


--
-- Name: service_log_serviceeventschedule_visible_to service_log_serviceevent_serviceeventschedule_id__5d0c7709_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventschedule_visible_to
    ADD CONSTRAINT service_log_serviceevent_serviceeventschedule_id__5d0c7709_uniq UNIQUE (serviceeventschedule_id, group_id);


--
-- Name: service_log_serviceeventtemplate_return_to_service_cycles service_log_serviceevent_serviceeventtemplate_id__73e306c6_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventtemplate_return_to_service_cycles
    ADD CONSTRAINT service_log_serviceevent_serviceeventtemplate_id__73e306c6_uniq UNIQUE (serviceeventtemplate_id, testlistcycle_id);


--
-- Name: service_log_serviceeventtemplate_return_to_service_test_lists service_log_serviceevent_serviceeventtemplate_id__f471dfc8_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventtemplate_return_to_service_test_lists
    ADD CONSTRAINT service_log_serviceevent_serviceeventtemplate_id__f471dfc8_uniq UNIQUE (serviceeventtemplate_id, testlist_id);


--
-- Name: service_log_serviceeventschedule service_log_serviceevent_unit_service_area_id_ser_19805891_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventschedule
    ADD CONSTRAINT service_log_serviceevent_unit_service_area_id_ser_19805891_uniq UNIQUE (unit_service_area_id, service_event_template_id, frequency_id);


--
-- Name: service_log_serviceeventschedule service_log_serviceeventschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventschedule
    ADD CONSTRAINT service_log_serviceeventschedule_pkey PRIMARY KEY (id);


--
-- Name: service_log_serviceeventschedule_visible_to service_log_serviceeventschedule_visible_to_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventschedule_visible_to
    ADD CONSTRAINT service_log_serviceeventschedule_visible_to_pkey PRIMARY KEY (id);


--
-- Name: service_log_serviceeventstatus service_log_serviceeventstatus_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventstatus
    ADD CONSTRAINT service_log_serviceeventstatus_name_key UNIQUE (name);


--
-- Name: service_log_serviceeventstatus service_log_serviceeventstatus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventstatus
    ADD CONSTRAINT service_log_serviceeventstatus_pkey PRIMARY KEY (id);


--
-- Name: service_log_serviceeventtemplate service_log_serviceeventtemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventtemplate
    ADD CONSTRAINT service_log_serviceeventtemplate_pkey PRIMARY KEY (id);


--
-- Name: service_log_serviceeventtemplate_return_to_service_cycles service_log_serviceeventtemplate_return_to_service_cycles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventtemplate_return_to_service_cycles
    ADD CONSTRAINT service_log_serviceeventtemplate_return_to_service_cycles_pkey PRIMARY KEY (id);


--
-- Name: service_log_serviceeventtemplate_return_to_service_test_lists service_log_serviceeventtemplate_return_to_service_test_li_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventtemplate_return_to_service_test_lists
    ADD CONSTRAINT service_log_serviceeventtemplate_return_to_service_test_li_pkey PRIMARY KEY (id);


--
-- Name: service_log_servicelog service_log_servicelog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_servicelog
    ADD CONSTRAINT service_log_servicelog_pkey PRIMARY KEY (id);


--
-- Name: service_log_servicetype service_log_servicetype_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_servicetype
    ADD CONSTRAINT service_log_servicetype_name_key UNIQUE (name);


--
-- Name: service_log_servicetype service_log_servicetype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_servicetype
    ADD CONSTRAINT service_log_servicetype_pkey PRIMARY KEY (id);


--
-- Name: service_log_thirdparty service_log_thirdparty_first_name_last_name_ven_6ef978a2_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_thirdparty
    ADD CONSTRAINT service_log_thirdparty_first_name_last_name_ven_6ef978a2_uniq UNIQUE (first_name, last_name, vendor_id);


--
-- Name: service_log_thirdparty service_log_thirdparty_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_thirdparty
    ADD CONSTRAINT service_log_thirdparty_pkey PRIMARY KEY (id);


--
-- Name: service_log_unitservicearea service_log_unitservicea_unit_id_service_area_id_3d8aafcb_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_unitservicearea
    ADD CONSTRAINT service_log_unitservicea_unit_id_service_area_id_3d8aafcb_uniq UNIQUE (unit_id, service_area_id);


--
-- Name: service_log_unitservicearea service_log_unitservicearea_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_unitservicearea
    ADD CONSTRAINT service_log_unitservicearea_pkey PRIMARY KEY (id);


--
-- Name: units_modality units_modality_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_modality
    ADD CONSTRAINT units_modality_name_key UNIQUE (name);


--
-- Name: units_modality units_modality_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_modality
    ADD CONSTRAINT units_modality_pkey PRIMARY KEY (id);


--
-- Name: units_site units_site_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_site
    ADD CONSTRAINT units_site_name_key UNIQUE (name);


--
-- Name: units_site units_site_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_site
    ADD CONSTRAINT units_site_pkey PRIMARY KEY (id);


--
-- Name: units_site units_site_slug_228c7867_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_site
    ADD CONSTRAINT units_site_slug_228c7867_uniq UNIQUE (slug);


--
-- Name: units_unit_modalities units_unit_modalities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unit_modalities
    ADD CONSTRAINT units_unit_modalities_pkey PRIMARY KEY (id);


--
-- Name: units_unit_modalities units_unit_modalities_unit_id_modality_id_9006773c_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unit_modalities
    ADD CONSTRAINT units_unit_modalities_unit_id_modality_id_9006773c_uniq UNIQUE (unit_id, modality_id);


--
-- Name: units_unit units_unit_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unit
    ADD CONSTRAINT units_unit_number_key UNIQUE (number);


--
-- Name: units_unit units_unit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unit
    ADD CONSTRAINT units_unit_pkey PRIMARY KEY (id);


--
-- Name: units_unitavailabletime units_unitavailabletime_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unitavailabletime
    ADD CONSTRAINT units_unitavailabletime_pkey PRIMARY KEY (id);


--
-- Name: units_unitavailabletime units_unitavailabletime_unit_id_date_changed_43e50c90_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unitavailabletime
    ADD CONSTRAINT units_unitavailabletime_unit_id_date_changed_43e50c90_uniq UNIQUE (unit_id, date_changed);


--
-- Name: units_unitavailabletimeedit units_unitavailabletimeedit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unitavailabletimeedit
    ADD CONSTRAINT units_unitavailabletimeedit_pkey PRIMARY KEY (id);


--
-- Name: units_unitavailabletimeedit units_unitavailabletimeedit_unit_id_date_36527ddf_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unitavailabletimeedit
    ADD CONSTRAINT units_unitavailabletimeedit_unit_id_date_36527ddf_uniq UNIQUE (unit_id, date);


--
-- Name: units_unitclass units_unitclass_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unitclass
    ADD CONSTRAINT units_unitclass_name_key UNIQUE (name);


--
-- Name: units_unitclass units_unitclass_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unitclass
    ADD CONSTRAINT units_unitclass_pkey PRIMARY KEY (id);


--
-- Name: units_unittype units_unittype_name_model_vendor_id_unit_class_id_6449dec0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unittype
    ADD CONSTRAINT units_unittype_name_model_vendor_id_unit_class_id_6449dec0_uniq UNIQUE (name, model, vendor_id, unit_class_id);


--
-- Name: units_unittype units_unittype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unittype
    ADD CONSTRAINT units_unittype_pkey PRIMARY KEY (id);


--
-- Name: units_vendor units_vendor_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_vendor
    ADD CONSTRAINT units_vendor_name_key UNIQUE (name);


--
-- Name: units_vendor units_vendor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_vendor
    ADD CONSTRAINT units_vendor_pkey PRIMARY KEY (id);


--
-- Name: accounts_activedirectorygr_activedirectorygroupmap_id_05f56661; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX accounts_activedirectorygr_activedirectorygroupmap_id_05f56661 ON public.accounts_activedirectorygroupmap_groups USING btree (activedirectorygroupmap_id);


--
-- Name: accounts_activedirectorygroupmap_ad_group_21734e97_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX accounts_activedirectorygroupmap_ad_group_21734e97_like ON public.accounts_activedirectorygroupmap USING btree (ad_group varchar_pattern_ops);


--
-- Name: accounts_activedirectorygroupmap_groups_group_id_17058fa6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX accounts_activedirectorygroupmap_groups_group_id_17058fa6 ON public.accounts_activedirectorygroupmap_groups USING btree (group_id);


--
-- Name: accounts_defaultgroup_group_id_377144be; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX accounts_defaultgroup_group_id_377144be ON public.accounts_defaultgroup USING btree (group_id);


--
-- Name: attachments_attachment_created_by_id_61d20d74; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attachments_attachment_created_by_id_61d20d74 ON public.attachments_attachment USING btree (created_by_id);


--
-- Name: attachments_attachment_fault_id_996e496c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attachments_attachment_fault_id_996e496c ON public.attachments_attachment USING btree (fault_id);


--
-- Name: attachments_attachment_part_id_a8e0cde5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attachments_attachment_part_id_a8e0cde5 ON public.attachments_attachment USING btree (part_id);


--
-- Name: attachments_attachment_serviceevent_id_298d8a61; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attachments_attachment_serviceevent_id_298d8a61 ON public.attachments_attachment USING btree (serviceevent_id);


--
-- Name: attachments_attachment_test_id_f8a5cf0c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attachments_attachment_test_id_f8a5cf0c ON public.attachments_attachment USING btree (test_id);


--
-- Name: attachments_attachment_testinstance_id_036fc369; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attachments_attachment_testinstance_id_036fc369 ON public.attachments_attachment USING btree (testinstance_id);


--
-- Name: attachments_attachment_testlist_id_fa5ddcce; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attachments_attachment_testlist_id_fa5ddcce ON public.attachments_attachment USING btree (testlist_id);


--
-- Name: attachments_attachment_testlistcycle_id_440c16a7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attachments_attachment_testlistcycle_id_440c16a7 ON public.attachments_attachment USING btree (testlistcycle_id);


--
-- Name: attachments_attachment_testlistinstance_id_81e848ca; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attachments_attachment_testlistinstance_id_81e848ca ON public.attachments_attachment USING btree (testlistinstance_id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: authtoken_token_key_10f0b77e_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX authtoken_token_key_10f0b77e_like ON public.authtoken_token USING btree (key varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_comment_flags_comment_id_d8054933; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_comment_flags_comment_id_d8054933 ON public.django_comment_flags USING btree (comment_id);


--
-- Name: django_comment_flags_flag_8b141fcb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_comment_flags_flag_8b141fcb ON public.django_comment_flags USING btree (flag);


--
-- Name: django_comment_flags_flag_8b141fcb_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_comment_flags_flag_8b141fcb_like ON public.django_comment_flags USING btree (flag varchar_pattern_ops);


--
-- Name: django_comment_flags_user_id_f3f81f0a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_comment_flags_user_id_f3f81f0a ON public.django_comment_flags USING btree (user_id);


--
-- Name: django_comments_content_type_id_c4afe962; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_comments_content_type_id_c4afe962 ON public.django_comments USING btree (content_type_id);


--
-- Name: django_comments_site_id_9dcf666e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_comments_site_id_9dcf666e ON public.django_comments USING btree (site_id);


--
-- Name: django_comments_submit_date_514ed2d9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_comments_submit_date_514ed2d9 ON public.django_comments USING btree (submit_date);


--
-- Name: django_comments_user_id_a0a440a1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_comments_user_id_a0a440a1 ON public.django_comments USING btree (user_id);


--
-- Name: django_q_task_id_32882367_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_q_task_id_32882367_like ON public.django_q_task USING btree (id varchar_pattern_ops);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_site_domain_a2e37b91_like ON public.django_site USING btree (domain varchar_pattern_ops);


--
-- Name: faults_fault_created_by_id_4bce00c2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX faults_fault_created_by_id_4bce00c2 ON public.faults_fault USING btree (created_by_id);


--
-- Name: faults_fault_fault_types_fault_id_216a475e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX faults_fault_fault_types_fault_id_216a475e ON public.faults_fault_fault_types USING btree (fault_id);


--
-- Name: faults_fault_fault_types_faulttype_id_87b9d801; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX faults_fault_fault_types_faulttype_id_87b9d801 ON public.faults_fault_fault_types USING btree (faulttype_id);


--
-- Name: faults_fault_modality_id_8e8d6541; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX faults_fault_modality_id_8e8d6541 ON public.faults_fault USING btree (modality_id);


--
-- Name: faults_fault_modified_by_id_785b683c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX faults_fault_modified_by_id_785b683c ON public.faults_fault USING btree (modified_by_id);


--
-- Name: faults_fault_occurred_32c9d8c9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX faults_fault_occurred_32c9d8c9 ON public.faults_fault USING btree (occurred);


--
-- Name: faults_fault_related_service_events_fault_id_35fc6127; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX faults_fault_related_service_events_fault_id_35fc6127 ON public.faults_fault_related_service_events USING btree (fault_id);


--
-- Name: faults_fault_related_service_events_serviceevent_id_43406871; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX faults_fault_related_service_events_serviceevent_id_43406871 ON public.faults_fault_related_service_events USING btree (serviceevent_id);


--
-- Name: faults_fault_unit_id_9a0e2384; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX faults_fault_unit_id_9a0e2384 ON public.faults_fault USING btree (unit_id);


--
-- Name: faults_faultreviewinstance_fault_id_3137d6ff; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX faults_faultreviewinstance_fault_id_3137d6ff ON public.faults_faultreviewinstance USING btree (fault_id);


--
-- Name: faults_faultreviewinstance_fault_review_group_id_88fac68b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX faults_faultreviewinstance_fault_review_group_id_88fac68b ON public.faults_faultreviewinstance USING btree (fault_review_group_id);


--
-- Name: faults_faultreviewinstance_reviewed_by_id_76cdc2ea; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX faults_faultreviewinstance_reviewed_by_id_76cdc2ea ON public.faults_faultreviewinstance USING btree (reviewed_by_id);


--
-- Name: faults_faulttype_code_59df96e3_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX faults_faulttype_code_59df96e3_like ON public.faults_faulttype USING btree (code varchar_pattern_ops);


--
-- Name: faults_faulttype_slug_bb331fbe_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX faults_faulttype_slug_bb331fbe_like ON public.faults_faulttype USING btree (slug varchar_pattern_ops);


--
-- Name: issue_tracker_issue_issue_priority_id_d1dd39d9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX issue_tracker_issue_issue_priority_id_d1dd39d9 ON public.issue_tracker_issue USING btree (issue_priority_id);


--
-- Name: issue_tracker_issue_issue_status_id_e33b07af; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX issue_tracker_issue_issue_status_id_e33b07af ON public.issue_tracker_issue USING btree (issue_status_id);


--
-- Name: issue_tracker_issue_issue_tags_issue_id_5cb0cccd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX issue_tracker_issue_issue_tags_issue_id_5cb0cccd ON public.issue_tracker_issue_issue_tags USING btree (issue_id);


--
-- Name: issue_tracker_issue_issue_tags_issuetag_id_631076d6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX issue_tracker_issue_issue_tags_issuetag_id_631076d6 ON public.issue_tracker_issue_issue_tags USING btree (issuetag_id);


--
-- Name: issue_tracker_issue_issue_type_id_b7d96cd5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX issue_tracker_issue_issue_type_id_b7d96cd5 ON public.issue_tracker_issue USING btree (issue_type_id);


--
-- Name: issue_tracker_issue_user_submitted_by_id_73db76a4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX issue_tracker_issue_user_submitted_by_id_73db76a4 ON public.issue_tracker_issue USING btree (user_submitted_by_id);


--
-- Name: notifications_faultnotice_recipients_id_aa706e4f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_faultnotice_recipients_id_aa706e4f ON public.notifications_faultnotice USING btree (recipients_id);


--
-- Name: notifications_faultnotice_units_id_713922db; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_faultnotice_units_id_713922db ON public.notifications_faultnotice USING btree (units_id);


--
-- Name: notifications_faultsreviewnotice_recipients_id_9b4f6bcb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_faultsreviewnotice_recipients_id_9b4f6bcb ON public.notifications_faultsreviewnotice USING btree (recipients_id);


--
-- Name: notifications_faultsreviewnotice_units_id_7647ac9c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_faultsreviewnotice_units_id_7647ac9c ON public.notifications_faultsreviewnotice USING btree (units_id);


--
-- Name: notifications_partcategory_partcategory_id_fe29b753; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_partcategory_partcategory_id_fe29b753 ON public.notifications_partcategorygroup_part_categories USING btree (partcategory_id);


--
-- Name: notifications_partcategory_partcategorygroup_id_6b7650ba; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_partcategory_partcategorygroup_id_6b7650ba ON public.notifications_partcategorygroup_part_categories USING btree (partcategorygroup_id);


--
-- Name: notifications_partnotice_part_categories_id_7da4f6d7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_partnotice_part_categories_id_7da4f6d7 ON public.notifications_partnotice USING btree (part_categories_id);


--
-- Name: notifications_partnotice_recipients_id_17fab351; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_partnotice_recipients_id_17fab351 ON public.notifications_partnotice USING btree (recipients_id);


--
-- Name: notifications_qccompletednotice_recipients_id_6de40c63; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_qccompletednotice_recipients_id_6de40c63 ON public.notifications_qccompletednotice USING btree (recipients_id);


--
-- Name: notifications_qccompletednotice_test_lists_id_e8e54059; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_qccompletednotice_test_lists_id_e8e54059 ON public.notifications_qccompletednotice USING btree (test_lists_id);


--
-- Name: notifications_qccompletednotice_units_id_aa7cbc2d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_qccompletednotice_units_id_aa7cbc2d ON public.notifications_qccompletednotice USING btree (units_id);


--
-- Name: notifications_qcreviewnotice_recipients_id_f0ad3fa3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_qcreviewnotice_recipients_id_f0ad3fa3 ON public.notifications_qcreviewnotice USING btree (recipients_id);


--
-- Name: notifications_qcreviewnotice_test_lists_id_c7100b8b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_qcreviewnotice_test_lists_id_c7100b8b ON public.notifications_qcreviewnotice USING btree (test_lists_id);


--
-- Name: notifications_qcreviewnotice_units_id_cdf24e9f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_qcreviewnotice_units_id_cdf24e9f ON public.notifications_qcreviewnotice USING btree (units_id);


--
-- Name: notifications_qcschedulingnotice_recipients_id_c962ca95; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_qcschedulingnotice_recipients_id_c962ca95 ON public.notifications_qcschedulingnotice USING btree (recipients_id);


--
-- Name: notifications_qcschedulingnotice_test_lists_id_d317eaa9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_qcschedulingnotice_test_lists_id_d317eaa9 ON public.notifications_qcschedulingnotice USING btree (test_lists_id);


--
-- Name: notifications_qcschedulingnotice_units_id_869ec7ec; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_qcschedulingnotice_units_id_869ec7ec ON public.notifications_qcschedulingnotice USING btree (units_id);


--
-- Name: notifications_recipientgroup_groups_group_id_e6e882af; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_recipientgroup_groups_group_id_e6e882af ON public.notifications_recipientgroup_groups USING btree (group_id);


--
-- Name: notifications_recipientgroup_groups_recipientgroup_id_0ea9cf43; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_recipientgroup_groups_recipientgroup_id_0ea9cf43 ON public.notifications_recipientgroup_groups USING btree (recipientgroup_id);


--
-- Name: notifications_recipientgroup_users_recipientgroup_id_59011229; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_recipientgroup_users_recipientgroup_id_59011229 ON public.notifications_recipientgroup_users USING btree (recipientgroup_id);


--
-- Name: notifications_recipientgroup_users_user_id_4fd4f36a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_recipientgroup_users_user_id_4fd4f36a ON public.notifications_recipientgroup_users USING btree (user_id);


--
-- Name: notifications_serviceevent_recipients_id_b03729e6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_serviceevent_recipients_id_b03729e6 ON public.notifications_serviceeventschedulingnotice USING btree (recipients_id);


--
-- Name: notifications_serviceeventnotice_recipients_id_95901acc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_serviceeventnotice_recipients_id_95901acc ON public.notifications_serviceeventnotice USING btree (recipients_id);


--
-- Name: notifications_serviceeventnotice_units_id_96440a79; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_serviceeventnotice_units_id_96440a79 ON public.notifications_serviceeventnotice USING btree (units_id);


--
-- Name: notifications_serviceeventreviewnotice_recipients_id_9af5410b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_serviceeventreviewnotice_recipients_id_9af5410b ON public.notifications_serviceeventreviewnotice USING btree (recipients_id);


--
-- Name: notifications_serviceeventreviewnotice_units_id_11e1069c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_serviceeventreviewnotice_units_id_11e1069c ON public.notifications_serviceeventreviewnotice USING btree (units_id);


--
-- Name: notifications_serviceeventschedulingnotice_units_id_d072dba5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_serviceeventschedulingnotice_units_id_d072dba5 ON public.notifications_serviceeventschedulingnotice USING btree (units_id);


--
-- Name: notifications_testlistgrou_testlistgroup_id_f2960b73; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_testlistgrou_testlistgroup_id_f2960b73 ON public.notifications_testlistgroup_test_lists USING btree (testlistgroup_id);


--
-- Name: notifications_testlistgroup_test_lists_testlist_id_72d3fde2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_testlistgroup_test_lists_testlist_id_72d3fde2 ON public.notifications_testlistgroup_test_lists USING btree (testlist_id);


--
-- Name: notifications_unitgroup_units_unit_id_0afe1e31; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_unitgroup_units_unit_id_0afe1e31 ON public.notifications_unitgroup_units USING btree (unit_id);


--
-- Name: notifications_unitgroup_units_unitgroup_id_b72efb34; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notifications_unitgroup_units_unitgroup_id_b72efb34 ON public.notifications_unitgroup_units USING btree (unitgroup_id);


--
-- Name: parts_contact_supplier_id_c2bf3410; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX parts_contact_supplier_id_c2bf3410 ON public.parts_contact USING btree (supplier_id);


--
-- Name: parts_part_part_category_id_11a0cd79; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX parts_part_part_category_id_11a0cd79 ON public.parts_part USING btree (part_category_id);


--
-- Name: parts_partstoragecollection_part_id_ea6f64d6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX parts_partstoragecollection_part_id_ea6f64d6 ON public.parts_partstoragecollection USING btree (part_id);


--
-- Name: parts_partstoragecollection_storage_id_fa633086; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX parts_partstoragecollection_storage_id_fa633086 ON public.parts_partstoragecollection USING btree (storage_id);


--
-- Name: parts_partsuppliercollection_part_id_1c0f8fd8; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX parts_partsuppliercollection_part_id_1c0f8fd8 ON public.parts_partsuppliercollection USING btree (part_id);


--
-- Name: parts_partsuppliercollection_supplier_id_02a55267; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX parts_partsuppliercollection_supplier_id_02a55267 ON public.parts_partsuppliercollection USING btree (supplier_id);


--
-- Name: parts_partused_from_storage_id_24242c10; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX parts_partused_from_storage_id_24242c10 ON public.parts_partused USING btree (from_storage_id);


--
-- Name: parts_partused_part_id_1f227e92; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX parts_partused_part_id_1f227e92 ON public.parts_partused USING btree (part_id);


--
-- Name: parts_partused_service_event_id_de202ce8; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX parts_partused_service_event_id_de202ce8 ON public.parts_partused USING btree (service_event_id);


--
-- Name: parts_room_site_id_92882215; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX parts_room_site_id_92882215 ON public.parts_room USING btree (site_id);


--
-- Name: parts_storage_room_id_99c16cbd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX parts_storage_room_id_99c16cbd ON public.parts_storage USING btree (room_id);


--
-- Name: parts_supplier_name_bd520624_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX parts_supplier_name_bd520624_like ON public.parts_supplier USING btree (name varchar_pattern_ops);


--
-- Name: qa_autoreviewrule_status_id_31d76b71; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_autoreviewrule_status_id_31d76b71 ON public.qa_autoreviewrule USING btree (status_id);


--
-- Name: qa_autoreviewruleset_name_4f27156f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_autoreviewruleset_name_4f27156f_like ON public.qa_autoreviewruleset USING btree (name varchar_pattern_ops);


--
-- Name: qa_autoreviewruleset_rules_autoreviewrule_id_44777010; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_autoreviewruleset_rules_autoreviewrule_id_44777010 ON public.qa_autoreviewruleset_rules USING btree (autoreviewrule_id);


--
-- Name: qa_autoreviewruleset_rules_autoreviewruleset_id_344e0db1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_autoreviewruleset_rules_autoreviewruleset_id_344e0db1 ON public.qa_autoreviewruleset_rules USING btree (autoreviewruleset_id);


--
-- Name: qa_autosave_created_by_id_a30ad943; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_autosave_created_by_id_a30ad943 ON public.qa_autosave USING btree (created_by_id);


--
-- Name: qa_autosave_modified_by_id_5deb2631; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_autosave_modified_by_id_5deb2631 ON public.qa_autosave USING btree (modified_by_id);


--
-- Name: qa_autosave_test_list_id_94254c7a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_autosave_test_list_id_94254c7a ON public.qa_autosave USING btree (test_list_id);


--
-- Name: qa_autosave_test_list_instance_id_8cb3b337; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_autosave_test_list_instance_id_8cb3b337 ON public.qa_autosave USING btree (test_list_instance_id);


--
-- Name: qa_autosave_unit_test_collection_id_62d97eac; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_autosave_unit_test_collection_id_62d97eac ON public.qa_autosave USING btree (unit_test_collection_id);


--
-- Name: qa_category_name_4d47ff79_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_category_name_4d47ff79_like ON public.qa_category USING btree (name varchar_pattern_ops);


--
-- Name: qa_category_parent_id_c6738942; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_category_parent_id_c6738942 ON public.qa_category USING btree (parent_id);


--
-- Name: qa_category_slug_1ec80aab_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_category_slug_1ec80aab_like ON public.qa_category USING btree (slug varchar_pattern_ops);


--
-- Name: qa_category_tree_id_de2c7716; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_category_tree_id_de2c7716 ON public.qa_category USING btree (tree_id);


--
-- Name: qa_frequency_name_eb42de8a_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_frequency_name_eb42de8a_like ON public.qa_frequency USING btree (name varchar_pattern_ops);


--
-- Name: qa_frequency_slug_d858304e_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_frequency_slug_d858304e_like ON public.qa_frequency USING btree (slug varchar_pattern_ops);


--
-- Name: qa_reference_created_by_id_ee1e528c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_reference_created_by_id_ee1e528c ON public.qa_reference USING btree (created_by_id);


--
-- Name: qa_reference_modified_by_id_97a782b3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_reference_modified_by_id_97a782b3 ON public.qa_reference USING btree (modified_by_id);


--
-- Name: qa_sublist_child_id_a51201a3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_sublist_child_id_a51201a3 ON public.qa_sublist USING btree (child_id);


--
-- Name: qa_sublist_order_b710c5af; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_sublist_order_b710c5af ON public.qa_sublist USING btree ("order");


--
-- Name: qa_sublist_parent_id_231fc9f4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_sublist_parent_id_231fc9f4 ON public.qa_sublist USING btree (parent_id);


--
-- Name: qa_test_autoreviewruleset_id_cc755b28; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_test_autoreviewruleset_id_cc755b28 ON public.qa_test USING btree (autoreviewruleset_id);


--
-- Name: qa_test_category_id_7997f302; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_test_category_id_7997f302 ON public.qa_test USING btree (category_id);


--
-- Name: qa_test_created_by_id_1fa1a61b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_test_created_by_id_1fa1a61b ON public.qa_test USING btree (created_by_id);


--
-- Name: qa_test_display_name_81ef85f9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_test_display_name_81ef85f9 ON public.qa_test USING btree (display_name);


--
-- Name: qa_test_display_name_81ef85f9_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_test_display_name_81ef85f9_like ON public.qa_test USING btree (display_name varchar_pattern_ops);


--
-- Name: qa_test_modified_by_id_ce21788a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_test_modified_by_id_ce21788a ON public.qa_test USING btree (modified_by_id);


--
-- Name: qa_test_name_2a1f268a_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_test_name_2a1f268a_like ON public.qa_test USING btree (name varchar_pattern_ops);


--
-- Name: qa_test_slug_3bfc533f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_test_slug_3bfc533f ON public.qa_test USING btree (slug);


--
-- Name: qa_test_slug_3bfc533f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_test_slug_3bfc533f_like ON public.qa_test USING btree (slug varchar_pattern_ops);


--
-- Name: qa_testinstance_created_by_id_0697268a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testinstance_created_by_id_0697268a ON public.qa_testinstance USING btree (created_by_id);


--
-- Name: qa_testinstance_modified_by_id_b54e0fdd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testinstance_modified_by_id_b54e0fdd ON public.qa_testinstance USING btree (modified_by_id);


--
-- Name: qa_testinstance_pass_fail_37533825; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testinstance_pass_fail_37533825 ON public.qa_testinstance USING btree (pass_fail);


--
-- Name: qa_testinstance_pass_fail_37533825_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testinstance_pass_fail_37533825_like ON public.qa_testinstance USING btree (pass_fail varchar_pattern_ops);


--
-- Name: qa_testinstance_reference_id_92e877e3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testinstance_reference_id_92e877e3 ON public.qa_testinstance USING btree (reference_id);


--
-- Name: qa_testinstance_reviewed_by_id_b2507968; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testinstance_reviewed_by_id_b2507968 ON public.qa_testinstance USING btree (reviewed_by_id);


--
-- Name: qa_testinstance_status_id_45112bad; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testinstance_status_id_45112bad ON public.qa_testinstance USING btree (status_id);


--
-- Name: qa_testinstance_test_list_instance_id_5c6e01aa; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testinstance_test_list_instance_id_5c6e01aa ON public.qa_testinstance USING btree (test_list_instance_id);


--
-- Name: qa_testinstance_tolerance_id_1fc90c78; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testinstance_tolerance_id_1fc90c78 ON public.qa_testinstance USING btree (tolerance_id);


--
-- Name: qa_testinstance_unit_test_info_id_3708d3f6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testinstance_unit_test_info_id_3708d3f6 ON public.qa_testinstance USING btree (unit_test_info_id);


--
-- Name: qa_testinstance_work_completed_b23dc4ea; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testinstance_work_completed_b23dc4ea ON public.qa_testinstance USING btree (work_completed);


--
-- Name: qa_testinstance_work_started_0fe31eb6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testinstance_work_started_0fe31eb6 ON public.qa_testinstance USING btree (work_started);


--
-- Name: qa_testinstancestatus_name_6ca212a4_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testinstancestatus_name_6ca212a4_like ON public.qa_testinstancestatus USING btree (name varchar_pattern_ops);


--
-- Name: qa_testinstancestatus_slug_29601461_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testinstancestatus_slug_29601461_like ON public.qa_testinstancestatus USING btree (slug varchar_pattern_ops);


--
-- Name: qa_testlist_created_by_id_a31ba126; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testlist_created_by_id_a31ba126 ON public.qa_testlist USING btree (created_by_id);


--
-- Name: qa_testlist_modified_by_id_5f318376; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testlist_modified_by_id_5f318376 ON public.qa_testlist USING btree (modified_by_id);


--
-- Name: qa_testlist_name_9b03bf04; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testlist_name_9b03bf04 ON public.qa_testlist USING btree (name);


--
-- Name: qa_testlist_name_9b03bf04_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testlist_name_9b03bf04_like ON public.qa_testlist USING btree (name varchar_pattern_ops);


--
-- Name: qa_testlist_slug_441ad77c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testlist_slug_441ad77c_like ON public.qa_testlist USING btree (slug varchar_pattern_ops);


--
-- Name: qa_testlistcycle_created_by_id_56e6b74d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testlistcycle_created_by_id_56e6b74d ON public.qa_testlistcycle USING btree (created_by_id);


--
-- Name: qa_testlistcycle_modified_by_id_4fd36af5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testlistcycle_modified_by_id_4fd36af5 ON public.qa_testlistcycle USING btree (modified_by_id);


--
-- Name: qa_testlistcycle_name_4a095bcf; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testlistcycle_name_4a095bcf ON public.qa_testlistcycle USING btree (name);


--
-- Name: qa_testlistcycle_name_4a095bcf_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testlistcycle_name_4a095bcf_like ON public.qa_testlistcycle USING btree (name varchar_pattern_ops);


--
-- Name: qa_testlistcycle_slug_57ea2c76_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testlistcycle_slug_57ea2c76_like ON public.qa_testlistcycle USING btree (slug varchar_pattern_ops);


--
-- Name: qa_testlistcyclemembership_cycle_id_59195e72; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testlistcyclemembership_cycle_id_59195e72 ON public.qa_testlistcyclemembership USING btree (cycle_id);


--
-- Name: qa_testlistcyclemembership_test_list_id_9838340d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testlistcyclemembership_test_list_id_9838340d ON public.qa_testlistcyclemembership USING btree (test_list_id);


--
-- Name: qa_testlistinstance_created_by_id_7d53e4b6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testlistinstance_created_by_id_7d53e4b6 ON public.qa_testlistinstance USING btree (created_by_id);


--
-- Name: qa_testlistinstance_in_progress_f2b82aae; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testlistinstance_in_progress_f2b82aae ON public.qa_testlistinstance USING btree (in_progress);


--
-- Name: qa_testlistinstance_modified_by_id_e5534397; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testlistinstance_modified_by_id_e5534397 ON public.qa_testlistinstance USING btree (modified_by_id);


--
-- Name: qa_testlistinstance_reviewed_by_id_a0c912f4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testlistinstance_reviewed_by_id_a0c912f4 ON public.qa_testlistinstance USING btree (reviewed_by_id);


--
-- Name: qa_testlistinstance_test_list_id_49678bc1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testlistinstance_test_list_id_49678bc1 ON public.qa_testlistinstance USING btree (test_list_id);


--
-- Name: qa_testlistinstance_unit_test_collection_id_34d73919; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testlistinstance_unit_test_collection_id_34d73919 ON public.qa_testlistinstance USING btree (unit_test_collection_id);


--
-- Name: qa_testlistinstance_user_key_00c690bc_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testlistinstance_user_key_00c690bc_like ON public.qa_testlistinstance USING btree (user_key varchar_pattern_ops);


--
-- Name: qa_testlistinstance_work_completed_f1348c20; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testlistinstance_work_completed_f1348c20 ON public.qa_testlistinstance USING btree (work_completed);


--
-- Name: qa_testlistinstance_work_started_b591017a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testlistinstance_work_started_b591017a ON public.qa_testlistinstance USING btree (work_started);


--
-- Name: qa_testlistmembership_order_7b9628d5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testlistmembership_order_7b9628d5 ON public.qa_testlistmembership USING btree ("order");


--
-- Name: qa_testlistmembership_test_id_c1cc5b13; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testlistmembership_test_id_c1cc5b13 ON public.qa_testlistmembership USING btree (test_id);


--
-- Name: qa_testlistmembership_test_list_id_6c915779; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_testlistmembership_test_list_id_6c915779 ON public.qa_testlistmembership USING btree (test_list_id);


--
-- Name: qa_tolerance_created_by_id_c30bfcc9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_tolerance_created_by_id_c30bfcc9 ON public.qa_tolerance USING btree (created_by_id);


--
-- Name: qa_tolerance_modified_by_id_934fa1b7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_tolerance_modified_by_id_934fa1b7 ON public.qa_tolerance USING btree (modified_by_id);


--
-- Name: qa_tolerance_name_50925047_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_tolerance_name_50925047_like ON public.qa_tolerance USING btree (name varchar_pattern_ops);


--
-- Name: qa_unittestcollection_active_4983f5c7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_unittestcollection_active_4983f5c7 ON public.qa_unittestcollection USING btree (active);


--
-- Name: qa_unittestcollection_assigned_to_id_96fcc103; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_unittestcollection_assigned_to_id_96fcc103 ON public.qa_unittestcollection USING btree (assigned_to_id);


--
-- Name: qa_unittestcollection_content_type_id_ada1fcc1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_unittestcollection_content_type_id_ada1fcc1 ON public.qa_unittestcollection USING btree (content_type_id);


--
-- Name: qa_unittestcollection_frequency_id_9d8dd3ac; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_unittestcollection_frequency_id_9d8dd3ac ON public.qa_unittestcollection USING btree (frequency_id);


--
-- Name: qa_unittestcollection_last_instance_id_aae52268; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_unittestcollection_last_instance_id_aae52268 ON public.qa_unittestcollection USING btree (last_instance_id);


--
-- Name: qa_unittestcollection_name_abfd17cf; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_unittestcollection_name_abfd17cf ON public.qa_unittestcollection USING btree (name);


--
-- Name: qa_unittestcollection_name_abfd17cf_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_unittestcollection_name_abfd17cf_like ON public.qa_unittestcollection USING btree (name varchar_pattern_ops);


--
-- Name: qa_unittestcollection_unit_id_d348eb33; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_unittestcollection_unit_id_d348eb33 ON public.qa_unittestcollection USING btree (unit_id);


--
-- Name: qa_unittestcollection_visible_to_group_id_288ea5fe; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_unittestcollection_visible_to_group_id_288ea5fe ON public.qa_unittestcollection_visible_to USING btree (group_id);


--
-- Name: qa_unittestcollection_visible_to_unittestcollection_id_e029edac; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_unittestcollection_visible_to_unittestcollection_id_e029edac ON public.qa_unittestcollection_visible_to USING btree (unittestcollection_id);


--
-- Name: qa_unittestinfo_active_188f704f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_unittestinfo_active_188f704f ON public.qa_unittestinfo USING btree (active);


--
-- Name: qa_unittestinfo_assigned_to_id_2fad7eb4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_unittestinfo_assigned_to_id_2fad7eb4 ON public.qa_unittestinfo USING btree (assigned_to_id);


--
-- Name: qa_unittestinfo_reference_id_dcd9998b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_unittestinfo_reference_id_dcd9998b ON public.qa_unittestinfo USING btree (reference_id);


--
-- Name: qa_unittestinfo_test_id_456afff4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_unittestinfo_test_id_456afff4 ON public.qa_unittestinfo USING btree (test_id);


--
-- Name: qa_unittestinfo_tolerance_id_05b87f44; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_unittestinfo_tolerance_id_05b87f44 ON public.qa_unittestinfo USING btree (tolerance_id);


--
-- Name: qa_unittestinfo_unit_id_d1a42e3e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_unittestinfo_unit_id_d1a42e3e ON public.qa_unittestinfo USING btree (unit_id);


--
-- Name: qa_unittestinfochange_changed_by_id_dee5d9fa; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_unittestinfochange_changed_by_id_dee5d9fa ON public.qa_unittestinfochange USING btree (changed_by_id);


--
-- Name: qa_unittestinfochange_reference_id_bcc541ef; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_unittestinfochange_reference_id_bcc541ef ON public.qa_unittestinfochange USING btree (reference_id);


--
-- Name: qa_unittestinfochange_tolerance_id_7a9de89d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_unittestinfochange_tolerance_id_7a9de89d ON public.qa_unittestinfochange USING btree (tolerance_id);


--
-- Name: qa_unittestinfochange_unit_test_info_id_d46a01fd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qa_unittestinfochange_unit_test_info_id_d46a01fd ON public.qa_unittestinfochange USING btree (unit_test_info_id);


--
-- Name: qatrack_cache_table_expires; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX qatrack_cache_table_expires ON public.qatrack_cache_table USING btree (expires);


--
-- Name: recurrence_date_recurrence_id_eb6cafba; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX recurrence_date_recurrence_id_eb6cafba ON public.recurrence_date USING btree (recurrence_id);


--
-- Name: recurrence_param_rule_id_89d093fd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX recurrence_param_rule_id_89d093fd ON public.recurrence_param USING btree (rule_id);


--
-- Name: recurrence_rule_recurrence_id_b9b6b296; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX recurrence_rule_recurrence_id_b9b6b296 ON public.recurrence_rule USING btree (recurrence_id);


--
-- Name: reports_reportnote_report_id_ea9b46e4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reports_reportnote_report_id_ea9b46e4 ON public.reports_reportnote USING btree (report_id);


--
-- Name: reports_reportschedule_created_by_id_7146245b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reports_reportschedule_created_by_id_7146245b ON public.reports_reportschedule USING btree (created_by_id);


--
-- Name: reports_reportschedule_groups_group_id_a57b3715; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reports_reportschedule_groups_group_id_a57b3715 ON public.reports_reportschedule_groups USING btree (group_id);


--
-- Name: reports_reportschedule_groups_reportschedule_id_71c8791d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reports_reportschedule_groups_reportschedule_id_71c8791d ON public.reports_reportschedule_groups USING btree (reportschedule_id);


--
-- Name: reports_reportschedule_modified_by_id_e99e94b9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reports_reportschedule_modified_by_id_e99e94b9 ON public.reports_reportschedule USING btree (modified_by_id);


--
-- Name: reports_reportschedule_users_reportschedule_id_f6ec61b8; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reports_reportschedule_users_reportschedule_id_f6ec61b8 ON public.reports_reportschedule_users USING btree (reportschedule_id);


--
-- Name: reports_reportschedule_users_user_id_e59ef055; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reports_reportschedule_users_user_id_e59ef055 ON public.reports_reportschedule_users USING btree (user_id);


--
-- Name: reports_savedreport_created_by_id_0558e77e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reports_savedreport_created_by_id_0558e77e ON public.reports_savedreport USING btree (created_by_id);


--
-- Name: reports_savedreport_modified_by_id_d4dce5ca; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reports_savedreport_modified_by_id_d4dce5ca ON public.reports_savedreport USING btree (modified_by_id);


--
-- Name: reports_savedreport_visible_to_group_id_695d07a0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reports_savedreport_visible_to_group_id_695d07a0 ON public.reports_savedreport_visible_to USING btree (group_id);


--
-- Name: reports_savedreport_visible_to_savedreport_id_177bc573; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reports_savedreport_visible_to_savedreport_id_177bc573 ON public.reports_savedreport_visible_to USING btree (savedreport_id);


--
-- Name: service_log_grouplinker_group_id_cac036fa; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_grouplinker_group_id_cac036fa ON public.service_log_grouplinker USING btree (group_id);


--
-- Name: service_log_grouplinkerinstance_group_linker_id_d10a3466; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_grouplinkerinstance_group_linker_id_d10a3466 ON public.service_log_grouplinkerinstance USING btree (group_linker_id);


--
-- Name: service_log_grouplinkerinstance_service_event_id_b7d616b7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_grouplinkerinstance_service_event_id_b7d616b7 ON public.service_log_grouplinkerinstance USING btree (service_event_id);


--
-- Name: service_log_grouplinkerinstance_user_id_abbc59df; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_grouplinkerinstance_user_id_abbc59df ON public.service_log_grouplinkerinstance USING btree (user_id);


--
-- Name: service_log_hours_service_event_id_9cef907a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_hours_service_event_id_9cef907a ON public.service_log_hours USING btree (service_event_id);


--
-- Name: service_log_hours_third_party_id_649aafe8; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_hours_third_party_id_649aafe8 ON public.service_log_hours USING btree (third_party_id);


--
-- Name: service_log_hours_user_id_95e3b0be; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_hours_user_id_95e3b0be ON public.service_log_hours USING btree (user_id);


--
-- Name: service_log_qafollowup_service_event_id_8815500a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_qafollowup_service_event_id_8815500a ON public.service_log_returntoserviceqa USING btree (service_event_id);


--
-- Name: service_log_qafollowup_test_list_instance_id_71107ea2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_qafollowup_test_list_instance_id_71107ea2 ON public.service_log_returntoserviceqa USING btree (test_list_instance_id);


--
-- Name: service_log_qafollowup_unit_test_collection_id_4b674ad8; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_qafollowup_unit_test_collection_id_4b674ad8 ON public.service_log_returntoserviceqa USING btree (unit_test_collection_id);


--
-- Name: service_log_qafollowup_user_assigned_by_id_ef2c66e7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_qafollowup_user_assigned_by_id_ef2c66e7 ON public.service_log_returntoserviceqa USING btree (user_assigned_by_id);


--
-- Name: service_log_servicearea_name_64d170f5_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_servicearea_name_64d170f5_like ON public.service_log_servicearea USING btree (name varchar_pattern_ops);


--
-- Name: service_log_serviceevent_s_from_serviceevent_id_250d27e1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceevent_s_from_serviceevent_id_250d27e1 ON public.service_log_serviceevent_service_event_related USING btree (from_serviceevent_id);


--
-- Name: service_log_serviceevent_s_to_serviceevent_id_3ea069ed; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceevent_s_to_serviceevent_id_3ea069ed ON public.service_log_serviceevent_service_event_related USING btree (to_serviceevent_id);


--
-- Name: service_log_serviceevent_service_event_schedule_id_cde59198; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceevent_service_event_schedule_id_cde59198 ON public.service_log_serviceevent USING btree (service_event_schedule_id);


--
-- Name: service_log_serviceevent_service_event_template_id_7a1118c2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceevent_service_event_template_id_7a1118c2 ON public.service_log_serviceevent USING btree (service_event_template_id);


--
-- Name: service_log_serviceevent_service_status_id_b30fd85a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceevent_service_status_id_b30fd85a ON public.service_log_serviceevent USING btree (service_status_id);


--
-- Name: service_log_serviceevent_service_type_id_1fcdb7d3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceevent_service_type_id_1fcdb7d3 ON public.service_log_serviceevent USING btree (service_type_id);


--
-- Name: service_log_serviceevent_test_list_instance_initiat_35d1ebd3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceevent_test_list_instance_initiat_35d1ebd3 ON public.service_log_serviceevent USING btree (test_list_instance_initiated_by_id);


--
-- Name: service_log_serviceevent_unit_service_area_id_c762e446; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceevent_unit_service_area_id_c762e446 ON public.service_log_serviceevent USING btree (unit_service_area_id);


--
-- Name: service_log_serviceevent_user_created_by_id_553ba44d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceevent_user_created_by_id_553ba44d ON public.service_log_serviceevent USING btree (user_created_by_id);


--
-- Name: service_log_serviceevent_user_modified_by_id_7bf503f5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceevent_user_modified_by_id_7bf503f5 ON public.service_log_serviceevent USING btree (user_modified_by_id);


--
-- Name: service_log_serviceevent_user_status_changed_by_id_755a57b8; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceevent_user_status_changed_by_id_755a57b8 ON public.service_log_serviceevent USING btree (user_status_changed_by_id);


--
-- Name: service_log_serviceeventsc_service_event_template_id_98e72acf; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceeventsc_service_event_template_id_98e72acf ON public.service_log_serviceeventschedule USING btree (service_event_template_id);


--
-- Name: service_log_serviceeventsc_serviceeventschedule_id_d30da730; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceeventsc_serviceeventschedule_id_d30da730 ON public.service_log_serviceeventschedule_visible_to USING btree (serviceeventschedule_id);


--
-- Name: service_log_serviceeventschedule_assigned_to_id_113f5256; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceeventschedule_assigned_to_id_113f5256 ON public.service_log_serviceeventschedule USING btree (assigned_to_id);


--
-- Name: service_log_serviceeventschedule_frequency_id_65e431ee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceeventschedule_frequency_id_65e431ee ON public.service_log_serviceeventschedule USING btree (frequency_id);


--
-- Name: service_log_serviceeventschedule_last_instance_id_ae5e08b6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceeventschedule_last_instance_id_ae5e08b6 ON public.service_log_serviceeventschedule USING btree (last_instance_id);


--
-- Name: service_log_serviceeventschedule_unit_service_area_id_b138845e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceeventschedule_unit_service_area_id_b138845e ON public.service_log_serviceeventschedule USING btree (unit_service_area_id);


--
-- Name: service_log_serviceeventschedule_visible_to_group_id_79c02951; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceeventschedule_visible_to_group_id_79c02951 ON public.service_log_serviceeventschedule_visible_to USING btree (group_id);


--
-- Name: service_log_serviceeventstatus_name_0d6dbb3b_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceeventstatus_name_0d6dbb3b_like ON public.service_log_serviceeventstatus USING btree (name varchar_pattern_ops);


--
-- Name: service_log_serviceeventte_serviceeventtemplate_id_af4f4502; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceeventte_serviceeventtemplate_id_af4f4502 ON public.service_log_serviceeventtemplate_return_to_service_test_lists USING btree (serviceeventtemplate_id);


--
-- Name: service_log_serviceeventte_serviceeventtemplate_id_c5388b48; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceeventte_serviceeventtemplate_id_c5388b48 ON public.service_log_serviceeventtemplate_return_to_service_cycles USING btree (serviceeventtemplate_id);


--
-- Name: service_log_serviceeventte_testlist_id_e2aa6d89; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceeventte_testlist_id_e2aa6d89 ON public.service_log_serviceeventtemplate_return_to_service_test_lists USING btree (testlist_id);


--
-- Name: service_log_serviceeventte_testlistcycle_id_53723a07; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceeventte_testlistcycle_id_53723a07 ON public.service_log_serviceeventtemplate_return_to_service_cycles USING btree (testlistcycle_id);


--
-- Name: service_log_serviceeventtemplate_created_by_id_74f9add4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceeventtemplate_created_by_id_74f9add4 ON public.service_log_serviceeventtemplate USING btree (created_by_id);


--
-- Name: service_log_serviceeventtemplate_modified_by_id_10c7e385; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceeventtemplate_modified_by_id_10c7e385 ON public.service_log_serviceeventtemplate USING btree (modified_by_id);


--
-- Name: service_log_serviceeventtemplate_service_area_id_e16ac3cf; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceeventtemplate_service_area_id_e16ac3cf ON public.service_log_serviceeventtemplate USING btree (service_area_id);


--
-- Name: service_log_serviceeventtemplate_service_type_id_5aad4fca; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_serviceeventtemplate_service_type_id_5aad4fca ON public.service_log_serviceeventtemplate USING btree (service_type_id);


--
-- Name: service_log_servicelog_service_event_id_009ddecd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_servicelog_service_event_id_009ddecd ON public.service_log_servicelog USING btree (service_event_id);


--
-- Name: service_log_servicelog_user_id_31ee369b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_servicelog_user_id_31ee369b ON public.service_log_servicelog USING btree (user_id);


--
-- Name: service_log_servicetype_name_c5bcbc48_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_servicetype_name_c5bcbc48_like ON public.service_log_servicetype USING btree (name varchar_pattern_ops);


--
-- Name: service_log_thirdparty_vendor_id_bc8107b0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_thirdparty_vendor_id_bc8107b0 ON public.service_log_thirdparty USING btree (vendor_id);


--
-- Name: service_log_unitservicearea_service_area_id_057e67f5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_unitservicearea_service_area_id_057e67f5 ON public.service_log_unitservicearea USING btree (service_area_id);


--
-- Name: service_log_unitservicearea_unit_id_3784b1fb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX service_log_unitservicearea_unit_id_3784b1fb ON public.service_log_unitservicearea USING btree (unit_id);


--
-- Name: units_modality_name_21e1cada_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX units_modality_name_21e1cada_like ON public.units_modality USING btree (name varchar_pattern_ops);


--
-- Name: units_site_name_d7f52340_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX units_site_name_d7f52340_like ON public.units_site USING btree (name varchar_pattern_ops);


--
-- Name: units_site_slug_228c7867_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX units_site_slug_228c7867_like ON public.units_site USING btree (slug varchar_pattern_ops);


--
-- Name: units_unit_modalities_modality_id_875b4f27; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX units_unit_modalities_modality_id_875b4f27 ON public.units_unit_modalities USING btree (modality_id);


--
-- Name: units_unit_modalities_unit_id_93f0e84c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX units_unit_modalities_unit_id_93f0e84c ON public.units_unit_modalities USING btree (unit_id);


--
-- Name: units_unit_site_id_d1d5d0aa; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX units_unit_site_id_d1d5d0aa ON public.units_unit USING btree (site_id);


--
-- Name: units_unit_type_id_29510326; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX units_unit_type_id_29510326 ON public.units_unit USING btree (type_id);


--
-- Name: units_unitavailabletime_unit_id_e3727bf5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX units_unitavailabletime_unit_id_e3727bf5 ON public.units_unitavailabletime USING btree (unit_id);


--
-- Name: units_unitavailabletimeedit_unit_id_d509fbd0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX units_unitavailabletimeedit_unit_id_d509fbd0 ON public.units_unitavailabletimeedit USING btree (unit_id);


--
-- Name: units_unitclass_name_c42c5f06_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX units_unitclass_name_c42c5f06_like ON public.units_unitclass USING btree (name varchar_pattern_ops);


--
-- Name: units_unittype_unit_class_id_a731630a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX units_unittype_unit_class_id_a731630a ON public.units_unittype USING btree (unit_class_id);


--
-- Name: units_unittype_vendor_id_3bc1a664; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX units_unittype_vendor_id_3bc1a664 ON public.units_unittype USING btree (vendor_id);


--
-- Name: units_vendor_name_e9b66b49_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX units_vendor_name_e9b66b49_like ON public.units_vendor USING btree (name varchar_pattern_ops);


--
-- Name: accounts_activedirectorygroupmap_groups accounts_activedirec_activedirectorygroup_05f56661_fk_accounts_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_activedirectorygroupmap_groups
    ADD CONSTRAINT accounts_activedirec_activedirectorygroup_05f56661_fk_accounts_ FOREIGN KEY (activedirectorygroupmap_id) REFERENCES public.accounts_activedirectorygroupmap(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_activedirectorygroupmap_groups accounts_activedirec_group_id_17058fa6_fk_auth_grou; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_activedirectorygroupmap_groups
    ADD CONSTRAINT accounts_activedirec_group_id_17058fa6_fk_auth_grou FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_defaultgroup accounts_defaultgroup_group_id_377144be_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_defaultgroup
    ADD CONSTRAINT accounts_defaultgroup_group_id_377144be_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: attachments_attachment attachments_attachme_serviceevent_id_298d8a61_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments_attachment
    ADD CONSTRAINT attachments_attachme_serviceevent_id_298d8a61_fk_service_l FOREIGN KEY (serviceevent_id) REFERENCES public.service_log_serviceevent(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: attachments_attachment attachments_attachme_testinstance_id_036fc369_fk_qa_testin; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments_attachment
    ADD CONSTRAINT attachments_attachme_testinstance_id_036fc369_fk_qa_testin FOREIGN KEY (testinstance_id) REFERENCES public.qa_testinstance(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: attachments_attachment attachments_attachme_testlistcycle_id_440c16a7_fk_qa_testli; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments_attachment
    ADD CONSTRAINT attachments_attachme_testlistcycle_id_440c16a7_fk_qa_testli FOREIGN KEY (testlistcycle_id) REFERENCES public.qa_testlistcycle(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: attachments_attachment attachments_attachme_testlistinstance_id_81e848ca_fk_qa_testli; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments_attachment
    ADD CONSTRAINT attachments_attachme_testlistinstance_id_81e848ca_fk_qa_testli FOREIGN KEY (testlistinstance_id) REFERENCES public.qa_testlistinstance(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: attachments_attachment attachments_attachment_created_by_id_61d20d74_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments_attachment
    ADD CONSTRAINT attachments_attachment_created_by_id_61d20d74_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: attachments_attachment attachments_attachment_fault_id_996e496c_fk_faults_fault_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments_attachment
    ADD CONSTRAINT attachments_attachment_fault_id_996e496c_fk_faults_fault_id FOREIGN KEY (fault_id) REFERENCES public.faults_fault(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: attachments_attachment attachments_attachment_part_id_a8e0cde5_fk_parts_part_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments_attachment
    ADD CONSTRAINT attachments_attachment_part_id_a8e0cde5_fk_parts_part_id FOREIGN KEY (part_id) REFERENCES public.parts_part(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: attachments_attachment attachments_attachment_test_id_f8a5cf0c_fk_qa_test_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments_attachment
    ADD CONSTRAINT attachments_attachment_test_id_f8a5cf0c_fk_qa_test_id FOREIGN KEY (test_id) REFERENCES public.qa_test(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: attachments_attachment attachments_attachment_testlist_id_fa5ddcce_fk_qa_testlist_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments_attachment
    ADD CONSTRAINT attachments_attachment_testlist_id_fa5ddcce_fk_qa_testlist_id FOREIGN KEY (testlist_id) REFERENCES public.qa_testlist(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authtoken_token authtoken_token_user_id_35299eff_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_35299eff_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comment_flags django_comment_flags_comment_id_d8054933_fk_django_comments_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_comment_flags
    ADD CONSTRAINT django_comment_flags_comment_id_d8054933_fk_django_comments_id FOREIGN KEY (comment_id) REFERENCES public.django_comments(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comment_flags django_comment_flags_user_id_f3f81f0a_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_comment_flags
    ADD CONSTRAINT django_comment_flags_user_id_f3f81f0a_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comments django_comments_content_type_id_c4afe962_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_comments
    ADD CONSTRAINT django_comments_content_type_id_c4afe962_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comments django_comments_site_id_9dcf666e_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_comments
    ADD CONSTRAINT django_comments_site_id_9dcf666e_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comments django_comments_user_id_a0a440a1_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_comments
    ADD CONSTRAINT django_comments_user_id_a0a440a1_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: faults_fault faults_fault_created_by_id_4bce00c2_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_fault
    ADD CONSTRAINT faults_fault_created_by_id_4bce00c2_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: faults_fault_fault_types faults_fault_fault_t_faulttype_id_87b9d801_fk_faults_fa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_fault_fault_types
    ADD CONSTRAINT faults_fault_fault_t_faulttype_id_87b9d801_fk_faults_fa FOREIGN KEY (faulttype_id) REFERENCES public.faults_faulttype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: faults_fault_fault_types faults_fault_fault_types_fault_id_216a475e_fk_faults_fault_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_fault_fault_types
    ADD CONSTRAINT faults_fault_fault_types_fault_id_216a475e_fk_faults_fault_id FOREIGN KEY (fault_id) REFERENCES public.faults_fault(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: faults_fault faults_fault_modality_id_8e8d6541_fk_units_modality_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_fault
    ADD CONSTRAINT faults_fault_modality_id_8e8d6541_fk_units_modality_id FOREIGN KEY (modality_id) REFERENCES public.units_modality(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: faults_fault faults_fault_modified_by_id_785b683c_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_fault
    ADD CONSTRAINT faults_fault_modified_by_id_785b683c_fk_auth_user_id FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: faults_fault_related_service_events faults_fault_related_fault_id_35fc6127_fk_faults_fa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_fault_related_service_events
    ADD CONSTRAINT faults_fault_related_fault_id_35fc6127_fk_faults_fa FOREIGN KEY (fault_id) REFERENCES public.faults_fault(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: faults_fault_related_service_events faults_fault_related_serviceevent_id_43406871_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_fault_related_service_events
    ADD CONSTRAINT faults_fault_related_serviceevent_id_43406871_fk_service_l FOREIGN KEY (serviceevent_id) REFERENCES public.service_log_serviceevent(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: faults_fault faults_fault_unit_id_9a0e2384_fk_units_unit_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_fault
    ADD CONSTRAINT faults_fault_unit_id_9a0e2384_fk_units_unit_id FOREIGN KEY (unit_id) REFERENCES public.units_unit(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: faults_faultreviewgroup faults_faultreviewgroup_group_id_9478cb4d_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_faultreviewgroup
    ADD CONSTRAINT faults_faultreviewgroup_group_id_9478cb4d_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: faults_faultreviewinstance faults_faultreviewin_fault_review_group_i_88fac68b_fk_faults_fa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_faultreviewinstance
    ADD CONSTRAINT faults_faultreviewin_fault_review_group_i_88fac68b_fk_faults_fa FOREIGN KEY (fault_review_group_id) REFERENCES public.faults_faultreviewgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: faults_faultreviewinstance faults_faultreviewin_reviewed_by_id_76cdc2ea_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_faultreviewinstance
    ADD CONSTRAINT faults_faultreviewin_reviewed_by_id_76cdc2ea_fk_auth_user FOREIGN KEY (reviewed_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: faults_faultreviewinstance faults_faultreviewinstance_fault_id_3137d6ff_fk_faults_fault_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.faults_faultreviewinstance
    ADD CONSTRAINT faults_faultreviewinstance_fault_id_3137d6ff_fk_faults_fault_id FOREIGN KEY (fault_id) REFERENCES public.faults_fault(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: issue_tracker_issue_issue_tags issue_tracker_issue__issue_id_5cb0cccd_fk_issue_tra; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_tracker_issue_issue_tags
    ADD CONSTRAINT issue_tracker_issue__issue_id_5cb0cccd_fk_issue_tra FOREIGN KEY (issue_id) REFERENCES public.issue_tracker_issue(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: issue_tracker_issue_issue_tags issue_tracker_issue__issuetag_id_631076d6_fk_issue_tra; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_tracker_issue_issue_tags
    ADD CONSTRAINT issue_tracker_issue__issuetag_id_631076d6_fk_issue_tra FOREIGN KEY (issuetag_id) REFERENCES public.issue_tracker_issuetag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: issue_tracker_issue issue_tracker_issue_issue_priority_id_d1dd39d9_fk_issue_tra; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_tracker_issue
    ADD CONSTRAINT issue_tracker_issue_issue_priority_id_d1dd39d9_fk_issue_tra FOREIGN KEY (issue_priority_id) REFERENCES public.issue_tracker_issuepriority(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: issue_tracker_issue issue_tracker_issue_issue_status_id_e33b07af_fk_issue_tra; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_tracker_issue
    ADD CONSTRAINT issue_tracker_issue_issue_status_id_e33b07af_fk_issue_tra FOREIGN KEY (issue_status_id) REFERENCES public.issue_tracker_issuestatus(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: issue_tracker_issue issue_tracker_issue_issue_type_id_b7d96cd5_fk_issue_tra; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_tracker_issue
    ADD CONSTRAINT issue_tracker_issue_issue_type_id_b7d96cd5_fk_issue_tra FOREIGN KEY (issue_type_id) REFERENCES public.issue_tracker_issuetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: issue_tracker_issue issue_tracker_issue_user_submitted_by_id_73db76a4_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_tracker_issue
    ADD CONSTRAINT issue_tracker_issue_user_submitted_by_id_73db76a4_fk_auth_user FOREIGN KEY (user_submitted_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_faultnotice notifications_faultn_recipients_id_aa706e4f_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_faultnotice
    ADD CONSTRAINT notifications_faultn_recipients_id_aa706e4f_fk_notificat FOREIGN KEY (recipients_id) REFERENCES public.notifications_recipientgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_faultnotice notifications_faultn_units_id_713922db_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_faultnotice
    ADD CONSTRAINT notifications_faultn_units_id_713922db_fk_notificat FOREIGN KEY (units_id) REFERENCES public.notifications_unitgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_faultsreviewnotice notifications_faults_recipients_id_9b4f6bcb_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_faultsreviewnotice
    ADD CONSTRAINT notifications_faults_recipients_id_9b4f6bcb_fk_notificat FOREIGN KEY (recipients_id) REFERENCES public.notifications_recipientgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_faultsreviewnotice notifications_faults_units_id_7647ac9c_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_faultsreviewnotice
    ADD CONSTRAINT notifications_faults_units_id_7647ac9c_fk_notificat FOREIGN KEY (units_id) REFERENCES public.notifications_unitgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_partcategorygroup_part_categories notifications_partca_partcategory_id_fe29b753_fk_parts_par; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_partcategorygroup_part_categories
    ADD CONSTRAINT notifications_partca_partcategory_id_fe29b753_fk_parts_par FOREIGN KEY (partcategory_id) REFERENCES public.parts_partcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_partcategorygroup_part_categories notifications_partca_partcategorygroup_id_6b7650ba_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_partcategorygroup_part_categories
    ADD CONSTRAINT notifications_partca_partcategorygroup_id_6b7650ba_fk_notificat FOREIGN KEY (partcategorygroup_id) REFERENCES public.notifications_partcategorygroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_partnotice notifications_partno_part_categories_id_7da4f6d7_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_partnotice
    ADD CONSTRAINT notifications_partno_part_categories_id_7da4f6d7_fk_notificat FOREIGN KEY (part_categories_id) REFERENCES public.notifications_partcategorygroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_partnotice notifications_partno_recipients_id_17fab351_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_partnotice
    ADD CONSTRAINT notifications_partno_recipients_id_17fab351_fk_notificat FOREIGN KEY (recipients_id) REFERENCES public.notifications_recipientgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_qccompletednotice notifications_qccomp_recipients_id_6de40c63_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_qccompletednotice
    ADD CONSTRAINT notifications_qccomp_recipients_id_6de40c63_fk_notificat FOREIGN KEY (recipients_id) REFERENCES public.notifications_recipientgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_qccompletednotice notifications_qccomp_test_lists_id_e8e54059_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_qccompletednotice
    ADD CONSTRAINT notifications_qccomp_test_lists_id_e8e54059_fk_notificat FOREIGN KEY (test_lists_id) REFERENCES public.notifications_testlistgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_qccompletednotice notifications_qccomp_units_id_aa7cbc2d_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_qccompletednotice
    ADD CONSTRAINT notifications_qccomp_units_id_aa7cbc2d_fk_notificat FOREIGN KEY (units_id) REFERENCES public.notifications_unitgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_qcreviewnotice notifications_qcrevi_recipients_id_f0ad3fa3_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_qcreviewnotice
    ADD CONSTRAINT notifications_qcrevi_recipients_id_f0ad3fa3_fk_notificat FOREIGN KEY (recipients_id) REFERENCES public.notifications_recipientgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_qcreviewnotice notifications_qcrevi_test_lists_id_c7100b8b_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_qcreviewnotice
    ADD CONSTRAINT notifications_qcrevi_test_lists_id_c7100b8b_fk_notificat FOREIGN KEY (test_lists_id) REFERENCES public.notifications_testlistgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_qcreviewnotice notifications_qcrevi_units_id_cdf24e9f_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_qcreviewnotice
    ADD CONSTRAINT notifications_qcrevi_units_id_cdf24e9f_fk_notificat FOREIGN KEY (units_id) REFERENCES public.notifications_unitgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_qcschedulingnotice notifications_qcsche_recipients_id_c962ca95_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_qcschedulingnotice
    ADD CONSTRAINT notifications_qcsche_recipients_id_c962ca95_fk_notificat FOREIGN KEY (recipients_id) REFERENCES public.notifications_recipientgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_qcschedulingnotice notifications_qcsche_test_lists_id_d317eaa9_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_qcschedulingnotice
    ADD CONSTRAINT notifications_qcsche_test_lists_id_d317eaa9_fk_notificat FOREIGN KEY (test_lists_id) REFERENCES public.notifications_testlistgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_qcschedulingnotice notifications_qcsche_units_id_869ec7ec_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_qcschedulingnotice
    ADD CONSTRAINT notifications_qcsche_units_id_869ec7ec_fk_notificat FOREIGN KEY (units_id) REFERENCES public.notifications_unitgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_recipientgroup_groups notifications_recipi_group_id_e6e882af_fk_auth_grou; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_recipientgroup_groups
    ADD CONSTRAINT notifications_recipi_group_id_e6e882af_fk_auth_grou FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_recipientgroup_groups notifications_recipi_recipientgroup_id_0ea9cf43_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_recipientgroup_groups
    ADD CONSTRAINT notifications_recipi_recipientgroup_id_0ea9cf43_fk_notificat FOREIGN KEY (recipientgroup_id) REFERENCES public.notifications_recipientgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_recipientgroup_users notifications_recipi_recipientgroup_id_59011229_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_recipientgroup_users
    ADD CONSTRAINT notifications_recipi_recipientgroup_id_59011229_fk_notificat FOREIGN KEY (recipientgroup_id) REFERENCES public.notifications_recipientgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_recipientgroup_users notifications_recipi_user_id_4fd4f36a_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_recipientgroup_users
    ADD CONSTRAINT notifications_recipi_user_id_4fd4f36a_fk_auth_user FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_serviceeventnotice notifications_servic_recipients_id_95901acc_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_serviceeventnotice
    ADD CONSTRAINT notifications_servic_recipients_id_95901acc_fk_notificat FOREIGN KEY (recipients_id) REFERENCES public.notifications_recipientgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_serviceeventreviewnotice notifications_servic_recipients_id_9af5410b_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_serviceeventreviewnotice
    ADD CONSTRAINT notifications_servic_recipients_id_9af5410b_fk_notificat FOREIGN KEY (recipients_id) REFERENCES public.notifications_recipientgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_serviceeventschedulingnotice notifications_servic_recipients_id_b03729e6_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_serviceeventschedulingnotice
    ADD CONSTRAINT notifications_servic_recipients_id_b03729e6_fk_notificat FOREIGN KEY (recipients_id) REFERENCES public.notifications_recipientgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_serviceeventreviewnotice notifications_servic_units_id_11e1069c_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_serviceeventreviewnotice
    ADD CONSTRAINT notifications_servic_units_id_11e1069c_fk_notificat FOREIGN KEY (units_id) REFERENCES public.notifications_unitgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_serviceeventnotice notifications_servic_units_id_96440a79_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_serviceeventnotice
    ADD CONSTRAINT notifications_servic_units_id_96440a79_fk_notificat FOREIGN KEY (units_id) REFERENCES public.notifications_unitgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_serviceeventschedulingnotice notifications_servic_units_id_d072dba5_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_serviceeventschedulingnotice
    ADD CONSTRAINT notifications_servic_units_id_d072dba5_fk_notificat FOREIGN KEY (units_id) REFERENCES public.notifications_unitgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_testlistgroup_test_lists notifications_testli_testlist_id_72d3fde2_fk_qa_testli; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_testlistgroup_test_lists
    ADD CONSTRAINT notifications_testli_testlist_id_72d3fde2_fk_qa_testli FOREIGN KEY (testlist_id) REFERENCES public.qa_testlist(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_testlistgroup_test_lists notifications_testli_testlistgroup_id_f2960b73_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_testlistgroup_test_lists
    ADD CONSTRAINT notifications_testli_testlistgroup_id_f2960b73_fk_notificat FOREIGN KEY (testlistgroup_id) REFERENCES public.notifications_testlistgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_unitgroup_units notifications_unitgr_unitgroup_id_b72efb34_fk_notificat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_unitgroup_units
    ADD CONSTRAINT notifications_unitgr_unitgroup_id_b72efb34_fk_notificat FOREIGN KEY (unitgroup_id) REFERENCES public.notifications_unitgroup(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: notifications_unitgroup_units notifications_unitgroup_units_unit_id_0afe1e31_fk_units_unit_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications_unitgroup_units
    ADD CONSTRAINT notifications_unitgroup_units_unit_id_0afe1e31_fk_units_unit_id FOREIGN KEY (unit_id) REFERENCES public.units_unit(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: parts_contact parts_contact_supplier_id_c2bf3410_fk_parts_supplier_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_contact
    ADD CONSTRAINT parts_contact_supplier_id_c2bf3410_fk_parts_supplier_id FOREIGN KEY (supplier_id) REFERENCES public.parts_supplier(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: parts_part parts_part_part_category_id_11a0cd79_fk_parts_partcategory_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_part
    ADD CONSTRAINT parts_part_part_category_id_11a0cd79_fk_parts_partcategory_id FOREIGN KEY (part_category_id) REFERENCES public.parts_partcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: parts_partstoragecollection parts_partstoragecol_storage_id_fa633086_fk_parts_sto; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_partstoragecollection
    ADD CONSTRAINT parts_partstoragecol_storage_id_fa633086_fk_parts_sto FOREIGN KEY (storage_id) REFERENCES public.parts_storage(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: parts_partstoragecollection parts_partstoragecollection_part_id_ea6f64d6_fk_parts_part_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_partstoragecollection
    ADD CONSTRAINT parts_partstoragecollection_part_id_ea6f64d6_fk_parts_part_id FOREIGN KEY (part_id) REFERENCES public.parts_part(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: parts_partsuppliercollection parts_partsupplierco_supplier_id_02a55267_fk_parts_sup; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_partsuppliercollection
    ADD CONSTRAINT parts_partsupplierco_supplier_id_02a55267_fk_parts_sup FOREIGN KEY (supplier_id) REFERENCES public.parts_supplier(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: parts_partsuppliercollection parts_partsuppliercollection_part_id_1c0f8fd8_fk_parts_part_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_partsuppliercollection
    ADD CONSTRAINT parts_partsuppliercollection_part_id_1c0f8fd8_fk_parts_part_id FOREIGN KEY (part_id) REFERENCES public.parts_part(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: parts_partused parts_partused_from_storage_id_24242c10_fk_parts_storage_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_partused
    ADD CONSTRAINT parts_partused_from_storage_id_24242c10_fk_parts_storage_id FOREIGN KEY (from_storage_id) REFERENCES public.parts_storage(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: parts_partused parts_partused_part_id_1f227e92_fk_parts_part_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_partused
    ADD CONSTRAINT parts_partused_part_id_1f227e92_fk_parts_part_id FOREIGN KEY (part_id) REFERENCES public.parts_part(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: parts_partused parts_partused_service_event_id_de202ce8_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_partused
    ADD CONSTRAINT parts_partused_service_event_id_de202ce8_fk_service_l FOREIGN KEY (service_event_id) REFERENCES public.service_log_serviceevent(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: parts_room parts_room_site_id_92882215_fk_units_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_room
    ADD CONSTRAINT parts_room_site_id_92882215_fk_units_site_id FOREIGN KEY (site_id) REFERENCES public.units_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: parts_storage parts_storage_room_id_99c16cbd_fk_parts_room_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts_storage
    ADD CONSTRAINT parts_storage_room_id_99c16cbd_fk_parts_room_id FOREIGN KEY (room_id) REFERENCES public.parts_room(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_autoreviewrule qa_autoreviewrule_status_id_31d76b71_fk_qa_testin; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_autoreviewrule
    ADD CONSTRAINT qa_autoreviewrule_status_id_31d76b71_fk_qa_testin FOREIGN KEY (status_id) REFERENCES public.qa_testinstancestatus(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_autoreviewruleset_rules qa_autoreviewruleset_autoreviewrule_id_44777010_fk_qa_autore; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_autoreviewruleset_rules
    ADD CONSTRAINT qa_autoreviewruleset_autoreviewrule_id_44777010_fk_qa_autore FOREIGN KEY (autoreviewrule_id) REFERENCES public.qa_autoreviewrule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_autoreviewruleset_rules qa_autoreviewruleset_autoreviewruleset_id_344e0db1_fk_qa_autore; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_autoreviewruleset_rules
    ADD CONSTRAINT qa_autoreviewruleset_autoreviewruleset_id_344e0db1_fk_qa_autore FOREIGN KEY (autoreviewruleset_id) REFERENCES public.qa_autoreviewruleset(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_autosave qa_autosave_created_by_id_a30ad943_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_autosave
    ADD CONSTRAINT qa_autosave_created_by_id_a30ad943_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_autosave qa_autosave_modified_by_id_5deb2631_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_autosave
    ADD CONSTRAINT qa_autosave_modified_by_id_5deb2631_fk_auth_user_id FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_autosave qa_autosave_test_list_id_94254c7a_fk_qa_testlist_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_autosave
    ADD CONSTRAINT qa_autosave_test_list_id_94254c7a_fk_qa_testlist_id FOREIGN KEY (test_list_id) REFERENCES public.qa_testlist(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_autosave qa_autosave_test_list_instance_i_8cb3b337_fk_qa_testli; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_autosave
    ADD CONSTRAINT qa_autosave_test_list_instance_i_8cb3b337_fk_qa_testli FOREIGN KEY (test_list_instance_id) REFERENCES public.qa_testlistinstance(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_autosave qa_autosave_unit_test_collection_62d97eac_fk_qa_unitte; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_autosave
    ADD CONSTRAINT qa_autosave_unit_test_collection_62d97eac_fk_qa_unitte FOREIGN KEY (unit_test_collection_id) REFERENCES public.qa_unittestcollection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_category qa_category_parent_id_c6738942_fk_qa_category_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_category
    ADD CONSTRAINT qa_category_parent_id_c6738942_fk_qa_category_id FOREIGN KEY (parent_id) REFERENCES public.qa_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_reference qa_reference_created_by_id_ee1e528c_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_reference
    ADD CONSTRAINT qa_reference_created_by_id_ee1e528c_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_reference qa_reference_modified_by_id_97a782b3_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_reference
    ADD CONSTRAINT qa_reference_modified_by_id_97a782b3_fk_auth_user_id FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_sublist qa_sublist_child_id_a51201a3_fk_qa_testlist_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_sublist
    ADD CONSTRAINT qa_sublist_child_id_a51201a3_fk_qa_testlist_id FOREIGN KEY (child_id) REFERENCES public.qa_testlist(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_sublist qa_sublist_parent_id_231fc9f4_fk_qa_testlist_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_sublist
    ADD CONSTRAINT qa_sublist_parent_id_231fc9f4_fk_qa_testlist_id FOREIGN KEY (parent_id) REFERENCES public.qa_testlist(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_test qa_test_autoreviewruleset_id_cc755b28_fk_qa_autore; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_test
    ADD CONSTRAINT qa_test_autoreviewruleset_id_cc755b28_fk_qa_autore FOREIGN KEY (autoreviewruleset_id) REFERENCES public.qa_autoreviewruleset(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_test qa_test_category_id_7997f302_fk_qa_category_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_test
    ADD CONSTRAINT qa_test_category_id_7997f302_fk_qa_category_id FOREIGN KEY (category_id) REFERENCES public.qa_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_test qa_test_created_by_id_1fa1a61b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_test
    ADD CONSTRAINT qa_test_created_by_id_1fa1a61b_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_test qa_test_modified_by_id_ce21788a_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_test
    ADD CONSTRAINT qa_test_modified_by_id_ce21788a_fk_auth_user_id FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_testinstance qa_testinstance_created_by_id_0697268a_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testinstance
    ADD CONSTRAINT qa_testinstance_created_by_id_0697268a_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_testinstance qa_testinstance_modified_by_id_b54e0fdd_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testinstance
    ADD CONSTRAINT qa_testinstance_modified_by_id_b54e0fdd_fk_auth_user_id FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_testinstance qa_testinstance_reference_id_92e877e3_fk_qa_reference_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testinstance
    ADD CONSTRAINT qa_testinstance_reference_id_92e877e3_fk_qa_reference_id FOREIGN KEY (reference_id) REFERENCES public.qa_reference(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_testinstance qa_testinstance_reviewed_by_id_b2507968_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testinstance
    ADD CONSTRAINT qa_testinstance_reviewed_by_id_b2507968_fk_auth_user_id FOREIGN KEY (reviewed_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_testinstance qa_testinstance_status_id_45112bad_fk_qa_testinstancestatus_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testinstance
    ADD CONSTRAINT qa_testinstance_status_id_45112bad_fk_qa_testinstancestatus_id FOREIGN KEY (status_id) REFERENCES public.qa_testinstancestatus(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_testinstance qa_testinstance_test_list_instance_i_5c6e01aa_fk_qa_testli; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testinstance
    ADD CONSTRAINT qa_testinstance_test_list_instance_i_5c6e01aa_fk_qa_testli FOREIGN KEY (test_list_instance_id) REFERENCES public.qa_testlistinstance(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_testinstance qa_testinstance_tolerance_id_1fc90c78_fk_qa_tolerance_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testinstance
    ADD CONSTRAINT qa_testinstance_tolerance_id_1fc90c78_fk_qa_tolerance_id FOREIGN KEY (tolerance_id) REFERENCES public.qa_tolerance(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_testinstance qa_testinstance_unit_test_info_id_3708d3f6_fk_qa_unitte; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testinstance
    ADD CONSTRAINT qa_testinstance_unit_test_info_id_3708d3f6_fk_qa_unitte FOREIGN KEY (unit_test_info_id) REFERENCES public.qa_unittestinfo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_testlist qa_testlist_created_by_id_a31ba126_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlist
    ADD CONSTRAINT qa_testlist_created_by_id_a31ba126_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_testlist qa_testlist_modified_by_id_5f318376_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlist
    ADD CONSTRAINT qa_testlist_modified_by_id_5f318376_fk_auth_user_id FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_testlistcycle qa_testlistcycle_created_by_id_56e6b74d_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlistcycle
    ADD CONSTRAINT qa_testlistcycle_created_by_id_56e6b74d_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_testlistcycle qa_testlistcycle_modified_by_id_4fd36af5_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlistcycle
    ADD CONSTRAINT qa_testlistcycle_modified_by_id_4fd36af5_fk_auth_user_id FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_testlistcyclemembership qa_testlistcyclememb_cycle_id_59195e72_fk_qa_testli; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlistcyclemembership
    ADD CONSTRAINT qa_testlistcyclememb_cycle_id_59195e72_fk_qa_testli FOREIGN KEY (cycle_id) REFERENCES public.qa_testlistcycle(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_testlistcyclemembership qa_testlistcyclememb_test_list_id_9838340d_fk_qa_testli; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlistcyclemembership
    ADD CONSTRAINT qa_testlistcyclememb_test_list_id_9838340d_fk_qa_testli FOREIGN KEY (test_list_id) REFERENCES public.qa_testlist(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_testlistinstance qa_testlistinstance_created_by_id_7d53e4b6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlistinstance
    ADD CONSTRAINT qa_testlistinstance_created_by_id_7d53e4b6_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_testlistinstance qa_testlistinstance_modified_by_id_e5534397_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlistinstance
    ADD CONSTRAINT qa_testlistinstance_modified_by_id_e5534397_fk_auth_user_id FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_testlistinstance qa_testlistinstance_reviewed_by_id_a0c912f4_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlistinstance
    ADD CONSTRAINT qa_testlistinstance_reviewed_by_id_a0c912f4_fk_auth_user_id FOREIGN KEY (reviewed_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_testlistinstance qa_testlistinstance_test_list_id_49678bc1_fk_qa_testlist_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlistinstance
    ADD CONSTRAINT qa_testlistinstance_test_list_id_49678bc1_fk_qa_testlist_id FOREIGN KEY (test_list_id) REFERENCES public.qa_testlist(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_testlistinstance qa_testlistinstance_unit_test_collection_34d73919_fk_qa_unitte; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlistinstance
    ADD CONSTRAINT qa_testlistinstance_unit_test_collection_34d73919_fk_qa_unitte FOREIGN KEY (unit_test_collection_id) REFERENCES public.qa_unittestcollection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_testlistmembership qa_testlistmembership_test_id_c1cc5b13_fk_qa_test_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlistmembership
    ADD CONSTRAINT qa_testlistmembership_test_id_c1cc5b13_fk_qa_test_id FOREIGN KEY (test_id) REFERENCES public.qa_test(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_testlistmembership qa_testlistmembership_test_list_id_6c915779_fk_qa_testlist_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_testlistmembership
    ADD CONSTRAINT qa_testlistmembership_test_list_id_6c915779_fk_qa_testlist_id FOREIGN KEY (test_list_id) REFERENCES public.qa_testlist(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_tolerance qa_tolerance_created_by_id_c30bfcc9_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_tolerance
    ADD CONSTRAINT qa_tolerance_created_by_id_c30bfcc9_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_tolerance qa_tolerance_modified_by_id_934fa1b7_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_tolerance
    ADD CONSTRAINT qa_tolerance_modified_by_id_934fa1b7_fk_auth_user_id FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_unittestcollection qa_unittestcollectio_content_type_id_ada1fcc1_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestcollection
    ADD CONSTRAINT qa_unittestcollectio_content_type_id_ada1fcc1_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_unittestcollection_visible_to qa_unittestcollectio_group_id_288ea5fe_fk_auth_grou; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestcollection_visible_to
    ADD CONSTRAINT qa_unittestcollectio_group_id_288ea5fe_fk_auth_grou FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_unittestcollection qa_unittestcollectio_last_instance_id_aae52268_fk_qa_testli; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestcollection
    ADD CONSTRAINT qa_unittestcollectio_last_instance_id_aae52268_fk_qa_testli FOREIGN KEY (last_instance_id) REFERENCES public.qa_testlistinstance(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_unittestcollection_visible_to qa_unittestcollectio_unittestcollection_i_e029edac_fk_qa_unitte; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestcollection_visible_to
    ADD CONSTRAINT qa_unittestcollectio_unittestcollection_i_e029edac_fk_qa_unitte FOREIGN KEY (unittestcollection_id) REFERENCES public.qa_unittestcollection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_unittestcollection qa_unittestcollection_assigned_to_id_96fcc103_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestcollection
    ADD CONSTRAINT qa_unittestcollection_assigned_to_id_96fcc103_fk_auth_group_id FOREIGN KEY (assigned_to_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_unittestcollection qa_unittestcollection_frequency_id_9d8dd3ac_fk_qa_frequency_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestcollection
    ADD CONSTRAINT qa_unittestcollection_frequency_id_9d8dd3ac_fk_qa_frequency_id FOREIGN KEY (frequency_id) REFERENCES public.qa_frequency(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_unittestcollection qa_unittestcollection_unit_id_d348eb33_fk_units_unit_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestcollection
    ADD CONSTRAINT qa_unittestcollection_unit_id_d348eb33_fk_units_unit_id FOREIGN KEY (unit_id) REFERENCES public.units_unit(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_unittestinfo qa_unittestinfo_assigned_to_id_2fad7eb4_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestinfo
    ADD CONSTRAINT qa_unittestinfo_assigned_to_id_2fad7eb4_fk_auth_group_id FOREIGN KEY (assigned_to_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_unittestinfo qa_unittestinfo_reference_id_dcd9998b_fk_qa_reference_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestinfo
    ADD CONSTRAINT qa_unittestinfo_reference_id_dcd9998b_fk_qa_reference_id FOREIGN KEY (reference_id) REFERENCES public.qa_reference(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_unittestinfo qa_unittestinfo_test_id_456afff4_fk_qa_test_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestinfo
    ADD CONSTRAINT qa_unittestinfo_test_id_456afff4_fk_qa_test_id FOREIGN KEY (test_id) REFERENCES public.qa_test(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_unittestinfo qa_unittestinfo_tolerance_id_05b87f44_fk_qa_tolerance_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestinfo
    ADD CONSTRAINT qa_unittestinfo_tolerance_id_05b87f44_fk_qa_tolerance_id FOREIGN KEY (tolerance_id) REFERENCES public.qa_tolerance(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_unittestinfo qa_unittestinfo_unit_id_d1a42e3e_fk_units_unit_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestinfo
    ADD CONSTRAINT qa_unittestinfo_unit_id_d1a42e3e_fk_units_unit_id FOREIGN KEY (unit_id) REFERENCES public.units_unit(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_unittestinfochange qa_unittestinfochang_unit_test_info_id_d46a01fd_fk_qa_unitte; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestinfochange
    ADD CONSTRAINT qa_unittestinfochang_unit_test_info_id_d46a01fd_fk_qa_unitte FOREIGN KEY (unit_test_info_id) REFERENCES public.qa_unittestinfo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_unittestinfochange qa_unittestinfochange_changed_by_id_dee5d9fa_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestinfochange
    ADD CONSTRAINT qa_unittestinfochange_changed_by_id_dee5d9fa_fk_auth_user_id FOREIGN KEY (changed_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_unittestinfochange qa_unittestinfochange_reference_id_bcc541ef_fk_qa_reference_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestinfochange
    ADD CONSTRAINT qa_unittestinfochange_reference_id_bcc541ef_fk_qa_reference_id FOREIGN KEY (reference_id) REFERENCES public.qa_reference(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: qa_unittestinfochange qa_unittestinfochange_tolerance_id_7a9de89d_fk_qa_tolerance_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_unittestinfochange
    ADD CONSTRAINT qa_unittestinfochange_tolerance_id_7a9de89d_fk_qa_tolerance_id FOREIGN KEY (tolerance_id) REFERENCES public.qa_tolerance(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: recurrence_date recurrence_date_recurrence_id_eb6cafba_fk_recurrenc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurrence_date
    ADD CONSTRAINT recurrence_date_recurrence_id_eb6cafba_fk_recurrenc FOREIGN KEY (recurrence_id) REFERENCES public.recurrence_recurrence(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: recurrence_param recurrence_param_rule_id_89d093fd_fk_recurrence_rule_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurrence_param
    ADD CONSTRAINT recurrence_param_rule_id_89d093fd_fk_recurrence_rule_id FOREIGN KEY (rule_id) REFERENCES public.recurrence_rule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: recurrence_rule recurrence_rule_recurrence_id_b9b6b296_fk_recurrenc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurrence_rule
    ADD CONSTRAINT recurrence_rule_recurrence_id_b9b6b296_fk_recurrenc FOREIGN KEY (recurrence_id) REFERENCES public.recurrence_recurrence(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reports_reportnote reports_reportnote_report_id_ea9b46e4_fk_reports_savedreport_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_reportnote
    ADD CONSTRAINT reports_reportnote_report_id_ea9b46e4_fk_reports_savedreport_id FOREIGN KEY (report_id) REFERENCES public.reports_savedreport(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reports_reportschedule_groups reports_reportschedu_group_id_a57b3715_fk_auth_grou; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_reportschedule_groups
    ADD CONSTRAINT reports_reportschedu_group_id_a57b3715_fk_auth_grou FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reports_reportschedule reports_reportschedu_report_id_afe3bd17_fk_reports_s; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_reportschedule
    ADD CONSTRAINT reports_reportschedu_report_id_afe3bd17_fk_reports_s FOREIGN KEY (report_id) REFERENCES public.reports_savedreport(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reports_reportschedule_groups reports_reportschedu_reportschedule_id_71c8791d_fk_reports_r; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_reportschedule_groups
    ADD CONSTRAINT reports_reportschedu_reportschedule_id_71c8791d_fk_reports_r FOREIGN KEY (reportschedule_id) REFERENCES public.reports_reportschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reports_reportschedule_users reports_reportschedu_reportschedule_id_f6ec61b8_fk_reports_r; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_reportschedule_users
    ADD CONSTRAINT reports_reportschedu_reportschedule_id_f6ec61b8_fk_reports_r FOREIGN KEY (reportschedule_id) REFERENCES public.reports_reportschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reports_reportschedule reports_reportschedule_created_by_id_7146245b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_reportschedule
    ADD CONSTRAINT reports_reportschedule_created_by_id_7146245b_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reports_reportschedule reports_reportschedule_modified_by_id_e99e94b9_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_reportschedule
    ADD CONSTRAINT reports_reportschedule_modified_by_id_e99e94b9_fk_auth_user_id FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reports_reportschedule_users reports_reportschedule_users_user_id_e59ef055_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_reportschedule_users
    ADD CONSTRAINT reports_reportschedule_users_user_id_e59ef055_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reports_savedreport_visible_to reports_savedreport__group_id_695d07a0_fk_auth_grou; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_savedreport_visible_to
    ADD CONSTRAINT reports_savedreport__group_id_695d07a0_fk_auth_grou FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reports_savedreport_visible_to reports_savedreport__savedreport_id_177bc573_fk_reports_s; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_savedreport_visible_to
    ADD CONSTRAINT reports_savedreport__savedreport_id_177bc573_fk_reports_s FOREIGN KEY (savedreport_id) REFERENCES public.reports_savedreport(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reports_savedreport reports_savedreport_created_by_id_0558e77e_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_savedreport
    ADD CONSTRAINT reports_savedreport_created_by_id_0558e77e_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reports_savedreport reports_savedreport_modified_by_id_d4dce5ca_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports_savedreport
    ADD CONSTRAINT reports_savedreport_modified_by_id_d4dce5ca_fk_auth_user_id FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_grouplinkerinstance service_log_grouplin_group_linker_id_d10a3466_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_grouplinkerinstance
    ADD CONSTRAINT service_log_grouplin_group_linker_id_d10a3466_fk_service_l FOREIGN KEY (group_linker_id) REFERENCES public.service_log_grouplinker(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_grouplinkerinstance service_log_grouplin_service_event_id_b7d616b7_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_grouplinkerinstance
    ADD CONSTRAINT service_log_grouplin_service_event_id_b7d616b7_fk_service_l FOREIGN KEY (service_event_id) REFERENCES public.service_log_serviceevent(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_grouplinkerinstance service_log_grouplin_user_id_abbc59df_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_grouplinkerinstance
    ADD CONSTRAINT service_log_grouplin_user_id_abbc59df_fk_auth_user FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_grouplinker service_log_grouplinker_group_id_cac036fa_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_grouplinker
    ADD CONSTRAINT service_log_grouplinker_group_id_cac036fa_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_hours service_log_hours_service_event_id_9cef907a_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_hours
    ADD CONSTRAINT service_log_hours_service_event_id_9cef907a_fk_service_l FOREIGN KEY (service_event_id) REFERENCES public.service_log_serviceevent(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_hours service_log_hours_third_party_id_649aafe8_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_hours
    ADD CONSTRAINT service_log_hours_third_party_id_649aafe8_fk_service_l FOREIGN KEY (third_party_id) REFERENCES public.service_log_thirdparty(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_hours service_log_hours_user_id_95e3b0be_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_hours
    ADD CONSTRAINT service_log_hours_user_id_95e3b0be_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_returntoserviceqa service_log_qafollow_service_event_id_8815500a_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_returntoserviceqa
    ADD CONSTRAINT service_log_qafollow_service_event_id_8815500a_fk_service_l FOREIGN KEY (service_event_id) REFERENCES public.service_log_serviceevent(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_returntoserviceqa service_log_qafollow_unit_test_collection_4b674ad8_fk_qa_unitte; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_returntoserviceqa
    ADD CONSTRAINT service_log_qafollow_unit_test_collection_4b674ad8_fk_qa_unitte FOREIGN KEY (unit_test_collection_id) REFERENCES public.qa_unittestcollection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_returntoserviceqa service_log_qafollow_user_assigned_by_id_ef2c66e7_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_returntoserviceqa
    ADD CONSTRAINT service_log_qafollow_user_assigned_by_id_ef2c66e7_fk_auth_user FOREIGN KEY (user_assigned_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_returntoserviceqa service_log_returnto_test_list_instance_i_393472b0_fk_qa_testli; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_returntoserviceqa
    ADD CONSTRAINT service_log_returnto_test_list_instance_i_393472b0_fk_qa_testli FOREIGN KEY (test_list_instance_id) REFERENCES public.qa_testlistinstance(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceeventschedule service_log_servicee_assigned_to_id_113f5256_fk_auth_grou; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventschedule
    ADD CONSTRAINT service_log_servicee_assigned_to_id_113f5256_fk_auth_grou FOREIGN KEY (assigned_to_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceeventtemplate service_log_servicee_created_by_id_74f9add4_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventtemplate
    ADD CONSTRAINT service_log_servicee_created_by_id_74f9add4_fk_auth_user FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceeventschedule service_log_servicee_frequency_id_65e431ee_fk_qa_freque; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventschedule
    ADD CONSTRAINT service_log_servicee_frequency_id_65e431ee_fk_qa_freque FOREIGN KEY (frequency_id) REFERENCES public.qa_frequency(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceevent_service_event_related service_log_servicee_from_serviceevent_id_250d27e1_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceevent_service_event_related
    ADD CONSTRAINT service_log_servicee_from_serviceevent_id_250d27e1_fk_service_l FOREIGN KEY (from_serviceevent_id) REFERENCES public.service_log_serviceevent(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceeventschedule_visible_to service_log_servicee_group_id_79c02951_fk_auth_grou; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventschedule_visible_to
    ADD CONSTRAINT service_log_servicee_group_id_79c02951_fk_auth_grou FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceeventschedule service_log_servicee_last_instance_id_ae5e08b6_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventschedule
    ADD CONSTRAINT service_log_servicee_last_instance_id_ae5e08b6_fk_service_l FOREIGN KEY (last_instance_id) REFERENCES public.service_log_serviceevent(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceeventtemplate service_log_servicee_modified_by_id_10c7e385_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventtemplate
    ADD CONSTRAINT service_log_servicee_modified_by_id_10c7e385_fk_auth_user FOREIGN KEY (modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceeventtemplate service_log_servicee_service_area_id_e16ac3cf_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventtemplate
    ADD CONSTRAINT service_log_servicee_service_area_id_e16ac3cf_fk_service_l FOREIGN KEY (service_area_id) REFERENCES public.service_log_servicearea(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceevent service_log_servicee_service_event_schedu_cde59198_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceevent
    ADD CONSTRAINT service_log_servicee_service_event_schedu_cde59198_fk_service_l FOREIGN KEY (service_event_schedule_id) REFERENCES public.service_log_serviceeventschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceevent service_log_servicee_service_event_templa_7a1118c2_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceevent
    ADD CONSTRAINT service_log_servicee_service_event_templa_7a1118c2_fk_service_l FOREIGN KEY (service_event_template_id) REFERENCES public.service_log_serviceeventtemplate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceeventschedule service_log_servicee_service_event_templa_98e72acf_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventschedule
    ADD CONSTRAINT service_log_servicee_service_event_templa_98e72acf_fk_service_l FOREIGN KEY (service_event_template_id) REFERENCES public.service_log_serviceeventtemplate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceevent service_log_servicee_service_status_id_b30fd85a_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceevent
    ADD CONSTRAINT service_log_servicee_service_status_id_b30fd85a_fk_service_l FOREIGN KEY (service_status_id) REFERENCES public.service_log_serviceeventstatus(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceevent service_log_servicee_service_type_id_1fcdb7d3_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceevent
    ADD CONSTRAINT service_log_servicee_service_type_id_1fcdb7d3_fk_service_l FOREIGN KEY (service_type_id) REFERENCES public.service_log_servicetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceeventtemplate service_log_servicee_service_type_id_5aad4fca_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventtemplate
    ADD CONSTRAINT service_log_servicee_service_type_id_5aad4fca_fk_service_l FOREIGN KEY (service_type_id) REFERENCES public.service_log_servicetype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceeventschedule_visible_to service_log_servicee_serviceeventschedule_d30da730_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventschedule_visible_to
    ADD CONSTRAINT service_log_servicee_serviceeventschedule_d30da730_fk_service_l FOREIGN KEY (serviceeventschedule_id) REFERENCES public.service_log_serviceeventschedule(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceeventtemplate_return_to_service_test_lists service_log_servicee_serviceeventtemplate_af4f4502_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventtemplate_return_to_service_test_lists
    ADD CONSTRAINT service_log_servicee_serviceeventtemplate_af4f4502_fk_service_l FOREIGN KEY (serviceeventtemplate_id) REFERENCES public.service_log_serviceeventtemplate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceeventtemplate_return_to_service_cycles service_log_servicee_serviceeventtemplate_c5388b48_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventtemplate_return_to_service_cycles
    ADD CONSTRAINT service_log_servicee_serviceeventtemplate_c5388b48_fk_service_l FOREIGN KEY (serviceeventtemplate_id) REFERENCES public.service_log_serviceeventtemplate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceevent service_log_servicee_test_list_instance_i_35d1ebd3_fk_qa_testli; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceevent
    ADD CONSTRAINT service_log_servicee_test_list_instance_i_35d1ebd3_fk_qa_testli FOREIGN KEY (test_list_instance_initiated_by_id) REFERENCES public.qa_testlistinstance(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceeventtemplate_return_to_service_test_lists service_log_servicee_testlist_id_e2aa6d89_fk_qa_testli; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventtemplate_return_to_service_test_lists
    ADD CONSTRAINT service_log_servicee_testlist_id_e2aa6d89_fk_qa_testli FOREIGN KEY (testlist_id) REFERENCES public.qa_testlist(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceeventtemplate_return_to_service_cycles service_log_servicee_testlistcycle_id_53723a07_fk_qa_testli; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventtemplate_return_to_service_cycles
    ADD CONSTRAINT service_log_servicee_testlistcycle_id_53723a07_fk_qa_testli FOREIGN KEY (testlistcycle_id) REFERENCES public.qa_testlistcycle(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceevent_service_event_related service_log_servicee_to_serviceevent_id_3ea069ed_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceevent_service_event_related
    ADD CONSTRAINT service_log_servicee_to_serviceevent_id_3ea069ed_fk_service_l FOREIGN KEY (to_serviceevent_id) REFERENCES public.service_log_serviceevent(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceeventschedule service_log_servicee_unit_service_area_id_b138845e_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceeventschedule
    ADD CONSTRAINT service_log_servicee_unit_service_area_id_b138845e_fk_service_l FOREIGN KEY (unit_service_area_id) REFERENCES public.service_log_unitservicearea(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceevent service_log_servicee_unit_service_area_id_c762e446_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceevent
    ADD CONSTRAINT service_log_servicee_unit_service_area_id_c762e446_fk_service_l FOREIGN KEY (unit_service_area_id) REFERENCES public.service_log_unitservicearea(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceevent service_log_servicee_user_created_by_id_553ba44d_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceevent
    ADD CONSTRAINT service_log_servicee_user_created_by_id_553ba44d_fk_auth_user FOREIGN KEY (user_created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceevent service_log_servicee_user_modified_by_id_7bf503f5_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceevent
    ADD CONSTRAINT service_log_servicee_user_modified_by_id_7bf503f5_fk_auth_user FOREIGN KEY (user_modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_serviceevent service_log_servicee_user_status_changed__755a57b8_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_serviceevent
    ADD CONSTRAINT service_log_servicee_user_status_changed__755a57b8_fk_auth_user FOREIGN KEY (user_status_changed_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_servicelog service_log_servicel_service_event_id_009ddecd_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_servicelog
    ADD CONSTRAINT service_log_servicel_service_event_id_009ddecd_fk_service_l FOREIGN KEY (service_event_id) REFERENCES public.service_log_serviceevent(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_servicelog service_log_servicelog_user_id_31ee369b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_servicelog
    ADD CONSTRAINT service_log_servicelog_user_id_31ee369b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_thirdparty service_log_thirdparty_vendor_id_bc8107b0_fk_units_vendor_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_thirdparty
    ADD CONSTRAINT service_log_thirdparty_vendor_id_bc8107b0_fk_units_vendor_id FOREIGN KEY (vendor_id) REFERENCES public.units_vendor(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_unitservicearea service_log_unitserv_service_area_id_057e67f5_fk_service_l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_unitservicearea
    ADD CONSTRAINT service_log_unitserv_service_area_id_057e67f5_fk_service_l FOREIGN KEY (service_area_id) REFERENCES public.service_log_servicearea(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_log_unitservicearea service_log_unitservicearea_unit_id_3784b1fb_fk_units_unit_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_log_unitservicearea
    ADD CONSTRAINT service_log_unitservicearea_unit_id_3784b1fb_fk_units_unit_id FOREIGN KEY (unit_id) REFERENCES public.units_unit(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: units_unit_modalities units_unit_modalities_modality_id_875b4f27_fk_units_modality_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unit_modalities
    ADD CONSTRAINT units_unit_modalities_modality_id_875b4f27_fk_units_modality_id FOREIGN KEY (modality_id) REFERENCES public.units_modality(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: units_unit_modalities units_unit_modalities_unit_id_93f0e84c_fk_units_unit_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unit_modalities
    ADD CONSTRAINT units_unit_modalities_unit_id_93f0e84c_fk_units_unit_id FOREIGN KEY (unit_id) REFERENCES public.units_unit(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: units_unit units_unit_site_id_d1d5d0aa_fk_units_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unit
    ADD CONSTRAINT units_unit_site_id_d1d5d0aa_fk_units_site_id FOREIGN KEY (site_id) REFERENCES public.units_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: units_unit units_unit_type_id_29510326_fk_units_unittype_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unit
    ADD CONSTRAINT units_unit_type_id_29510326_fk_units_unittype_id FOREIGN KEY (type_id) REFERENCES public.units_unittype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: units_unitavailabletime units_unitavailabletime_unit_id_e3727bf5_fk_units_unit_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unitavailabletime
    ADD CONSTRAINT units_unitavailabletime_unit_id_e3727bf5_fk_units_unit_id FOREIGN KEY (unit_id) REFERENCES public.units_unit(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: units_unitavailabletimeedit units_unitavailabletimeedit_unit_id_d509fbd0_fk_units_unit_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unitavailabletimeedit
    ADD CONSTRAINT units_unitavailabletimeedit_unit_id_d509fbd0_fk_units_unit_id FOREIGN KEY (unit_id) REFERENCES public.units_unit(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: units_unittype units_unittype_unit_class_id_a731630a_fk_units_unitclass_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unittype
    ADD CONSTRAINT units_unittype_unit_class_id_a731630a_fk_units_unitclass_id FOREIGN KEY (unit_class_id) REFERENCES public.units_unitclass(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: units_unittype units_unittype_vendor_id_3bc1a664_fk_units_vendor_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units_unittype
    ADD CONSTRAINT units_unittype_vendor_id_3bc1a664_fk_units_vendor_id FOREIGN KEY (vendor_id) REFERENCES public.units_vendor(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

\unrestrict MXEveMPs96eWcrxUjJg2polRxXLyWdw2NS2wg8jiVDPMQnrROCttm8eXJQbkh2D

