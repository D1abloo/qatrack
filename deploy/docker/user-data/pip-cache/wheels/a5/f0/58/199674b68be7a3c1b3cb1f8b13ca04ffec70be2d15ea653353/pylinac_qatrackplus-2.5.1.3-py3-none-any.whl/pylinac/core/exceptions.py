

class NotAnalyzed(ValueError):
    pass
